#!/usr/local/bin python

from _package.text import compare_document as cdobj
from _package.text import pdf_highlight as pdfobj
# from nltk.tokenize import sent_tokenize
from subprocess import check_output
# import subprocess as sp
# from subprocess import call as sub_call
from _utils import utils as util_
import pandas as pd
import numpy as np
# import ntpath
import shutil
import glob
import time
import os
import re
# import sys
from _utils.utils import inp_path, out_path, pro_path, st_03
from _utils.progress_logs import print_log
# from _utils.utils import pdf2text_util, arg_text_util
import platform as pf
import fitz
# import unicodedata
# from gensim.parsing.preprocessing import preprocess_string
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

#docdiff line 294

class docdiffer:
    '''
    Responsible for identifying and highlighting the difference in two version 
    of documents 
    '''
#Function to remove filename extension
    def Filename_noext(filename_ext):
        filename = os.path.splitext(filename_ext)[0]
        return filename


    def strip_spchrs(text):
        # text = unicodedata.normalize('NFD', text)
        text = text.encode('ascii', 'ignore')
        text = text.decode('utf-8')

        return str(text)
        
#Function to clean Folders
    def Clean_Folder(dirpath):
        for filename in os.listdir(dirpath):
            filepath = os.path.join(dirpath, filename)
            try:
                shutil.rmtree(filepath)
            except OSError:
                os.remove(filepath)

#Function to Create and Copy files
    def create_n_copy_(files_, directory, action):
        if not os.path.exists(directory):
            os.makedirs(directory)
        try:
            if action=='move':
                [shutil.move(filename, directory) for filename in files_]
            elif action=='copy':
                [shutil.copy(filename, directory) for filename in files_]
        except Exception as e:
            print(e)
            pass
            
# In Step1 PDF file is injested to create HTML, XML & Text files.

    def step_01(self, pdf_1_name, pdf_2_name):
        file_lists = [pdf_1_name, pdf_2_name]
        print("Files List Step 1: ", file_lists)

########Creating HTML, XML & Text files from Input Files
        for file in file_lists:
            #Extracting File name without extenstion
            file_name = docdiffer.Filename_noext(str(os.path.basename(file)))
            #Creating directory with file name
            file_dir = os.path.join(util_.st_01, file_name)
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)
            input_file = os.path.join(util_.inp_path, str(os.path.basename(file)))
            filepath_withComma = ('{}'+input_file+'{}').format('"','"')

            file_name_text = file_name +'.txt'
            text_output = os.path.join(file_dir, file_name_text)
            text_output_withComma = ('{}'+text_output+'{}').format('"','"')
########Text File Generation
            popplrpath = util_.poppler_bin
            gen_text_command = ' '.join([popplrpath+'pdftotext', '-layout', filepath_withComma, text_output_withComma])
            print("Text file created")
            check_output(gen_text_command, shell=True)
    
########create different directory for files                
            all_text = glob.glob(os.path.join(file_dir,'*.txt'))
            text_out_dir = os.path.join(file_dir, util_.txt_dir)
            docdiffer.create_n_copy_(all_text, text_out_dir, 'move')
              
########Check Table of Content    
            print("Checking table of contents")
            # docdiffer.Extract_table_content(text_out_dir, file)
            ###########################
            TOC_Page_flag = 0
            Extended_TOC_Flag = 0
            
            fpath = os.path.join(util_.inp_path, file)
            new_doc = fitz.open(fpath)
            toc_list = new_doc.get_toc()
            new_doc.close()
            if len(toc_list) > 2:
                for item in toc_list:
                    r1 = str(item[1]).strip()
                    r1 = r1.lower()
                    # print(r1)
                    if r1 in ['contents', 'toc', 'table of content']:
                        TOC_Page_flag = 1
                    r2 = item[2]
                    # print(r2)
                    if r2 <= 2:
                        Extended_TOC_Flag = 1
                if TOC_Page_flag == 0 and Extended_TOC_Flag == 0:
                    docdiffer.Extract_table_content_fitz(fpath)
                elif TOC_Page_flag == 1 and Extended_TOC_Flag == 1:   
                    docdiffer.Extract_table_content_fitz(fpath)
                else:
                    docdiffer.Extract_table_content_regex(text_out_dir, fpath)
            else:
                docdiffer.Extract_table_content_regex(text_out_dir, fpath)


    def get_sntnces(lst_sntnce):
        f_sentencelst = []
        new = [str(x) for x in lst_sntnce]
        temp_list = []
        for new_line in new:
            if 'Windows' in pf.platform():
                if new_line == "\r\n":
                    data = "".join(temp_list)
                    data = data.replace("\r\n", " ")
                    f_sentencelst.append(data)
                    temp_list = []
                else:
                    temp_list.append(new_line)

            if 'Linux' in pf.platform():
                if new_line == "\n":
                    data = "".join(temp_list)
                    data = data.replace("\n", " ")
                    f_sentencelst.append(data)
                    temp_list = []
                else:
                    temp_list.append(new_line)

    
        while("" in f_sentencelst) :
            f_sentencelst.remove("")
        if len(f_sentencelst)==0:
            f_sentencelst.append('')
        return f_sentencelst 
        

    def tokenize(folder_, f_exl, f_txt, title_pdf):
        print("Tokenizing the Data")
        # ILLEGAL_CHARACTERS_RE = re.compile(r'[\000-\010]|[\013-\014]|[\016-\037]')
        cleanrgx = r'[^A-Za-z0-9.\s]'
    #open extracted Table of content as a dataframe ndf
        # ndf = pd.read_excel(f_exl, engine='openpyxl')
        file_name = docdiffer.Filename_noext(str(os.path.basename(f_exl)))
        ex_cel = os.path.join(folder_, file_name)

        print(f_exl)
        ndf = pd.read_excel(f_exl, engine='openpyxl', dtype='O')

        for i, row in ndf.iterrows():
            temp_IDX = row['IDX']
            temp_IDX = str(temp_IDX)
            sec_name = row['SectionName']
            sec_name = str(sec_name)
            sec_name = re.sub(cleanrgx, '', sec_name)
            split_sec_list = sec_name.split(" ")
            if len(split_sec_list) >= 2:
                temp_sec_name = split_sec_list[0] + " " + split_sec_list[1]
                temp_sec_name = re.escape(temp_sec_name)
                if temp_IDX == 'nan':
                    ndf.at[i,'LINE_KEY'] = r'^\s*'+ temp_sec_name
                # elif temp_IDX[-2:] == '.0':
                #     ndf.at[i,'LINE_KEY'] = '^\s*'+temp_IDX[:-1]+'\s*'+ temp_sec_name
                else:
                    ndf.at[i,'LINE_KEY'] = r'^\s*'+temp_IDX+r'\s*'+ temp_sec_name
            else:
                temp_sec_name = split_sec_list[0]
                temp_sec_name = re.escape(temp_sec_name)
                if temp_IDX == 'nan':
                    ndf.at[i,'LINE_KEY'] = r'^\s*'+ temp_sec_name
                # elif temp_IDX[-2:] == '.0':
                #     ndf.at[i,'LINE_KEY'] = '^\s*'+temp_IDX[:-1]+'\s*'+ temp_sec_name
                else:
                    ndf.at[i,'LINE_KEY'] = r'^\s*'+temp_IDX+r'\s*'+ temp_sec_name

        ndf.to_excel(ex_cel +'_2.xlsx', index=False, engine='openpyxl')
        txt = open(f_txt, 'rb')
        file_lines = txt.readlines()
        txt.close()
        file_lines = [x.decode('utf-8') for x in file_lines]
        regexlst = ndf['LINE_KEY'].tolist()
        print("Line Count: ", len(file_lines), ", Key Count: ", len(regexlst))
        tmp_idx_lst = []
        found_flag = 0
        
        file_length = len(file_lines)
        clnrgx = r'[^A-Za-z0-9.\s]'
        end_point = 0
        for pat in regexlst:
            for ln1 in range(end_point, file_length):
                data_line = file_lines[ln1]
                data_line = re.sub(clnrgx, '', data_line)
                if re.search(pat, data_line, re.I):
                    tmp_idx_lst.append(ln1)  
                    found_flag = 1
                    end_point = (ln1 - 1)
                    break
                else:
                    found_flag = 0
                    npat = pat
                    npat = npat.replace(r'\(','.')
                    npat = npat.replace(r'\)','.')
                    npat = npat.replace(r'(','.')
                    npat = npat.replace(r')','.')
                    npat = npat.replace(r'\ ',r'\s*')

                    if re.search(npat,data_line, re.I):
                        tmp_idx_lst.append(ln1)  
                        found_flag = 1
                        end_point = (ln1 - 1)
                        break

            if found_flag == 0:
                print('Inconsistency')
                tmp_idx_lst.append(len(file_lines)-1)

        print(tmp_idx_lst)
        print(len(tmp_idx_lst))

        st_ntmp = []
        end_ntmp = []
        for id_ in range(len(tmp_idx_lst)):
            try:
                st_ntmp.append(tmp_idx_lst[id_])
                end_ntmp.append(tmp_idx_lst[id_+1])        
            except Exception as ex:
                print(ex)
                print("Log 7: ", tmp_idx_lst[id_])
                end_ntmp.append(file_length)

        print(ndf.shape, len(st_ntmp), len(end_ntmp))
        ndf['START_IDX'] = st_ntmp
        ndf['END_IDX'] = end_ntmp
        tmp_txt = []
        for idx, row in ndf.iterrows():
            exlst = file_lines[(int(row['START_IDX'])+1):int(row['END_IDX'])]
            flst = exlst
            tmp_txt.append(flst)
        ndf['Related_Text'] = tmp_txt
        ndf.to_excel(ex_cel + '_3.xlsx', index=False)

        #print("Part 5.b Dataframe saved at: ", ex_cel)
        #print("Part 5.b Dataframe records: ", ndf.shape)
        
        idx_ = []
        val_ = []
        rtext = []
        count = []
        for idx, row in ndf.iterrows():
            exlst = file_lines[(int(row['START_IDX'])+1):int(row['END_IDX'])]
            sntnce_lst = docdiffer.get_sntnces(exlst)
            a = len(sntnce_lst)
            for sntnce in sntnce_lst:
                idx_.append(row['IDX'])
                val_.append(row['SectionName'])
                p = re.compile(r'\s+')
                sntnce = (p.sub(" ", sntnce))
                rtext.append(sntnce)
            for i in range(1,a+1):count.append(i)

        title_file = fitz.open(title_pdf)
        P_start = 0
        P_end = int(len(title_file))        
        for page in range(P_start,P_end):
            page_content = title_file[page]
            content = page_content.get_text()
            idx_.append('')
            val_.append('Title_Pages')
            rtext.append(content.strip())
            count.append(1)

        df_three = pd.DataFrame({'HEAD_IDX':idx_,'HEAD_VAL':val_,'SENTENCES':rtext, 'Counter':count})
        df_three['len'] = df_three['SENTENCES'].apply(lambda x: len(x.strip()))
        df_three = df_three[df_three['len'] > 4]
        df_three = df_three[['HEAD_IDX', 'HEAD_VAL', 'SENTENCES', 'Counter']]
        # df_three['SENTENCES'] = df_three['SENTENCES'].apply(lambda x: docdiffer.strip_spchrs(x))
        df_three = df_three.apply(lambda x: ILLEGAL_CHARACTERS_RE.sub(r'', x) if isinstance(x, str) else x)
        # df_three = df_three.applymap(lambda x: x.encode('unicode_escape').decode('utf-8') if isinstance(x, str) else x)
        df_three.to_excel(ex_cel + '_tokenized.xlsx', index=False, engine='openpyxl')

        print("Part 6 Dataframe saved at: ", ex_cel)
        print("Part 6 Dataframe records: ", df_three.shape)


    def detect_paragraphs(lines, avg_char_length, avg_gap):
        """
        Detect paragraphs based on specific criteria:
        - Line starts with a capital letter or a number.
        - Line has fewer characters than the average line length.
        - Line contains more than 2 words.
        - Gap between lines is larger than the average gap.
        """
        paragraphs = []
        current_paragraph = ""
        prev_y = None  # To track the y-coordinate of the previous line

        # Define regex pattern for paragraph start
        paragraph_start_pattern = re.compile(r'^[A-Z0-9]')  # Starts with uppercase letter or number
        
        for line in lines:
            text, y_coord = line
            
            # Skip empty lines
            if not text.strip():
                continue

            # Check if the line starts with a valid paragraph character (uppercase letter or number)
            if not paragraph_start_pattern.match(text):  # Regex check for paragraph start
                continue
            
            # Calculate gap between this line and the previous one
            gap = abs(y_coord - prev_y) if prev_y is not None else 0
            
            # Check paragraph boundary conditions
            is_start_of_paragraph = (
                len(text) < min(70, avg_char_length) and               # Fewer characters than average
                len(text.split()) > 2 and                     # More than 2 words
                (gap > avg_gap if prev_y is not None else False)  # Larger-than-average gap
            )
            
            if is_start_of_paragraph and current_paragraph.strip():
                firstline = current_paragraph.split('\n')[0].strip()
                paragraphs.append(firstline)
                current_paragraph = ""
            
            current_paragraph += " " + text
            prev_y = y_coord
        
        # Add the last accumulated paragraph
        if current_paragraph.strip():
            firstline = current_paragraph.split('\n')[0].strip()
            paragraphs.append(firstline)
        
        return paragraphs


    def extract_paragraphs_from_pdf(doc):
        """
        Extract up to 3 paragraphs per page from the PDF using improved paragraph detection.
        Each paragraph's first line is treated as the SectionName.
        """
        # doc = fitz.open(pdf_path)
        data = []
        
        for page_num in range(len(doc)):
            page = doc.load_page(page_num)
            blocks = page.get_text("blocks")  # Get text blocks with coordinates
            
            # Extract lines and calculate average character length and gap
            lines = []
            total_chars = 0
            total_gaps = 0
            prev_y = None
            
            for block in blocks:
                x0, y0, x1, y1, text, block_no, block_type = block
                if block_type != 0:  # Ignore non-text blocks
                    continue
                
                for line in text.split('\n'):
                    line = line.strip()
                    if not line:
                        continue
                    
                    lines.append((f"{line}\n", y0))
                    total_chars += len(line)
                    
                    if prev_y is not None:
                        total_gaps += abs(y0 - prev_y)
                    prev_y = y0
            
            # Calculate averages
            avg_char_length = total_chars / len(lines) if lines else 0
            avg_gap = total_gaps / (len(lines) - 1) if len(lines) > 1 else 0
            
            # Detect paragraphs
            paragraphs = docdiffer.detect_paragraphs(lines, avg_char_length, avg_gap)
            
            # Limit to 3 paragraphs per page
            for i, paragraph in enumerate(paragraphs):
                section_name = paragraph.split('.')[0].strip()  # First line as SectionName
                data.append({
                    'IDX': '',
                    'SectionName': section_name,
                    'PageNumber': page_num + 1,  # 1-based page numbering
                    'SectionNumber': f"Section {i+1}"
                })
        
        return pd.DataFrame(data)


    def Extract_table_content_fitz(file):
    
    #Read TOC from PDF file
        new_doc = fitz.open(file)
        toc_list = new_doc.get_toc()
        
    #Define Pandas Dataframe
        df = pd.DataFrame(columns=('IDX','SectionName', 'PageNumber'))
        clnrgx = r'[^A-Za-z0-9.\s]'
    #Extract Table of Content in Data frame
        for item in toc_list:
            r1 = str(item[1]).strip()
            r1 = r1.title()
            r1 = re.sub(clnrgx, '', r1)
            r2 = item[2]
            values_to_add = {'SectionName': r1, 'PageNumber': r2}
            row_to_add = pd.DataFrame([values_to_add])  # Convert dictionary to DataFrame
            df = pd.concat([df, row_to_add], ignore_index=True)
            
    #dataframe manipulation to remove figure&table data And to check if content itself is present in TOC
        toc_word_flag = 0
        toc_word_Index = 0
        for i, row in df.iterrows():
            part = row['SectionName']
            toc_word_list = ['contents', 'toc', 'table of content', 'table of contents', 'list of contents', 'index', 'contents page']
            if part.lower() in toc_word_list: 
                toc_word_Index = i
                toc_word_flag = 1
            if re.findall("^figure|^Figure|^table|^Table", part.strip()): df.drop(i, inplace=True)
                
    #defining path to save TOC excel, temp PDF & remaining text file
        file_name = docdiffer.Filename_noext(str(os.path.basename(file)))
        step_2_f_dir = os.path.join(util_.st_02, file_name)
        if not os.path.exists(step_2_f_dir):
            os.makedirs(step_2_f_dir)
        excel_out_name = file_name+'_TOC'+'.xlsx'
        Excel_out = os.path.join(step_2_f_dir, excel_out_name)
        title_pdf_out_name = file_name+'_Title'+'.pdf'
        temp_pdf_out_name = file_name+'_Temp'+'.pdf'
        Title_pdf_out = os.path.join(step_2_f_dir, title_pdf_out_name)
        Temp_pdf_out = os.path.join(step_2_f_dir, temp_pdf_out_name)
        title_text_out = os.path.join(step_2_f_dir, file_name + '_title.txt')
        temp_text_out = os.path.join(step_2_f_dir, file_name + '_temp.txt')
        
    # if toc_word_flag is 1
        if toc_word_flag == 1:
            page_number = df.iloc[toc_word_Index+1]['PageNumber']
            page_list = list(range(page_number-1, new_doc.page_count))                     
            new_doc.select(page_list)                           
            new_doc.save(Temp_pdf_out, garbage=3)
            new_doc = fitz.open(file)
            Title_page_list = list(range(0, page_number-1))                     
            new_doc.select(Title_page_list)                           
            new_doc.save(Title_pdf_out, garbage=3)
            in_ = ('{}'+Temp_pdf_out+'{}').format('"','"')
            out_ = ('{}'+temp_text_out+'{}').format('"','"')
            # pdftotext_command = "pdftotext -layout"
            popplrpath = util_.poppler_bin
            gen_text_command = ' '.join([popplrpath+"pdftotext -layout", in_, out_])
            check_output(gen_text_command, shell=True)
            for word_index in range(toc_word_Index+1):
                df = df.drop([word_index] , axis=0)
                
    # if toc_word_flag is 0
        if toc_word_flag == 0:
            page_number = df.iloc[0]['PageNumber']
            page_list = list(range(page_number-1, new_doc.page_count))                     
            new_doc.select(page_list)                           
            new_doc.save(Temp_pdf_out, garbage=3)
            new_doc = fitz.open(file)
            Title_page_list = list(range(0, page_number-1))                     
            new_doc.select(Title_page_list)                           
            new_doc.save(Title_pdf_out, garbage=3)
            in_ = ('{}'+Temp_pdf_out+'{}').format('"','"')
            out_ = ('{}'+temp_text_out+'{}').format('"','"')
            # pdftotext_command = "pdftotext -layout"
            popplrpath = util_.poppler_bin
            gen_text_command = ' '.join([popplrpath+"pdftotext -layout", in_, out_])
            check_output(gen_text_command, shell=True)
            
    #dataframe manipulation for adding extra column "IDX" and to remove nan values and remove figure and table data
        df = df.replace(np.nan, '', regex=True)
        df = df.dropna()
        idx_lst = []
        for i, row in df.iterrows():
            part = row['SectionName']
            p = re.compile(r'\s+')
            n_part = (p.sub(" ", part))
            ptrn = r"^[\\.\d]+"
            check_2 = re.findall(ptrn, n_part)
            if check_2:
                df.at[i,'IDX'] = str(check_2[0])
                n_part = n_part.replace(str(check_2[0]), "");
                df.at[i,'SectionName'] = n_part.strip()
            else:
                df.at[i,'IDX'] = ''
                df.at[i,'SectionName'] = n_part.strip()
                
    #Saving dataframe to excel.
        df = df[['IDX','SectionName', 'PageNumber']].astype('O')
        df.to_excel(Excel_out)
        new_doc.close()
        
        
    # making of remaing text file 
        #text_file_content = open(temp_text_out, 'r', encoding='utf-8')    
        text_file_content = open(temp_text_out, 'rb')  
        text_file_lines = text_file_content.readlines()
        text_file_content.close()
        lines_to_remove = []
        for line in text_file_lines:
            try:
                if b'\x0b' in line or b'\x0c' in line:
                    lines_to_remove.append(line)
            except Exception as e:
                print(e)
                continue
        text_file_lines = [x.decode('utf-8') for x in text_file_lines if x not in lines_to_remove]
        end = int(len(text_file_lines))
        remaining_text = []
        for n in range(end):
            line = text_file_lines[n]
            line = line.strip()
            remaining_text.append(line)
        rem_text_out = os.path.join(step_2_f_dir, file_name + '_RM_TOC.txt')
        remaining_text_file = open(rem_text_out,'w+', encoding='utf-8')
        for line_element in remaining_text:
            remaining_text_file.write(line_element + "\n")
        remaining_text_file.close()
    #running tokenization Module    
        if len(df.index) > 2:
             docdiffer.tokenize(step_2_f_dir, Excel_out, rem_text_out, Title_pdf_out)
        else:
            print("Table of Content Not present")

    def Extract_table_content_regex(folder,file):
      
        new_doc = fitz.open(file)
        P_start = 0
        P_end = int(len(new_doc)/3)
        last_page = 0

        df = pd.DataFrame(columns=('IDX','SectionName', 'PageNumber'))
        backup_line2 =""

        for page in range(P_start,P_end):      
            st = 0
            page_content = new_doc[page]
            content = page_content.get_text()
            text_file_lines = content.split("\n")
            clnrgx = r'[^A-Za-z0-9.\s]'
            for line in text_file_lines:
                ptrn1 = r"[\\.]{2,250}\s*\d+"
                check_1 = re.findall(ptrn1, line)
                if check_1:
                    result = re.split(r"\s*[\\.]{2,250}\s*", line)
                    r1 = result[0].strip()
                    r2 = result[1].strip()
                    if st>=1 : r1 = backup_line1.strip() + " " + backup_line2.strip() + " " + r1
                    if st == 0:
                        if str(backup_line2).replace('.', '').isdigit():
                            r1 = backup_line2.strip() + " " + r1
                    r1 = re.sub(clnrgx, '', r1)
                    values_to_add = {'SectionName': r1.strip(), 'PageNumber': r2}
                    row_to_add = pd.DataFrame([values_to_add])  # Convert dictionary to DataFrame
                    df = pd.concat([df, row_to_add], ignore_index=True)
                    st+=1
                    backup_line1 = ""
                    backup_line2 = ""
                    last_page = page
                if not check_1:
                    backup_line1 = backup_line2
                    backup_line2 = line.strip()

        if len(df.index) == 0:
            df = docdiffer.extract_paragraphs_from_pdf(new_doc)

    #defining path to save TOC excel, temp PDF & remaining text file
        file_name = docdiffer.Filename_noext(str(os.path.basename(file)))
        step_2_f_dir = os.path.join(util_.st_02, file_name)
        if not os.path.exists(step_2_f_dir):
            os.makedirs(step_2_f_dir)
        excel_out_name = file_name+'_TOC'+'.xlsx'
        Excel_out = os.path.join(step_2_f_dir, excel_out_name)
        title_pdf_out_name = file_name+'_Title'+'.pdf'
        temp_pdf_out_name = file_name+'_Temp'+'.pdf'
        Title_pdf_out = os.path.join(step_2_f_dir, title_pdf_out_name)
        Temp_pdf_out = os.path.join(step_2_f_dir, temp_pdf_out_name)
        # title_text_out = os.path.join(step_2_f_dir, file_name + '_title.txt')
        temp_text_out = os.path.join(step_2_f_dir, file_name + '_temp.txt')                

    #Remaining data file.
        page_list = list(range(last_page+1, new_doc.page_count))                     
        new_doc.select(page_list)                           
        new_doc.save(Temp_pdf_out, garbage=3)
        new_doc = fitz.open(file)
        Title_page_list = list(range(0, last_page+1))                     
        new_doc.select(Title_page_list)                           
        new_doc.save(Title_pdf_out, garbage=3)
        in_ = ('{}'+Temp_pdf_out+'{}').format('"','"')
        out_ = ('{}'+temp_text_out+'{}').format('"','"')
        # pdftotext_command = "pdftotext -layout"
        popplrpath = util_.poppler_bin
        gen_text_command = ' '.join([popplrpath+"pdftotext -layout", in_, out_])
        check_output(gen_text_command, shell=True)

    # making of remaing text file 
        #text_file_content = open(temp_text_out, 'r', encoding='utf-8')    
        text_file_content = open(temp_text_out, 'rb')  
        text_file_lines = text_file_content.readlines()
        text_file_content.close()
        lines_to_remove = []
        for line in text_file_lines:
            try:
                if b'\x0b' in line or b'\x0c' in line:
                    lines_to_remove.append(line)
            except Exception as e:
                print(e)
                continue
        text_file_lines = [x.decode('utf-8') for x in text_file_lines if x not in lines_to_remove]
        end = int(len(text_file_lines))
        remaining_text = []
        for n in range(end):
            line = text_file_lines[n]
            line = line.strip()
            remaining_text.append(line)
        rem_text_out = os.path.join(step_2_f_dir, file_name + '_RM_TOC.txt')
        remaining_text_file = open(rem_text_out,'w+', encoding='utf-8')
        for line_element in remaining_text:
            remaining_text_file.write(line_element + "\n")
        remaining_text_file.close()
        
        
    #dataframe manipulation to remove figure and table data
        for i, row in df.iterrows():
            part = row['SectionName']
            if re.findall("^figure|^Figure|^table|^Table", part.strip()): df.drop(i, inplace=True)

    #dataframe manipulation for adding extra column "IDX" and to remove nan values and remove figure and table data
        df = df.replace(np.nan, '', regex=True)
        df = df.dropna()
        # idx_lst = []
        for i, row in df.iterrows():
            part = row['SectionName']
            p = re.compile(r'\s+')
            n_part = (p.sub(" ", part))
            ptrn = r"^[\\.\d]+"
            check_2 = re.findall(ptrn, n_part)
            if check_2:
                df.at[i,'IDX'] = str(check_2[0])
                n_part = n_part.replace(str(check_2[0]), "");
                df.at[i,'SectionName'] = n_part.strip()
            else:
                df.at[i,'IDX'] = ''
                df.at[i,'SectionName'] = n_part.strip()

        df = df[['IDX','SectionName', 'PageNumber']].astype('O')
        df.to_excel(Excel_out)

    #running tokenization Module    
        if len(df.index) > 2:
            docdiffer.tokenize(step_2_f_dir, Excel_out, rem_text_out, Title_pdf_out)
        else:
            print("Table of Content Not present")


def begin_compare(pdf_1_name, pdf_2_name, outpdf, outxl, ExcelOutput):

    print('Process Started')
    start_time = time.time()
    clsobject = docdiffer()
    clsobject.step_01(pdf_1_name, pdf_2_name)


    # folder_dir = util_.input_path
    # final_path = os.path.join(folder_dir,'*.pdf')
    # file_list = glob.glob(final_path)
    # pdf_1_name = str(os.path.basename(file_list[0]))
    # pdf_2_name = str(os.path.basename(file_list[1]))
    
    
    # compare_document.main(util_.project_location, pdf_1_name, pdf_2_name)
    ExcelOutputT = cdobj.main(pro_path, pdf_1_name, pdf_2_name, outxl, ExcelOutput)
    end_time = time.time()
    print('Time Taken in Seconds for Excel File Generation: ', end_time-start_time)

    if outpdf:
        pdfobj.main(pdf_1_name, pdf_2_name, inp_path, out_path, st_03)
    #pdf_highlight.main(util_.project_location, pdf_1_name, pdf_2_name)

    end_time = time.time()
    print('Process Completed Successfully')
    print('Time Taken in Seconds for PDF File Generation: ', end_time-start_time)

    return ExcelOutputT


# if __name__=='__main__':
    # begin_compare()
    