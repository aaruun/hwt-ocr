#!/usr/local/bin python

from _package.text import compare_document as cdobj
from _package.text import pdf_highlight as pdfobj
# from nltk.tokenize import sent_tokenize
from subprocess import check_output
# import subprocess as sp
# from subprocess import call as sub_call
from _utils import utils as util_
import pandas as pd
import numpy as np
# import ntpath
import shutil
import glob
import time
import os
import re
# import sys
from _utils.utils import inp_path, out_path, pro_path, st_03
from _utils.progress_logs import print_log
# from _utils.utils import pdf2text_util, arg_text_util
import platform as pf
import fitz
# import unicodedata
# from gensim.parsing.preprocessing import preprocess_string
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

#docdiff line 294

class docdiffer:
    '''
    Responsible for identifying and highlighting the difference in two version 
    of documents 
    '''
#Function to remove filename extension
    def Filename_noext(filename_ext):
        filename = os.path.splitext(filename_ext)[0]
        return filename


    def strip_spchrs(text):
        # text = unicodedata.normalize('NFD', text)
        text = text.encode('ascii', 'ignore')
        text = text.decode('utf-8')

        return str(text)
        
#Function to clean Folders
    def Clean_Folder(dirpath):
        for filename in os.listdir(dirpath):
            filepath = os.path.join(dirpath, filename)
            try:
                shutil.rmtree(filepath)
            except OSError:
                os.remove(filepath)

#Function to Create and Copy files
    def create_n_copy_(files_, directory, action):
        if not os.path.exists(directory):
            os.makedirs(directory)
        try:
            if action=='move':
                [shutil.move(filename, directory) for filename in files_]
            elif action=='copy':
                [shutil.copy(filename, directory) for filename in files_]
        except Exception as e:
            print(e)
            pass
            
# In Step1 PDF file is injested to create HTML, XML & Text files.

    def step_01(self, pdf_1_name, pdf_2_name):
        file_lists = [pdf_1_name, pdf_2_name]
        print("Files List Step 1: ", file_lists)

########Creating HTML, XML & Text files from Input Files
        for file in file_lists:
            #Extracting File name without extenstion
            file_name = docdiffer.Filename_noext(str(os.path.basename(file)))
            #Creating directory with file name
            file_dir = os.path.join(util_.st_01, file_name)
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)
            input_file = os.path.join(util_.inp_path, str(os.path.basename(file)))
            filepath_withComma = ('{}'+input_file+'{}').format('"','"')

            file_name_text = file_name +'.txt'
            text_output = os.path.join(file_dir, file_name_text)
            text_output_withComma = ('{}'+text_output+'{}').format('"','"')
########Text File Generation
            gen_text_command = ' '.join(['pdftotext', '-layout', filepath_withComma, text_output_withComma])
            print("Text file created")
            check_output(gen_text_command, shell=True)
            # sp.Popen(gen_text_command)

            # tfile = open(text_output, 'rb+')
            # contents = tfile.readlines()
            # tlist = []
            # for l in contents:
            #     l = str(l)
            #     if not '\x0c' in l:
            #         tlist.append(l)
            #     else:
            #         tlist.append(b'\r\n')
            #         tlist.append(l.decode().replace('\x0c', '\x0a').encode())
            # tfile.write(np.array(tlist).tobytes())
            # tfile.close()
    
########create different directory for files                
            # all_html = glob.glob(os.path.join(file_dir,'*.html'))
            all_text = glob.glob(os.path.join(file_dir,'*.txt'))
            # all_xml = glob.glob(os.path.join(file_dir,'*.xml'))
              
            # html_out_dir = os.path.join(file_dir, util_.html_dir )
            text_out_dir = os.path.join(file_dir, util_.txt_dir)
            # xml_out_dir = os.path.join(file_dir, util_.xml_dir )

            # docdiffer.create_n_copy_(all_html, html_out_dir, 'move')
            docdiffer.create_n_copy_(all_text, text_out_dir, 'move')
            # docdiffer.create_n_copy_(all_xml, xml_out_dir, 'move')
              
########Check Table of Content    
            print("Checking table of contents")
            # docdiffer.Extract_table_content(text_out_dir, file)
            new_doc = fitz.open(os.path.join(util_.inp_path, file))
            toc_list = new_doc.get_toc()
            new_doc.close()
            if len(toc_list) > 2:
                docdiffer.Extract_table_content_fitz(os.path.join(util_.inp_path, file))
            else:
                docdiffer.Extract_table_content_regex(text_out_dir, file)


    def get_sntnces(lst_sntnce):
        f_sentencelst = []
        new = [str(x) for x in lst_sntnce]
        temp_list = []
        for new_line in new:
            if 'Windows' in pf.platform():
                if new_line == "\r\n":
                    data = "".join(temp_list)
                    data = data.replace("\r\n", " ")
                    f_sentencelst.append(data)
                    temp_list = []
                else:
                    temp_list.append(new_line)

            if 'Linux' in pf.platform():
                if new_line == "\n":
                    data = "".join(temp_list)
                    data = data.replace("\n", " ")
                    f_sentencelst.append(data)
                    temp_list = []
                else:
                    temp_list.append(new_line)

    
        while("" in f_sentencelst) :
            f_sentencelst.remove("")
        if len(f_sentencelst)==0:
            f_sentencelst.append('')
        return f_sentencelst 
        

    def tokenize(folder_, f_exl, f_txt):
        print("Tokenizing the Data")
        # ILLEGAL_CHARACTERS_RE = re.compile(r'[\000-\010]|[\013-\014]|[\016-\037]')
        cleanrgx = r'[^A-Za-z0-9.\s]'
    #open extracted Table of content as a dataframe ndf
        # ndf = pd.read_excel(f_exl, engine='openpyxl')
        file_name = docdiffer.Filename_noext(str(os.path.basename(f_exl)))
        ex_cel = os.path.join(folder_, file_name)

        print(f_exl)
        ndf = pd.read_excel(f_exl, engine='openpyxl', dtype='O')

        for i, row in ndf.iterrows():
            temp_IDX = row['IDX']
            temp_IDX = str(temp_IDX)
            sec_name = row['SectionName']
            sec_name = str(sec_name)
            sec_name = re.sub(cleanrgx, '', sec_name)
            split_sec_list = sec_name.split(" ")
            if len(split_sec_list) >= 2:
                temp_sec_name = split_sec_list[0] + " " + split_sec_list[1]
                temp_sec_name = re.escape(temp_sec_name)
                if temp_IDX == 'nan':
                    ndf.at[i,'LINE_KEY'] = '^\s*'+ temp_sec_name
                # elif temp_IDX[-2:] == '.0':
                #     ndf.at[i,'LINE_KEY'] = '^\s*'+temp_IDX[:-1]+'\s*'+ temp_sec_name
                else:
                    ndf.at[i,'LINE_KEY'] = '^\s*'+temp_IDX+'\s*'+ temp_sec_name
            else:
                temp_sec_name = split_sec_list[0]
                temp_sec_name = re.escape(temp_sec_name)
                if temp_IDX == 'nan':
                    ndf.at[i,'LINE_KEY'] = '^\s*'+ temp_sec_name
                # elif temp_IDX[-2:] == '.0':
                #     ndf.at[i,'LINE_KEY'] = '^\s*'+temp_IDX[:-1]+'\s*'+ temp_sec_name
                else:
                    ndf.at[i,'LINE_KEY'] = '^\s*'+temp_IDX+'\s*'+ temp_sec_name

        ndf.to_excel(ex_cel +'_2.xlsx', index=False, engine='openpyxl')
        txt = open(f_txt, 'rb')
        file_lines = txt.readlines()
        txt.close()
        file_lines = [x.decode('utf-8') for x in file_lines]
        # txt = open(f_txt, 'rb')
        # file_lines = txt.readlines()
        # txt.close()
        # idx_to_remove = []
        # print("Count of Lines: ", len(file_lines))
        # for lnum in range(len(file_lines)):
        #     try:
        #         if b'\x0b' in file_lines[lnum] or b'\x0c' in file_lines[lnum]:
        #             idx_to_remove.append(file_lines[lnum-1])
        #             idx_to_remove.append(file_lines[lnum])
        #             idx_to_remove.append(file_lines[lnum+1])   
        #     except:
        #             continue

        # file_lines = [x.decode('utf-8') for x in file_lines if x not in idx_to_remove]
        regexlst = ndf['LINE_KEY'].tolist()
        print("Line Count: ", len(file_lines), ", Key Count: ", len(regexlst))
        tmp_idx_lst = []
        found_flag = 0
        
        file_length = len(file_lines)
        clnrgx = r'[^A-Za-z0-9.\s]'
        end_point = 0
        for pat in regexlst:
            for ln1 in range(end_point, file_length):
                data_line = file_lines[ln1]
                data_line = re.sub(clnrgx, '', data_line)
                if re.search(pat, data_line, re.I):
                    tmp_idx_lst.append(ln1)  
                    found_flag = 1
                    end_point = (ln1 - 1)
                    break
                else:
                    found_flag = 0
                    npat = pat
                    npat = npat.replace(r'\(','.')
                    npat = npat.replace(r'\)','.')
                    npat = npat.replace(r'(','.')
                    npat = npat.replace(r')','.')
                    npat = npat.replace(r'\ ',r'\s*')

                    if re.search(npat,data_line, re.I):
                        tmp_idx_lst.append(ln1)  
                        found_flag = 1
                        end_point = (ln1 - 1)
                        break

            if found_flag == 0:
                print('Inconsistency')
                tmp_idx_lst.append(len(file_lines)-1)

        print(tmp_idx_lst)
        print(len(tmp_idx_lst))

        st_ntmp = []
        end_ntmp = []
        for id_ in range(len(tmp_idx_lst)):
            try:
                st_ntmp.append(tmp_idx_lst[id_])
                end_ntmp.append(tmp_idx_lst[id_+1])        
            except Exception as ex:
                print(ex)
                print("Log 7: ", tmp_idx_lst[id_])
                end_ntmp.append(file_length)

        print(ndf.shape, len(st_ntmp), len(end_ntmp))
        ndf['START_IDX'] = st_ntmp
        ndf['END_IDX'] = end_ntmp
        tmp_txt = []
        for idx, row in ndf.iterrows():
            exlst = file_lines[(int(row['START_IDX'])+1):int(row['END_IDX'])]
            flst = exlst
            tmp_txt.append(flst)
        ndf['Related_Text'] = tmp_txt
        ndf.to_excel(ex_cel + '_3.xlsx', index=False)

        #print("Part 5.b Dataframe saved at: ", ex_cel)
        #print("Part 5.b Dataframe records: ", ndf.shape)
        
        idx_ = []
        val_ = []
        rtext = []
        count = []
        for idx, row in ndf.iterrows():
            exlst = file_lines[(int(row['START_IDX'])+1):int(row['END_IDX'])]
            sntnce_lst = docdiffer.get_sntnces(exlst)
            a = len(sntnce_lst)
            for sntnce in sntnce_lst:
                idx_.append(row['IDX'])
                val_.append(row['SectionName'])
                p = re.compile(r'\s+')
                sntnce = (p.sub(" ", sntnce))
                rtext.append(sntnce)
            for i in range(1,a+1):count.append(i)
        df_three = pd.DataFrame({'HEAD_IDX':idx_,'HEAD_VAL':val_,'SENTENCES':rtext, 'Counter':count})
        df_three['len'] = df_three['SENTENCES'].apply(lambda x: len(x.strip()))
        df_three = df_three[df_three['len'] > 4]
        df_three = df_three[['HEAD_IDX', 'HEAD_VAL', 'SENTENCES', 'Counter']]
        # df_three['SENTENCES'] = df_three['SENTENCES'].apply(lambda x: docdiffer.strip_spchrs(x))
        df_three = df_three.applymap(lambda x: ILLEGAL_CHARACTERS_RE.sub(r'', x) if isinstance(x, str) else x)
        # df_three = df_three.applymap(lambda x: x.encode('unicode_escape').decode('utf-8') if isinstance(x, str) else x)
        df_three.to_excel(ex_cel + '_tokenized.xlsx', index=False, engine='openpyxl')

        print("Part 6 Dataframe saved at: ", ex_cel)
        print("Part 6 Dataframe records: ", df_three.shape)


    def Extract_table_content_fitz(file):
#Read TOC from PDF file
        new_doc = fitz.open(file)
        toc_list = new_doc.get_toc()
    
#Define Pandas Dataframe
        df = pd.DataFrame(columns=('IDX','SectionName', 'PageNumber'))
    
#Extract Table of Content in Data frame
        for item in toc_list:
            r1 = str(item[1]).strip()
            r1 = r1.title()
            r2 = item[2]
            values_to_add = {'SectionName': r1, 'PageNumber': r2}
            row_to_add = pd.Series(values_to_add)
            df = df.append(row_to_add, ignore_index=True)
        
#dataframe manipulation to remove figure&table data And to check if content itself is present in TOC
        toc_word_flag = 0
        toc_word_Index = 0
        for i, row in df.iterrows():
            part = row['SectionName']
            toc_word_list = ['contents', 'toc', 'table of content']
            if part.lower() in toc_word_list: 
                toc_word_Index = i
                toc_word_flag = 1
            if re.findall("^figure|^Figure|^table|^Table", part.strip()): df.drop(i, inplace=True)
            
#defining path to save TOC excel, temp PDF & remaining text file
        file_name = docdiffer.Filename_noext(str(os.path.basename(file)))
        step_2_f_dir = os.path.join(util_.st_02, file_name)
        if not os.path.exists(step_2_f_dir):
            os.makedirs(step_2_f_dir)
        excel_out_name = file_name+'_TOC'+'.xlsx'
        Excel_out = os.path.join(step_2_f_dir, excel_out_name)
        temp_pdf_out_name = file_name+'_Temp'+'.pdf'
        Temp_pdf_out = os.path.join(step_2_f_dir, temp_pdf_out_name)
        temp_text_out = os.path.join(step_2_f_dir, file_name + '_TEMP.txt')
    
# if toc_word_flag is 1
        if toc_word_flag == 1:
            page_number = df.iloc[toc_word_Index+1]['PageNumber']
            page_list = list(range(page_number-1, new_doc.pageCount))                     
            new_doc.select(page_list)                           
            new_doc.save(Temp_pdf_out, garbage=3)
            in_ = ('{}'+Temp_pdf_out+'{}').format('"','"')
            out_ = ('{}'+temp_text_out+'{}').format('"','"')
            gen_text_command = ' '.join(['pdftotext', '-layout', in_, out_])
            check_output(gen_text_command, shell=True)
            # sp.Popen(gen_text_command)
            for word_index in range(toc_word_Index+1):
                df = df.drop([word_index] , axis=0)
            
# if toc_word_flag is 0
        if toc_word_flag == 0:
            page_number = df.iloc[0]['PageNumber']
            page_list = list(range(page_number-1, new_doc.pageCount))                     
            new_doc.select(page_list)                           
            new_doc.save(Temp_pdf_out, garbage=3)
            in_ = ('{}'+Temp_pdf_out+'{}').format('"','"')
            out_ = ('{}'+temp_text_out+'{}').format('"','"')
            gen_text_command = ' '.join(['pdftotext', '-layout', in_, out_])
            check_output(gen_text_command, shell=True)
            # sp.Popen(gen_text_command)
        
#dataframe manipulation for adding extra column "IDX" and to remove nan values and remove figure and table data
        df = df.replace(np.nan, '', regex=True)
        df = df.dropna()
        idx_lst = []
        for i, row in df.iterrows():
            part = row['SectionName']
            p = re.compile(r'\s+')
            n_part = (p.sub(" ", part))
            ptrn = r"^[\\.\d]+"
            check_2 = re.findall(ptrn, n_part)
            if check_2:
                df.at[i,'IDX'] = str(check_2[0])
                n_part = n_part.replace(str(check_2[0]), "");
                df.at[i,'SectionName'] = n_part.strip()
            else:
                df.at[i,'IDX'] = ''
                df.at[i,'SectionName'] = n_part.strip()
            
#Saving dataframe to excel.
        df = df[['IDX','SectionName', 'PageNumber']].astype('O')
        df.to_excel(Excel_out)
        new_doc.close()
        
        # making of remaing text file 
        text_file_content = open(temp_text_out, 'rb')      
        text_file_lines = text_file_content.readlines()
        text_file_content.close()
        lines_to_remove = []
        for line in text_file_lines:
            try:
                if b'\x0b' in line or b'\x0c' in line:
                    lines_to_remove.append(line)
            except Exception as e:
                print(e)
                continue
        text_file_lines = [x.decode('utf-8') for x in text_file_lines if x not in lines_to_remove]
        end = int(len(text_file_lines))
        remaining_text = []
        for n in range(end):
            line = text_file_lines[n]
            line = line.strip()
            remaining_text.append(line)
        rem_text_out = os.path.join(step_2_f_dir, file_name + '_RM_TOC.txt')
        remaining_text_file = open(rem_text_out,'w+', encoding='utf-8')
        for line_element in remaining_text:
            remaining_text_file.write(line_element + "\n")
        remaining_text_file.close()

#running tokenization Module    
        if len(df.index) > 2:
            docdiffer.tokenize(step_2_f_dir, Excel_out, rem_text_out)
        else:
            print("Table of Content Not present")


    def Extract_table_content_regex(folder,file):
        files = glob.glob(os.path.join(folder, '*.txt'))
        for text_file in files:
            text_file_content = open(text_file, 'rb')      
            text_file_lines = text_file_content.readlines()
            text_file_content.close()
            lines_to_remove = []
            for line in text_file_lines:
                try:
                    if b'\x0b' in line or b'\x0c' in line:
                        lines_to_remove.append(line)
                except Exception as e:
                    print(e)
                    continue
            text_file_lines = [x.decode('utf-8') for x in text_file_lines if x not in lines_to_remove]
            end = int(len(text_file_lines))
            remaining_text = []
            for n in range(end):
                line = text_file_lines[n]
                ptrn1 = r"[\\.]{4,150}\s*\d+"
                check_1 = re.findall(ptrn1, line)
                if check_1:
                    backup_line = ""
                if not check_1:
                    backup_line = line.strip()
                    remaining_text.append(backup_line)
        
        
        new_doc = fitz.open(os.path.join(inp_path, file))
        P_start = 0
        P_end = int(len(new_doc))

        df = pd.DataFrame(columns=('IDX','SectionName', 'PageNumber'))
        st = 0
        backup_line2 =""

        for page in range(P_start,P_end):
            page_content = new_doc[page]
            content = page_content.get_text()
            text_file_lines = content.split("\n")
            for line in text_file_lines:
                ptrn1 = r"[\\.]{4,150}\s*\d+"
                check_1 = re.findall(ptrn1, line)
                if check_1:
                    result = re.split(r"\s*[\\.]{4,250}\s*", line)
                    r1 = result[0].strip()
                    r2 = result[1].strip()
                    if st>=1 : r1 = backup_line1.strip() + " " + backup_line2.strip() + " " + r1
                    values_to_add = {'SectionName': r1.strip(), 'PageNumber': r2}
                    row_to_add = pd.Series(values_to_add)
                    df = df.append(row_to_add, ignore_index=True)
                    st+=1
                    backup_line1 = ""
                    backup_line2 = ""
                if not check_1:
                    backup_line1 = backup_line2
                    backup_line2 = line.strip()
                    

    #defining path to save the Output of TOC dataframe
        file_name = docdiffer.Filename_noext(str(os.path.basename(file)))
        step_2_f_dir = os.path.join(util_.st_02, file_name)
        if not os.path.exists(step_2_f_dir):
            os.makedirs(step_2_f_dir)
        out_file_name = file_name+'_TOC'+'.xlsx'
        Excel_out = os.path.join(step_2_f_dir, out_file_name)
    #dataframe manipulation to remove figure and table data
        for i, row in df.iterrows():
            part = row['SectionName']
            if re.findall("^figure|^Figure|^table|^Table", part.strip()): df.drop(i, inplace=True)

    #dataframe manipulation for adding extra column "IDX" and to remove nan values and remove figure and table data
        df = df.replace(np.nan, '', regex=True)
        df = df.dropna()
        idx_lst = []
        for i, row in df.iterrows():
            part = row['SectionName']
            p = re.compile(r'\s+')
            n_part = (p.sub(" ", part))
            ptrn = r"^[\\.\d]+"
            check_2 = re.findall(ptrn, n_part)
            if check_2:
                df.at[i,'IDX'] = str(check_2[0])
                n_part = n_part.replace(str(check_2[0]), "");
                df.at[i,'SectionName'] = n_part.strip()
            else:
                df.at[i,'IDX'] = ''
                df.at[i,'SectionName'] = n_part.strip()


    #Creating text file for remaining data
        rem_text_out = os.path.join(step_2_f_dir, file_name + '_RM_TOC.txt')
        remaining_text_file = open(rem_text_out,'w+', encoding='utf-8')
        for line_element in remaining_text:
            remaining_text_file.write(line_element + "\n")
        remaining_text_file.close()
    #Saving dataframe to excel.
        df = df[['IDX','SectionName', 'PageNumber']].astype('O')
        df.to_excel(Excel_out)

    #running tokenization Module    
        if len(df.index) > 2:
            docdiffer.tokenize(step_2_f_dir, Excel_out, rem_text_out)
        else:
            print("Table of Content Not present")


def begin_compare(pdf_1_name, pdf_2_name, outpdf, outxl, ExcelOutput):

    print('Process Started')
    start_time = time.time()
    clsobject = docdiffer()
    clsobject.step_01(pdf_1_name, pdf_2_name)


    # folder_dir = util_.input_path
    # final_path = os.path.join(folder_dir,'*.pdf')
    # file_list = glob.glob(final_path)
    # pdf_1_name = str(os.path.basename(file_list[0]))
    # pdf_2_name = str(os.path.basename(file_list[1]))
    
    
    # compare_document.main(util_.project_location, pdf_1_name, pdf_2_name)
    ExcelOutputT = cdobj.main(pro_path, pdf_1_name, pdf_2_name, outxl, ExcelOutput)
    end_time = time.time()
    print('Time Taken in Seconds for Excel File Generation: ', end_time-start_time)

    if outpdf:
        pdfobj.main(pdf_1_name, pdf_2_name, inp_path, out_path, st_03)
    #pdf_highlight.main(util_.project_location, pdf_1_name, pdf_2_name)

    end_time = time.time()
    print('Process Completed Successfully')
    print('Time Taken in Seconds for PDF File Generation: ', end_time-start_time)

    return ExcelOutputT


# if __name__=='__main__':
    # begin_compare()
    