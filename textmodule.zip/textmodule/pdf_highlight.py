#!/usr/local/bin python

# from cloudapp.comparedoc import reset_dirs
import re
import fitz
import pandas as pd
#import time
import os
from tqdm import tqdm
from _utils.utils import st_02
import numpy as np
from _utils.progress_logs import print_log


yellow = (1.0, 1.0, 0.0)
orange = (1.0, 0.6, 0.0)
green = (0.0, 1.0, 0.0)


def create_dir(path_):
    if not os.path.exists(path_):
        os.makedirs(path_)

class pdfhighlight:    
    def duplicates(self,lst, item):
        return [i for i,x in enumerate(lst) if x == item]
    
    def getRectanglesForSearchText(self,page_obj,text_to_search,sentence_rect):
        #print("**getRectanglesForSearchText**")
        final_text_instance = []
        for text_ix in range(0,len(text_to_search)):
            if (text_to_search[text_ix] != "") & (text_to_search[text_ix] != " "):
                text_search = text_to_search[text_ix] 
                text_instances = []

                if len(text_to_search[text_ix].split()) == 1:
                    list_all_words = page_obj.get_text_words()
                    text_word_list = [word for word in list_all_words if word[4] == text_to_search[text_ix].strip()]
                    for word_det in text_word_list:
                        text_instances.append(fitz.Rect(word_det[0],word_det[1],word_det[2],word_det[3]))
                    
                if len(text_to_search[text_ix].split()) > 1 or text_instances == [] :
                    text_search = text_search.strip()
                    # text_instances = page_obj.search_for(text_search,hit_max=35)
                    text_instances = page_obj.search_for(text_search)
                    text_instances = text_instances[:35]
                
    
                if len(text_instances) == 1:
                    final_text_instance.append(text_instances[0])
                elif len(text_instances) > 1:
                    for i in range(0,len(text_instances)):
                        for j in range(0,len(sentence_rect)):
                            if text_instances[i][0] >= sentence_rect[j][0]:
                                if abs(text_instances[i][1] - sentence_rect[j][1]) < 2:
                                    if text_instances[i][2] <= sentence_rect[j][2]:
                                        if abs(text_instances[i][3] - sentence_rect[j][3]) < 2:
                                            final_text_instance.append(text_instances[i])
    
    
        text_duplicates = self.duplicates(text_to_search,text_to_search[text_ix])

        if len(text_duplicates) == len(final_text_instance):
            final_text_instance = [final_text_instance[text_duplicates.index(text_ix)]]

        return final_text_instance
        
    def formatTexttoHighlight(self, text):
        #print("**formatTexttoHighlight**")
        text_tmp1 = re.sub(r'(#-#)\1+',"####",text)
        text_tmp2 = text_tmp1.replace("#-#"," ")
        formatted_text = text_tmp2.split("####")
        return formatted_text
        
        

    def highlightPdfFromExcel(self, pdf_name, output, pdf_version,sentences_df,text_col,highlight_color,hcol,sec_col,toc):
        for sent in tqdm(range(0,sentences_df.shape[0])):
        
    #Checking for Moved Flag     
            Intra_section_change = False
            section_change = False
            flaglist = ['Moved ', 'Moved & Updated ']
            if sentences_df.iloc[sent,4] in flaglist:
                section_change = True
            if sentences_df.iloc[sent,4] == 'Intra Section Moved ':
                Intra_section_change = True
            
            finalToBeHiglightedRectangles = []
            sentence_instances = []
            
            sentence = sentences_df.iloc[sent,text_col]
            sentence = sentence.strip()
            
    #page num analysis using TOC
            section_name = sentences_df.iloc[sent,sec_col]
            section_name = section_name.strip()
            P_start = 0
            P_end = len(pdf_version)
            page_series = toc[toc['SectionName'] == section_name]['PageNumber']
            if len(page_series) > 0:
                page_num = page_series.iloc[0]
                page_num = str(page_num)
                page_num = page_num.replace('.','')
                page_num = page_num.strip()

                if str(page_num).isdigit() is True:
                    page_num = int(page_num)
                    toc_list = pdf_version.get_toc()
                    if len(toc_list) > 2 and page_num != 0:
                        P_start = page_num-1
                        P_end = len(pdf_version)
                    else:
                        if page_num == 0:
                            P_start = 0
                            P_end = len(pdf_version)
                        elif page_num < 5:
                            P_start = 0
                            P_end = 20
                        elif (page_num + 15) > len(pdf_version):
                            P_start = page_num - 5
                            P_end = len(pdf_version)
                        else:
                            P_start = page_num - 5
                            P_end = page_num + 15


    #looking for page where data is located         
            for page in range(P_start,P_end):
                page_content = pdf_version[page]
                sentence_instances = page_content.search_for(sentence)
                if sentence_instances:
                    break

    #making data for highlight
            if len(sentence_instances) > 0:
                if (section_change == False) & (Intra_section_change == False):
                    text_to_highlight = sentences_df.iloc[sent,hcol]
                    text_to_highlight_formatted = self.formatTexttoHighlight(text_to_highlight)
                    finalToBeHiglightedRectangles = self.getRectanglesForSearchText(page_content,text_to_highlight_formatted,sentence_instances)
                else:
                    finalToBeHiglightedRectangles = sentence_instances
                        
    #highlighting the data
            if finalToBeHiglightedRectangles:
                for instance in finalToBeHiglightedRectangles:

                    if section_change:
                        color = {"stroke": (1, 1, 0)}  # Yellow
                        annot = page_content.add_highlight_annot(instance)
                        annot.set_colors(color)
                        annot.set_opacity(0.3)
                        annot.update()

                    elif Intra_section_change:
                        color = {"stroke": (1, 0.5, 0)}  # Orange
                        annot = page_content.add_highlight_annot(instance)
                        annot.set_colors(color)
                        annot.set_opacity(0.3)
                        annot.update()

                    else:
                        color = {"stroke": highlight_color}  # Assuming highlight_color is already defined
                        annot = page_content.add_highlight_annot(instance)
                        annot.set_colors(color)
                        annot.set_opacity(0.2)
                        annot.update()

                        
        
        print("Saving doc at location: ", output+pdf_name)
        pdf_version.save(os.path.join(output,pdf_name))
        pdf_version.close()
        
        
def main(pdf_1, pdf_2, input_path, output_path, st_03):


    #New version
    new_doc = fitz.open(os.path.join(input_path, pdf_2))
    #Old version
    old_doc = fitz.open(os.path.join(input_path, pdf_1))

    sentences = pd.read_excel(os.path.join(st_03, "comparison_highlighted.xlsx"), engine='openpyxl', dtype='O')

    newfileflag = ['Updated ', 'Intra Section Moved ', 'Moved & Updated ', 'Moved ', 'Added ']
    oldfileflag = ['Updated ', 'Removed ', 'Intra Section Moved ', 'Moved & Updated ', 'Moved ']

    sentences_newfile = sentences[sentences["FLAG_"].isin(newfileflag)]
    sentences_oldfile = sentences[sentences["FLAG_"].isin(oldfileflag)]
    
#Opening Table of content file
    file_name1 = os.path.splitext(pdf_1)[0]
    file_name2 = os.path.splitext(pdf_2)[0]
    toc1path = os.path.join(st_02,file_name1 )
    toc2path = os.path.join(st_02,file_name2)
    toc1 = pd.read_excel(os.path.join(toc1path, file_name1+'_TOC'+'.xlsx'), engine='openpyxl', dtype='O')
    toc2 = pd.read_excel(os.path.join(toc2path, file_name2+'_TOC'+'.xlsx'), engine='openpyxl', dtype='O')
    toc1 = toc1[['IDX','SectionName','PageNumber']]
    toc2 = toc2[['IDX','SectionName','PageNumber']]
    toc1 = toc1.replace('NaN', np.nan)
    toc1 = toc1.fillna(' ')
    toc2 = toc2.replace('NaN', np.nan)
    toc2 = toc2.fillna(' ')
    toc1["IDX"] = toc1["IDX"].map(str).map(str.strip)
    toc2["IDX"] = toc2["IDX"].map(str).map(str.strip)
    toc1['SectionName'] = toc1['IDX'].str.cat(toc1['SectionName'], sep =" ")
    toc2['SectionName'] = toc2['IDX'].str.cat(toc2['SectionName'], sep =" ")
    toc1['SectionName'] = toc1['SectionName'].str.strip()
    toc2['SectionName'] = toc2['SectionName'].str.strip()

#Running Main code
    blue   = (0.0, 0.0, 1.0)
    red    = (1.0, 0.0, 0.0)
    # green = (0.0, 1.0, 0.0)
    # yellow = (1.0, 1.0, 0.0)
    # orange = (1.0, 0.6, 0.0)

    clsobject = pdfhighlight()
    
    clsobject.highlightPdfFromExcel(pdf_name = pdf_2, output = output_path, pdf_version = new_doc,sentences_df = sentences_newfile,text_col=3,highlight_color=blue,hcol=6,sec_col=2,toc=toc2)
    clsobject.highlightPdfFromExcel(pdf_name = pdf_1, output = output_path, pdf_version = old_doc,sentences_df = sentences_oldfile,text_col=1,highlight_color=red,hcol=7,sec_col=0,toc=toc1)


# if __name__=='__main__':
#     main(pdf_doc_1, pdf_doc_2, input, output, st_03)
