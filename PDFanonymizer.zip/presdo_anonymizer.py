from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine

text="My phone number is 212-555-5555 From Gerry Kreese Sent: Friday 13, September 2019 09:12 To: customerservices@abc.ie Subject: 1-541-754-3010 you@email.co.uk yourwebsite.co.uk 194-05-7176 Display issue with tv screen Hello ABC, My name is Gerry Kreese and I bought a Sony tv from your Philadelphia center last Sunday and I'm facing some display issue with the screen. Can you please send someone to fix it. I live just across the 203 Christopher Columbus Blvd, Philadelphia and for any other query you can contact me at +12676781822. Thanks Gerry Kreese  1-541-754-3010 you@email.co.uk yourwebsite.co.uk 194-05-7176"

# Set up the engine, loads the NLP module (spaCy model by default) 
# and other PII recognizers
analyzer = AnalyzerEngine()

# Call analyzer to get results
results = analyzer.analyze(text=text,
                           entities=["PHONE_NUMBER"],
                           language='en')
print(results)

# Analyzer results are passed to the AnonymizerEngine for anonymization

anonymizer = AnonymizerEngine()

anonymized_text = anonymizer.anonymize(text=text,analyzer_results=results)

print(anonymized_text)