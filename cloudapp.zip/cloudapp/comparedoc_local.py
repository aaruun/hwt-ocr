#!/usr/local/bin python

from _utils.utils import reqdirs, to_exclude, reset_dirs
reset_dirs(reqdirs, to_exclude)

# import time
import logging
import os
from datetime import datetime
# import re
# import pyodbc
# from _package.mod.azdb import pypyodbc as pyodbc
# import pandas as pd
import shutil
import ntpath
import xlsxwriter

from _package.tabl.table_comparison import table_module
from _package.img import image_comparison
from _package.text import document_difference #import begin_compare
# from _package.mod.email.sendgrid import notify_user

# from _package.mod.azblb.azblob import upload_toblob, download_fromblob
from _utils.utils import inp_path, out_path, vba_bin, xlmname, logpath, logfilename # xlmtemplate, xlmtmpl,
from _utils.progress_logs import print_log, move_logs, stopp_log
from _utils.excel_info import excel_metadata
from _utils.pdf_info import add_legends


dtstr = datetime.now().strftime("%Y.%m.%d")

# logfile = 'progress_{0}.log'.format(dtstr)
# logpath = os.path.join(pro_path, "_logs", logfile)
# logsout = os.path.join(out_path, logfile)

PUBLISH_ENV = 'QA'
container_name = "documentcompare"
docid = 'LOCAL'

def init_job(docid, PUBLISH_ENV):

    from _utils.progress_logs import logg_config

    docid = 0 if not docid else docid

    print_log(['PUBLISH_ENV is', PUBLISH_ENV])
    print_log('_'*88)

    dtstr = datetime.now().strftime("%Y.%m.%d")
    logfile = 'progress_{}_{}.log'.format(docid, dtstr)
    logsin = os.path.join(logpath, logfile)
    logsout = os.path.join(out_path, logfilename)

    log = logging.getLogger()
    stopp_log(log)
    reset_dirs(reqdirs, to_exclude)
    logg_config(logsin)

    return logsin, logsout


def end_time(begin_time):
    end_time = datetime.now() - begin_time
    hrs, rem = divmod(end_time.seconds, 3600)
    minuts, secs = divmod(rem, 60)
    return 'Took {}:{}:{} (hh:mm:ss)'.format(hrs, minuts, secs)


def path_leaf(path):
    head, tail = ntpath.split(path)
    return head, tail or ntpath.basename(head)


def check_file(file1, file2, inppath, outpath):

    df1 = os.path.isfile(os.path.join(outpath, file1))
    df2 = os.path.isfile(os.path.join(outpath, file2))

    sf1 = os.path.join(inppath, file1)
    sf2 = os.path.join(inppath, file2)

    if not df1 and not df2:
        shutil.copy(sf1, os.path.join(outpath, file1))
        shutil.copy(sf2, os.path.join(outpath, file2))


def get_files(input_path):

    files = os.listdir(input_path)
    for file in files:
        if file.startswith('Old'):
            oldfile = file
        elif file.startswith('New'):
            newfile = file

    _, oldfname = path_leaf(oldfile)
    _, newfname = path_leaf(newfile)

    print_log(["File Names", oldfname, newfname])

    return oldfname, newfname


def compare_doc(pdf_1, pdf_2, inp_path, out_path, tables, images, texts, outpdf, outxl):

    print_log(['PUBLISH_ENV is', PUBLISH_ENV])
    print_log('_'*88)          
    begin_time = datetime.now()
    print_log(["Comparison Start Time", begin_time.strftime("%Y.%m.%d %H:%M:%S")])

    dtstr = datetime.now().strftime("%d-%b-%Y")

    # shutil.copy(xlmtemplate+xlmtmpl, out_path+xlmname)
    ExcelOutput = xlsxwriter.Workbook(out_path+xlmname)
    ExcelOutput.add_vba_project(vba_bin)
    ExcelOutput = excel_metadata(ExcelOutput, pdf_1, pdf_2, "Arun(LocalScript)", dtstr)

    # try:
    if texts:
        print_log("Text Comparison Job Started..")
        ExcelOutput = document_difference.begin_compare(pdf_1, pdf_2, outpdf, outxl, ExcelOutput)
        print_log("Text Comparison Job Completed..")
        print_log(["Text Comparison Time", end_time(begin_time)])

    if images:
        # try:
        print_log("Image Comparison Job Started..")
        check_file(pdf_1, pdf_2, inp_path, out_path)
        print_log("Using PDFs from Output Path..")
        ExcelOutput = image_comparison.img_module(pdf_1, pdf_2, out_path, outpdf, outxl, ExcelOutput)
        print_log("Image Comparison Job Completed..")
        print_log(["Image Comparison Time", end_time(begin_time)])
        # except Exception as ex:
        #     print_log(["Image Module Exception", ex])
        #     # shutil.copy(logpath, logsout)
    
    if tables:
        # try:
        print_log("Table Comparison Job Started..")
        check_file(pdf_1, pdf_2, inp_path, out_path)
        print_log("Using PDFs from Output Path..")
        ExcelOutput = table_module(pdf_1, pdf_2, out_path, outpdf, outxl, ExcelOutput)
        print_log("Table Comparison Job Completed..")
        print_log(["Table Comparison Time", end_time(begin_time)])
        # except Exception as ex:
        #     print_log(["Table Module Exception", ex])
        #     # shutil.copy(logpath, logsout)

    # except Exception as ex:
    #     print_log(["CompareDoc Exception", ex])
    #     # shutil.copy(logpath, logsout)

    ExcelOutput.close()
    add_legends(out_path+pdf_1)
    add_legends(out_path+pdf_2)
    print_log("Comparison Job Completed..")
    print_log(["Comparison Job Time", end_time(begin_time)])
    return print_log("Process completed..")


def comparedocjob():

    logsin, logsout = init_job(docid, PUBLISH_ENV)

    texts, images, tables = True, True, True
    outpdf, outxl = True, True
    
    # reset_dirs(reqdirs, to_exclude)
    pdf_1, pdf_2 = get_files(inp_path)
    compare_doc(pdf_1, pdf_2, inp_path, out_path, tables, images, texts, outpdf, outxl)

    results = os.listdir(out_path)
    print_log(["List of files to upload", results])

    # notify_user('85370@global.ul.com', pdf_1, pdf_2, tables, images, outpdf, outxl, 'Completed')

    print_log('_'*88)


if __name__ == '__main__':
    comparedocjob()

