#!/usr/local/bin python

import logging
from _utils.utils import reqdirs, to_exclude, reset_dirs
import time
import os
from datetime import datetime
import re
import pyodbc
import pandas as pd
import shutil
import ntpath
import xlsxwriter

from _package.tabl.table_comparison import table_module
from _package.img import image_comparison
from _package.text import document_difference
from _package.mod.queries.queries_str import qry_chk_new, qry_update_proc, qry_update_path
from _package.mod.azblb.azblob import upload_toblob, download_fromblob
from _utils.utils import inp_path, out_path, vba_bin, xlmname, logpath, logfilename # xlmtemplate, xlmtmpl,
from _utils.progress_logs import print_log, move_logs, stopp_log
from _package.mod.email.sendgrid import notify_user
from _utils.excel_info import excel_metadata
from _utils.pdf_info import add_legends

driver= 'ODBC Driver 17 for SQL Server'

PUBLISH_ENV = 'Production'
# from _package.mod.azdb.db_creds_qa import  server, database, username, password
# containername = "documentcompare"
from _package.mod.vault.cred_vault import server, database, username, password, containername

cnxn = pyodbc.connect('DRIVER='+driver+';SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)

def init_job(docid, PUBLISH_ENV):

    from _utils.progress_logs import logg_config

    docid = 0 if not docid else docid

    print_log(['PUBLISH_ENV is', PUBLISH_ENV])
    print_log('_'*88)

    dtstr = datetime.now().strftime("%Y.%m.%d")
    logfile = 'progress_{}_{}.log'.format(docid, dtstr)
    logsin = os.path.join(logpath, logfile)
    logsout = os.path.join(out_path, logfilename)

    log = logging.getLogger()
    stopp_log(log)
    reset_dirs(reqdirs, to_exclude)
    logg_config(logsin)

    return logsin, logsout


def end_time(begin_time):
    end_time = datetime.now() - begin_time
    hrs, rem = divmod(end_time.seconds, 3600)
    minuts, secs = divmod(rem, 60)
    return 'Took {}:{}:{} (hh:mm:ss)'.format(hrs, minuts, secs)


def path_leaf(path):
    if path:
        head, tail = ntpath.split(path)
        return head, tail or ntpath.basename(head)
    else:
        return None, None


def check_file(file1, file2, inppath, outpath):

    df1 = os.path.isfile(os.path.join(outpath, file1))
    df2 = os.path.isfile(os.path.join(outpath, file2))

    sf1 = os.path.join(inppath, file1)
    sf2 = os.path.join(inppath, file2)

    if not df1 and not df2:
        shutil.copy(sf1, os.path.join(outpath, file1))
        shutil.copy(sf2, os.path.join(outpath, file2))


def update_status(cnxn, status, pct, docid, query):
    try:
        cursor = cnxn.cursor()
        query = re.sub("@status", str(status), query)
        query = re.sub("@percent", str(pct), query)
        query = re.sub("@id", str(docid), query)
        print_log(query)
        cursor.execute(query)
        cnxn.commit()
        return print_log("DB update success..")
    except Exception as ex:
        print_log([ex])
        return print_log("DB connection closed..")


def update_path(cnxn, files, fpath, docid, dttm, sql):
    cursor = cnxn.cursor()
    
    for file in files:
        filename = fpath+'/Result_'+file
        # print(fpath, file, filename)
        query = sql.replace("@filename", filename)
        query = query.replace("@id", str(docid))
        query = query.replace("@datetime", dttm)
        
        print_log(query)
        cursor.execute(query)
    cnxn.commit()
    return print_log("DB insert success..")


def update_results(out_path, outpdf, outxl, cnxn, fpath, docid, qry_update_path):
    uploads = []
    results = os.listdir(out_path)

    for file in results:
        if outpdf and file.endswith('pdf'):
            uploads.append(file)
        elif outxl and file == xlmname:
            uploads.append(file)
        elif file == logfilename:
            uploads.append(file)

    print_log(["List of files to upload", uploads])
    # dttm = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    dttm = datetime.now().isoformat(sep=' ', timespec='milliseconds')
    update_path(cnxn, uploads, fpath, docid, dttm, qry_update_path)


def poll_db(qry_chk_new, cnxn):
    df =  pd.read_sql(qry_chk_new, cnxn) #get_compare_params()

    if len(df.index) > 0:

        row = len(df.index)-1

        docid = df.at[row, 'DocComparisonID']
        oldfile = df.at[row, 'FileCurrentVersion']
        newfile = df.at[row, 'FileNewVersion']
        tables = df.at[row, 'IsIncludeTable']
        images = df.at[row, 'IsIncludeImages']
        outpdf = df.at[row, 'IsOutputPDF']
        outxl = df.at[row, 'IsOutputExcel']
        fstat = df.at[row, 'FileStatus']
        abortjob = df.at[row, 'FileProcessCancelled']
        createdby = df.at[row, 'CreatedBy']

        logsin, logsout = init_job(docid, PUBLISH_ENV)
        
        print_log("Doc comparison id: " + str(docid))
        print_log(["Blob storage file paths", oldfile, newfile])
        print_log(["Checked Options tables, images, pdf, excel", tables, images, outpdf, outxl])

    else:
        print_log(["No new jobs found.. Sleeping..", datetime.now().strftime("%Y.%m.%d %H:%M:%S")])
        return None, None, None, None, None, None, None, None, None, None

    return docid, oldfile, newfile, tables, images, outpdf, outxl, logsin, logsout, createdby


def get_files(oldfile, newfile, input_path):

    fpath, oldfname = path_leaf(oldfile)
    _, newfname = path_leaf(newfile)

    print_log(["File Names", oldfname, newfname])

    print_log("Old Version PDF File: " + oldfname + " Download from Blob")
    download_fromblob(containername, oldfile, os.path.join(input_path, oldfname), PUBLISH_ENV)
    print_log("New Version PDF File: " + newfname + " Download from Blob")
    download_fromblob(containername, newfile, os.path.join(input_path, newfname), PUBLISH_ENV)

    return oldfname, newfname, fpath


def compare_doc(pdf_1, pdf_2, inp_path, out_path, tables, images, docid, fpath, outpdf, outxl, begin_time, logsin, logsout, createdby):
    
    xcept = False
    texts = True
    dtstr = datetime.now().strftime("%d-%b-%Y")

    update_status(cnxn, 2, 25, docid, qry_update_proc)

    # commons.py

    # shutil.copy(xlmtemplate+xlmtmpl, out_path+xlmname)
    ExcelOutput = xlsxwriter.Workbook(out_path+xlmname)
    ExcelOutput.add_vba_project(vba_bin)
    ExcelOutput = excel_metadata(ExcelOutput, pdf_1, pdf_2, createdby, dtstr)

    if texts:
        try:
            print_log("Text Comparison Job Started..")
            ExcelOutput = document_difference.begin_compare(pdf_1, pdf_2, outpdf, outxl, ExcelOutput)
            print_log("Text Comparison Job Completed..")
            print_log(["Text Comparison Time", end_time(begin_time)])
            update_status(cnxn, 2, 45, docid, qry_update_proc)
        except Exception as ex:
            xcept = move_logs('Text', ex, logsin, logsout)
            pass

    if images and not xcept:
        try:
            print_log("Image Comparison Job Started..")
            check_file(pdf_1, pdf_2, inp_path, out_path)
            ExcelOutput = image_comparison.img_module(pdf_1, pdf_2, out_path, outpdf, outxl, ExcelOutput)
            print_log("Image Comparison Job Completed..")
            print_log(["Image Comparison Time", end_time(begin_time)])
            update_status(cnxn, 2, 60, docid, qry_update_proc)
        except Exception as ex:
            xcept = move_logs('Image', ex, logsin, logsout)
            pass
    
    if tables and not xcept:
        try:
            print_log("Table Comparison Job Started..")
            check_file(pdf_1, pdf_2, inp_path, out_path)
            ExcelOutput = table_module(pdf_1, pdf_2, out_path, outpdf, outxl, ExcelOutput)
            print_log("Table Comparison Job Completed..")
            print_log(["Table Comparison Time", end_time(begin_time)])
            update_status(cnxn, 2, 85, docid, qry_update_proc)
        except Exception as ex:
            xcept = move_logs('Table', ex, logsin, logsout)
            pass

    ExcelOutput.close()
    print_log("Uploading files to blob storage..")
    
    if texts or images or tables:
        if outxl:
            upload_toblob(containername, fpath+'/Result_'+xlmname, out_path+xlmname, PUBLISH_ENV)
        if outpdf:
            add_legends(out_path+pdf_1)
            add_legends(out_path+pdf_2)
            upload_toblob(containername, fpath+'/Result_'+pdf_1, out_path+pdf_1, PUBLISH_ENV)
            upload_toblob(containername, fpath+'/Result_'+pdf_2, out_path+pdf_2, PUBLISH_ENV)

    print_log("Files upload completed..")
    update_status(cnxn, 2, 95, docid, qry_update_proc)

    print_log("Comparison Job Completed..")
    print_log(["Comparison Job Time", end_time(begin_time)])
    print_log("Process completed..")

    return xcept


def comparedocjob():
    max_time = 30
    while True:
        time.sleep(30 - max_time)
        t0 = time.time()

        docid, oldfile, newfile, tables, images, outpdf, outxl, logsin, logsout, createdby = poll_db(qry_chk_new, cnxn)
        ErrorPath, pdf_1 = path_leaf(oldfile)
        _, pdf_2 = path_leaf(newfile)

        try:
            if docid:
                update_status(cnxn, 2, 10, docid, qry_update_proc)

                begin_time = datetime.now()
                print_log(["Comparison Start Time", begin_time.strftime("%Y.%m.%d %H:%M:%S")])

                pdf_1, pdf_2, fpath = get_files(oldfile, newfile, inp_path)
                xcept = compare_doc(pdf_1, pdf_2, inp_path, out_path, tables, images, docid, fpath, outpdf, outxl, begin_time, logsin, logsout, createdby)

                update_status(cnxn, 3, 100, docid, qry_update_proc)
                update_results(out_path, outpdf, outxl, cnxn, fpath, docid, qry_update_path)
                notify_user(createdby, pdf_1, pdf_2, tables, images, outpdf, outxl, 'Completed')

                if xcept:
                    _ = move_logs('CompareDoc Tasks', 'NA', logsin, logsout)
                    upload_toblob(containername, fpath+'/Result_'+logfilename, logsout, PUBLISH_ENV)
                    notify_user(createdby, pdf_1, pdf_2, tables, images, outpdf, outxl, 'Completed With Errors')

            max_time = min(30, time.time() - t0)
            print_log(["Seconds to Wait", '{0:.2f}'.format(30 - max_time)])
            print_log('_'*88)

        except Exception as ex:
            print_log([ex])
            print_log(["CompareDoc Exception", ex])

            if ErrorPath:
                _ = move_logs('CompareDoc', 'NA', logsin, logsout)
                upload_toblob(containername, ErrorPath+'/Result_'+logfilename, logsout, PUBLISH_ENV)
                update_results(out_path, outpdf, outxl, cnxn, ErrorPath, docid, qry_update_path)

            update_status(cnxn, 3, 100, docid, qry_update_proc) # 3 = if error, generate error log
            notify_user(createdby, pdf_1, pdf_2, tables, images, outpdf, outxl, 'Completed With Errors')
            max_time = min(30, time.time() - t0)
            print_log(["Seconds to Wait", '{0:.2f}'.format(30 - max_time)])
            pass

        # else:
        #     pass

if __name__ == '__main__':
    comparedocjob()

