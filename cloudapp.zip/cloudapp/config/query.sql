update StandardComparisonDetails
  set   FileStatus = 1,
        Percentage = 5
        --FileCurrentVersion = 'testuser5@ul.com/637583869848433336/ETSI EN 300 330-1 v1_7_1.pdf',
        --FileNewVersion = 'testuser5@ul.com/637583869848433336/ETSI EN 300 330-1 V1_8_1.pdf'
where DocComparisonID =6078;


delete from StandardDocumentResultsFiles 
where DocComparisonID = 50 or DocComparisonID = 51;

delete from StandardDocumentResultsFiles 
where DocComparisonID in (50, 62, 63, 65, 56, 64, 66, 68);