#!/bin/sh
. /app/ulab/bin/activate
gunicorn -b 0.0.0.0:3000 app:app --timeout=600 --log-level=info --worker-class=gevent --threads=4
# python /app/comparedoc.py
# python /app/app.py
