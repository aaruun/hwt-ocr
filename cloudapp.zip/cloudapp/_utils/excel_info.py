import xlsxwriter
from _utils.utils import vba_bin

def excel_metadata(ExcelOutput, old_version_name, new_version_name, username, comparison_date):
    workbook = ExcelOutput

    data_format = workbook.add_format({
        'bold': 1,
        'border': 1,
        'align': 'center',
        'valign': 'vcenter',
        'text_wrap': True})
    
    main_header= workbook.add_format({
        'bold': 1,
        'border': 1,
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 14,
        'font_color': 'yellow',
        'fg_color': 'black'})

    sub_header = workbook.add_format({
        'bold' : 1,
        'border': 1,
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 12,
        'fg_color': 'yellow'})

    normal_text = workbook.add_format({
        'border': 1,
        'text_wrap': True})

    underline_text = workbook.add_format({
        'border': 1,
        'underline': True,
        'text_wrap': True})

    red_text = workbook.add_format({
        'border': 1,
        'font_color': 'red',
        'text_wrap': True})
    # ------------------ INSTRUCTION TAB ---------------------------------------
    worksheet1 = workbook.add_worksheet('Instructions')
    # worksheet1.set_column_pixels(0, 0, 1000)
    # worksheet1.set_column('A:A', 150)
    worksheet1.merge_range('A1:P1', 'CTECH EMC-W Gloal Standard Comparison Gap and Impact Analysis', main_header)
    worksheet1.merge_range('A2:P2', '     •   The purpose of this document is to identify the changes between the most previous and most current version of a Standard.', normal_text)
    worksheet1.merge_range('A3:P3', '     •   This summary is then used to analyze the impact of the Standard changes to our current accredition scope and capabilities.', normal_text)
    worksheet1.merge_range('A4:P4', '     •   Instructions on how to complete the information requested on this form can be found below.', normal_text)
    worksheet1.merge_range('A5:P6', '     •   Global Owners consult with regional staff and GMA as needed to clarify national deviations that are issued concurrently with the main standard such as CB scheme standards.', normal_text)
    worksheet1.merge_range('A7:P8', '     •   If a revised standard assigned is inactive in your location, return the Gap Analysis to the Program Manager for further investigation and follow the \'New Standard\' vetting process.', normal_text)

    worksheet1.merge_range('A12:P12', 'ACTIONS for GLOBAL OWNER', sub_header)
    worksheet1.merge_range('A13:P13', '     (1)  Complete the analysis and document your findings in this form. Refer to instructions below.', normal_text)
    worksheet1.merge_range('A14:P14', '     (2)  The completed form is to be stored in the CTECH Global Operations SharePoint site.', normal_text)
    worksheet1.merge_range('A15:P15', '          CTECH EMC-W Standards Review Documents Folder', normal_text)
    worksheet1.merge_range('A16:P16', '          a.  In the SharePoint site, create a new Folder with the Standard number and new version (Example: EN330 328, version 2.2.2)', normal_text)
    worksheet1.merge_range('A17:P18', '          b.  Save this completed form in that folder using the following naming convention: "Comparison Gap Analysis_xxxx_mmyy" where "xxx" is the Standard & "mmyy" are the month and date of the Revision (Example: "Comparison Gap Analysis_EN320328 2.2.2-201907")', normal_text)
    worksheet1.merge_range('A19:P19', '     (3)  Create an entry for this Standard Comparison in the Standard Review Tracking spreadsheet.', normal_text)
    worksheet1.merge_range('A20:P20', '          a.  The spreadsheet is stored on the SharePoint site. ', normal_text)
    worksheet1.merge_range('A21:P21', '              CTECH EMC-W Standards Review Documents Folder', normal_text)
    worksheet1.merge_range('A22:P22', '          b.  Instructions on how to create the entry are provided in the spreadsheet.', normal_text)
    worksheet1.merge_range('A23:P24', '     (4)  Send an email to idenified Local Owners at all EMC-W laboratory locations with a link to the Comparison Summary document you just stored in SharePoint. These individuals will be responsible to review this Comparison Summary and determine the impact to current laboratory operations for their location.', normal_text)
    worksheet1.merge_range('A25:P25', '          a.  The names of the local owners can be found at the end of this form.', normal_text)
    worksheet1.merge_range('A26:P27', '          b.  After conducting an impact analysis based on this Comparison Summary, the local lab owner will need to record that the analysis has been completed on the "Standard Review Tracking" spreadsheet.', normal_text)
    worksheet1.merge_range('A28:P28', '     (5)  Be available to support the Local Owners if they have any questions or need clarification on the Comparison Summary document.', normal_text)
    worksheet1.merge_range('A29:P29', '     (6)  Typical TAT for these Reviews should be 5-10 Working Days. Inform the Program Manager if this is not possible.', red_text)
    worksheet1.merge_range('A31:P31', 'From instructions to the Global Owner responsible for the Standard Review.', underline_text)
    worksheet1.merge_range('A33:P33', '1)  Enter new version of standard with the exact standard number and version (include date of issue).', normal_text)
    worksheet1.merge_range('A34:P34', '2)  Enter current/older version of standard with the exact standard number and version (include date of issue).', normal_text)
    worksheet1.merge_range('A35:P35', '3)  Enter your name (First and Last) in the Reviewed By field.', normal_text)
    worksheet1.merge_range('A36:P36', '4)  Enter the date you finished preparing the document.', normal_text)
    worksheet1.merge_range('A37:P37', '5)  Notes can be used for things like "the comparison doesn\'t include certain section of the standard"…etc.', normal_text)
    worksheet1.merge_range('A38:P38', '6)  Ref item # column is just a sequential number 1,2,3,…etc.', normal_text)
    worksheet1.merge_range('A39:P39', '7)  Document in the "New Edition/Version" column any changes or new requirements.', normal_text)
    worksheet1.merge_range('A40:P40', '8)  Document in the "Current Standard/Edition Version" column the current requirements.', normal_text)
    worksheet1.merge_range('A41:P41', '9)  Potential Impact Column is used to document possible actions needed to be considered by local offices.', normal_text)
    worksheet1.merge_range('A42:P42', '    a.  There are set responses from a drop down list to be used or a single free cell if the options aren\'t suitable.', normal_text)
    worksheet1.merge_range('A43:P43', '           List to be supplied by Frank Ibrahim.', normal_text)

    worksheet1.merge_range('A9:P11',' ')
    worksheet1.merge_range('A30:P30',' ')
    worksheet1.merge_range('A32:P32',' ')
    worksheet1.merge_range('A44:P46',' ')
    # ------------------ COLOR LEGEND -----------------------------------------
    clr_sub_hed =  workbook.add_format({'bold' : 2,
                                    'border': 1,
                                    'align': 'center',
                                    'valign': 'vcenter',
                                    'font_size': 12,
                                    'font_color': '#000000'
                                    })
    text_del = workbook.add_format({'bold' : 1,
                                    'border': 1,
                                    'align': 'center',
                                    'valign': 'vcenter',
                                    'font_size': 12,
                                    'bg_color': '#FF0000',
                                    'font_color': '#000000'
                                    # 'font_color': '#FF0000'
                                    })

    text_add = workbook.add_format({'bold' : 1,
                                    'border': 1,
                                    'align': 'center',
                                    'valign': 'vcenter',
                                    'font_size': 12,
                                    'bg_color': '#0000FF',
                                    'font_color': '#000000'
                                    # 'font_color' : '#0000FF'
                                    })

    img_add = workbook.add_format({'bold' : 1,
                                    'border': 1,
                                    'align': 'center',
                                    'valign': 'vcenter',
                                    'font_size': 12,
                                    'bg_color': '#FF0000',
                                    'font_color': '#000000'
                                    # 'font_color' : '#FF0000'
                                    })

    tabl_del = workbook.add_format({'bold' : 1,
                                    'border': 1,
                                    'align': 'center',
                                    'valign': 'vcenter',
                                    'font_size': 12,
                                    'bg_color': '#F24D32',
                                    'font_color': '#000000'
                                    # 'font_color' : '#FF0000'
                                    })

    tabl_add = workbook.add_format({'bold' : 1,
                                    'border': 1,
                                    'align': 'center',
                                    'valign': 'vcenter',
                                    'font_size': 12,
                                    'bg_color': '#00CCFF',
                                    #66CCFF
                                    'font_color': '#000000'
                                    # 'font_color' : '#FF0000'
                                    })

    tabl_update = workbook.add_format({'bold' : 1,
                                    'border': 1,
                                    'align': 'center',
                                    'valign': 'vcenter',
                                    'font_size': 12,
                                    'bg_color': '#FFCC66',
                                    'font_color': '#000000'
                                    # 'font_color' : '#FF0000'
                                    })

    worksheet1.merge_range('A47:P47', 'Excel Color Legend', data_format)

    worksheet1.merge_range('A48:E48', 'Module Name (Highlight Type)', clr_sub_hed)
    worksheet1.merge_range('F48:J48', 'Color Used', clr_sub_hed)
    worksheet1.merge_range('K48:P48', 'Style Type', clr_sub_hed)

    worksheet1.merge_range('A49:E49', 'Text (removed)', normal_text)
    worksheet1.merge_range('F49:J49', '', text_del)
    worksheet1.merge_range('K49:P49', 'Word color', normal_text)

    worksheet1.merge_range('A50:E50', 'Text (added)', normal_text)
    worksheet1.merge_range('F50:J50', '', text_add)
    worksheet1.merge_range('K50:P50', 'Word color', normal_text)

    worksheet1.merge_range('A51:E51', 'Image (updated)', normal_text)
    worksheet1.merge_range('F51:J51', '', img_add)
    worksheet1.merge_range('K51:P51', 'Rectangular boxes on image', normal_text)

    worksheet1.merge_range('A52:E52', 'Table (removed)', normal_text)
    worksheet1.merge_range('F52:J52', '', tabl_del)
    worksheet1.merge_range('K52:P52', 'Cell background', normal_text)

    worksheet1.merge_range('A53:E53', 'Table (added)', normal_text)
    worksheet1.merge_range('F53:J53', '', tabl_add)
    worksheet1.merge_range('K53:P53', 'Cell background', normal_text)

    worksheet1.merge_range('A54:E54', 'Table (updated)', normal_text)
    worksheet1.merge_range('F54:J54', '', tabl_update)
    worksheet1.merge_range('K54:P54', 'Cell background', normal_text)

    # ------------------ DATA TAB STATIC ENTRIES -------------------------------
    
    # workbook = ExcelOutput
    worksheet = workbook.add_worksheet('Data')


    worksheet.set_column('A:A', 25)
    worksheet.set_column('B:B', 30)
    worksheet.set_column('C:C', 15)
    worksheet.set_column('D:D', 30)
    worksheet.set_column('E:E', 15)

    worksheet.merge_range('A1:A2', "Subject", data_format)
    worksheet.merge_range('B1:F1', 'Comparison of', data_format)
    worksheet.write('B2', 'New or Revised Standard Version', data_format)
    worksheet.merge_range("C2:C3", 'Compared to', data_format)
    worksheet.write('D2', 'Current Version of Standard', data_format)
    worksheet.merge_range('E2:E3', 'Needed to maintain TCB?', data_format)

    worksheet.write('A5', 'Reviewed by:', data_format)
    worksheet.write('B5', 'Date:', data_format)
    worksheet.merge_range('C5:D5', 'Validated by:', data_format)
    worksheet.merge_range('E5:F5', 'Date:', data_format)

    worksheet.merge_range('A7:F7', '*Validation may be waived if standard comparison completed by qualified "L4 - Standard Reviewer".', data_format)
    # ------------------ DATA TAB DYNAMIC ENTRIES -------------------------------
    worksheet.write('B3', new_version_name, data_format)
    worksheet.write('D3', old_version_name, data_format)
    worksheet.write('A6', username, data_format)
    worksheet.write('B6', comparison_date, data_format)

    # ------------------ DATA TAB MANUAL ENTRIES -------------------------------
    worksheet.write('A3','', data_format)
    worksheet.merge_range('C6:D6','', data_format)
    worksheet.merge_range('E6:F6','', data_format)
    worksheet.merge_range('F2:F3', '', data_format)

    return workbook
    