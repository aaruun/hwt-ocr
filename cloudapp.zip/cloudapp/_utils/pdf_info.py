#Import Libraries
import os
import fitz

blue   = (0.0, 0.0, 1.0)
red    = (1.0, 0.0, 0.0)
yellow = (1.0, 1.0, 0.0)
orange = (1.0, 0.6, 0.0)
# green = (0.0, 1.0, 0.0)


def fitz_overwrite(Path, doc):
    if os.path.isfile(Path):
        docbytes = doc.tobytes()
        doc.close()
        os.remove(Path)
        doc = fitz.open("pdf", docbytes)
        doc.save(Path)
        doc.close()
    print("Overwrite Success", Path)


def add_legends(Path):

    fitzobj = fitz.open(Path)

    t1 = 'COMPARE DOC OUTPUT: COLOUR LEGENDS\n\n\n'
    t2 = 'TABLES:\nRed - Removed.\nBlue - Added.\n'
    t3 = 'Yellow - Moved/Updated/Intra-Section Movement.\n\n\n'
    t4 = 'IMAGES:\nRed Box(Surrounding Image) - Removed.\nRed Boxes(Inside Image Area)'
    t5 = ' - Differences in Image.\nBlue Box(Surrounding Image) - Added.\n'
    t6 = 'Yellow Box - Moved.\nOrange Box - Intra-Section Movement.\n\n\n'
    t7 = 'TEXT:\nRed - Removed.\nBlue - Added.\nYellow - Moved/Updated.\n'
    t8 = 'Orange - Intra-Section Movement.'

    t = t1+t2+t3+t4+t5+t6+t7+t8
    fitzobj.insert_page(0, text=t, fontsize=11, width=595, height=842, fontname="helv", color=None)

    Red = {"stroke": red,"fill": red}
    Yellow = {"stroke": yellow,"fill": yellow}
    Blue = {"stroke": blue,"fill": blue}
    Orange = {"stroke": orange,"fill": orange}

    page_content = fitzobj[0]
    for word in ['Red','Blue','Yellow','Orange']:
        coord = page_content.searchFor(word)
        # print(word, coord)
        for ins in coord:
            annot = page_content.addRectAnnot(ins)
            if word == 'Red':
                color = Red
            elif word == 'Blue':
                color = Blue
            elif word == 'Yellow':
                color = Yellow
            else:
                color = Orange
            annot.setColors(color)
            annot.setOpacity(0.3)
            annot.update()
    
    fitz_overwrite(Path, fitzobj)
