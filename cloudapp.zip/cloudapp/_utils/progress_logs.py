import logging
from datetime import datetime
from _utils.utils import pro_path, out_path, logpath
import os
import shutil
import xlsxwriter

# dtstr = datetime.now().strftime("%Y.%m.%d")

def print_log(vars_):
    if isinstance(vars_, str):
        print(vars_)
        logging.info((vars_))
    else:
        str_log = ' : '.join(map(str, vars_))
        logging.info(str_log)
        print((str_log))


def move_logs(module, ex, logsin, logsout):
    print_log([module + " Exception", ex])

    workbook = xlsxwriter.Workbook(logsout)
    worksheet = workbook.add_worksheet('ErrorLog')

    with open(logsin, 'r') as f:
        content = f.readlines()

        for row_num, data in enumerate(content):
            worksheet.write(row_num, 0, data)

    workbook.close()
    # shutil.move(logsin, logsout)
    return True


def stopp_log(log):
    # log = logging.getLogger()
    for hdle in log.handlers[:]:
        # if isinstance(hdle,logging.FileHandler):
        hdle.close()
        log.removeHandler(hdle)
        
    return print('Logfile reset successful..')


def logg_config(filename):

    log = logging.getLogger()
    for hdle in log.handlers[:]:
        # if isinstance(hdle,logging.FileHandler):
        hdle.close()
        log.removeHandler(hdle)

    fh = logging.FileHandler(filename, 'a')
    # fmt = logging.Formatter('%(asctime)s %(message)s')
    # %(module)s %(funcName)s %(lineno)d
    fmt = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
    fh.setFormatter(fmt)

    # ch = logging.StreamHandler()
    # ch.setLevel(logging.INFO)
    # ch.setFormatter(fmt)

    # log.addHandler(ch)
    log.addHandler(fh)
    log.setLevel(logging.INFO)

    # logging.root.handlers = []
    # logging.basicConfig(
    #     level=logging.INFO,
    #     format='%(asctime)s [%(levelname)s] %(message)s',
    #     handlers=[
    #         logging.FileHandler(filename),
    #         logging.StreamHandler()
    #     ]
    # )

