#!/usr/local/bin python

from pathlib import Path
import os
# import string
import configparser as cfg
# import logging
# from datetime import datetime
import shutil

def get_project_root():
    return Path(__file__).parent.parent
    # return Path(__file__).parent

project_location = get_project_root()
print(project_location)

mode = 'FOLDER'
config_dir = 'config'

poppler_bin = '/usr/bin'
wkhtml_path = "C:\\Program Files\\wkhtmltopdf\\bin"

# pdf2html_util = 'pdftohtml'
# arg_html_util = '-c -s -i'
# pdf2text_util = 'pdftotext'
# arg_text_util = '-layout'

# pdf2xml_util = 'pdftohtml'
# arg_xml_util = '-xml -i' #-i for ignoring images
# pdf2png_util = 'pdftoppm'
# arg_pdf2png_util = '-png'

# data_dir = 'wip_files'
# in_dir = '_blob_input'

# html_dir = 'html'
# txt_dir = 'text'
# images_dir = 'images'
# xml_dir = 'xml'
# pdf2pngs_dir = 'png'
index_ = 'index.ini'

# image module threshold
score_thresh = 0.73
hl_thresh = 0.80

# CONFIGURATION FILE READING
configParser = cfg.RawConfigParser()   
configFilePath = os.path.join(project_location, config_dir, index_)
print("configFilePath: ", configFilePath)
configParser.read(configFilePath)
text_suffix = configParser.get('IDENTIFICATION_TEXT', 'suffix')
text_prefix = configParser.get('IDENTIFICATION_TEXT', 'prefix')
extr_1 = configParser.get('EXTRACTION_TEXT', 'extraction_for_text_file_')
text_extr = configParser.get('EXTRACTION_TEXT', 'extraction')

line_sep = '___NNN___'
regexsep = '###'

pro_path = project_location
processing = 'jobs'

inp_path = os.path.join(pro_path, processing, '_blob_input/') #blob storage download path
out_path = os.path.join(pro_path, processing, '_blob_output/') #blob storage upload path
st_01 = os.path.join(pro_path, processing, "_text/step_01/")
st_02 = os.path.join(pro_path, processing, "_text/step_02/")
st_03 = os.path.join(pro_path, processing, "_text/step_03/")
im_path1 = os.path.join(pro_path, processing, "_image/")
# im_path2 = os.path.join(pro_path, processing, "_image/step2/")
# im_path3 = os.path.join(pro_path, processing, "_image/step3/")
tbl_path1 = os.path.join(pro_path, processing, "_table/html/")
tbl_path2 = os.path.join(pro_path, processing, "_table/image/")
tbl_path3 = os.path.join(pro_path, processing, "_table/pdfs/")
logpath = os.path.join(pro_path, processing, "_logs/")

# xlmtemplate = os.path.join(pro_path, processing, "excel_template/")
xlmname = "Excel_Output.xlsm"
# xlmtmpl = "excel_temp.xlsm"
logfilename = "ErrorLog.xlsx"

vba_bin = os.path.join(pro_path, processing, "vba_bin/vbaProject.bin")
# crop_path= im_path2

def reset_dirs(reqdirs, to_exclude):

    for _dirs in reqdirs:
        if _dirs not in to_exclude:
            if os.path.isdir(_dirs):
                shutil.rmtree(_dirs)
            os.makedirs(_dirs)

    return print("Reset dir successful..")

to_exclude = [inp_path]
reqdirs = [inp_path, out_path, st_01, st_02, st_03, im_path1, tbl_path1, tbl_path2, tbl_path3, logpath]
# im_path2, im_path3, 

