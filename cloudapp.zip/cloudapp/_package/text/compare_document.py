#!/usr/local/bin python

import os
import re
from gensim import corpora, models, similarities
from difflib import Differ
import pandas as pd
import numpy as np
import xlsxwriter
import itertools
import operator
from nltk import wordpunct_tokenize
from _utils.utils import inp_path, st_02, st_03
# from _package.mod.tsim.TextSimilarity import TextSimDFs
from _utils.progress_logs import print_log


n_list = []
o_list = []
flag_lst = []
score_list  =[]


def fname_noext(fname_ext):
    fname = os.path.splitext(fname_ext)[0]
    return fname


def raw_txt(a):
    # a = str(a).lower()
    a = str(a).title()
    a = re.sub(r'[^A-Za-z0-9.\s]+', '', a)
    return(a)

    
class compare_document():

    def __init__(self, pro_path, pdf_1_name, pdf_2_name):
        self.project_root = pro_path
        # self.file_list = [pdf_1_name, pdf_2_name]
        # pdf_1_name = pdf_1_name #str(os.path.basename(self.file_list[0]))
        # pdf_2_name = pdf_2_name #str(os.path.basename(self.file_list[1]))

        # inp_path = inp_path
     
        # self.intermediate_st02 = st_02 
        # self.intermediate_st03 = st_03 
    
        self.pdf_document_1 = os.path.join(inp_path,pdf_1_name)
        self.pdf_document_2 = os.path.join(inp_path,pdf_2_name)

        self.table_comparison_output = '_'.join(['Table_Compared.xlsx'])
        # self.table_comparison_output = '_'.join(['Table_Compared.xlsx'])

        self.document1 = fname_noext(str(os.path.basename(pdf_1_name)))
        self.document2 = fname_noext(str(os.path.basename(pdf_2_name)))

        self.final_table_score = os.path.join(st_03, self.table_comparison_output)
        # self.final_table_score = os.path.join(st_03, '_Table_Compared.xlsx')
        # self.final_table_score = os.path.join(st_03, self.table_comparison_output)

        self.older_file  = pd.read_excel(os.path.join(st_02,'{}/{}_TOC_tokenized.xlsx'.format(self.document1, self.document1)), engine='openpyxl', dtype='O')
        self.recent_file = pd.read_excel(os.path.join(st_02,'{}/{}_TOC_tokenized.xlsx'.format(self.document2, self.document2)), engine='openpyxl', dtype='O')
               
               
########Code to remove similer data and put it in new file Start########################################
        COLS = [
            'Oldfile_IDX',
            'Oldfile_SectionName', 
            'Oldfile_SENTENCES', 
            'Oldfile_Counter', 
            'Recentfile_IDX',
            'Recentfile_SectionName', 
            'Recentfile_SENTENCES', 
            'Recentfile_Counter', 
            'Flag']
        cdf = pd.DataFrame(columns=(COLS))
        olf_file_index = []
        self.recent_file_index = []
        checked = []
        self.recent_file['TmpHEAD_VAL'] = self.recent_file['HEAD_VAL'].apply(lambda x: raw_txt(x))
        for i, row in self.older_file.iterrows():
            old_IDX = row['HEAD_IDX']
            old_Section_name = row['HEAD_VAL']
            old_Section_name = raw_txt(old_Section_name)
            old_Section_data = row['SENTENCES']
            old_Counter_no = row['Counter']
            array1 = np.where((self.recent_file['TmpHEAD_VAL'] == old_Section_name) & ((self.recent_file['HEAD_IDX'] == old_IDX) | (self.recent_file['HEAD_IDX'] == '')))
            if len(array1[0]) > 0 :
                for index in array1[0]:
                    recent_section_data = self.recent_file['SENTENCES'][index]
                    recent_IDX = self.recent_file['HEAD_IDX'][index]
                    recent_Section_name = self.recent_file['HEAD_VAL'][index]
                    recent_Counter_no = self.recent_file['Counter'][index]
                    if str(old_Section_data).lower() == str(recent_section_data).lower() and index not in checked:
                        old_IDX = str(old_IDX)
                        recent_IDX = str(recent_IDX)
                        values_to_add = {
                            'Oldfile_IDX': old_IDX, 
                            'Oldfile_SectionName': old_Section_name, 
                            'Oldfile_SENTENCES': old_Section_data, 
                            'Oldfile_Counter': old_Counter_no, 
                            'Recentfile_IDX': recent_IDX, 
                            'Recentfile_SectionName': recent_Section_name, 
                            'Recentfile_SENTENCES': recent_section_data, 
                            'Recentfile_Counter': recent_Counter_no, 
                            'Flag' : "blank"
                            }
                        row_to_add = pd.Series(values_to_add)
                        cdf = cdf.append(row_to_add, ignore_index=True)
                        olf_file_index.append(i)
                        self.recent_file_index.append(index)
                        checked.append(index)
                        break
        self.recent_file.drop(['TmpHEAD_VAL'], axis = 1, inplace=True)

        grouped = cdf.groupby(['Oldfile_SectionName', 'Oldfile_IDX'])
        for _, group in grouped:
            st = 0
            for i, row in group.iterrows():
                OC = row['Oldfile_Counter']
                RC = row['Recentfile_Counter']
                if RC == 1:
                    cdf.at[i,'Flag'] = "Match"
                    RC1 = RC
                elif OC == RC:
                    cdf.at[i,'Flag'] = "Match"
                    RC1 = RC
                elif st == 0:
                    cdf.at[i,'Flag'] = "Intra Section Moved"
                    st = st+1
                    RC1 = RC
                else:
                    if RC-RC1 > 1:
                        cdf.at[i,'Flag'] = "Intra Section Moved"
                    else:
                        cdf.at[i,'Flag'] = "Match"
                    RC1 = RC 
                        
        self.older_file = self.older_file.drop(labels=olf_file_index, axis=0)
        self.recent_file = self.recent_file.drop(labels=self.recent_file_index, axis=0)
        cdf.to_excel(self.final_table_score)
########Code to remove similer data and put it in new file End##########################################  

        self.new_v_old = os.path.join(st_03,'new_v_old.xlsx')
        self.old_v_new = os.path.join(st_03,'old_v_new.xlsx')

        self.compared_without_highlighting = os.path.join(st_03,'comparison.xlsx')
        self.final_highlighted = os.path.join(st_03,'comparison_highlighted.xlsx')

        
    def create_dir(self, path_):
        if not os.path.exists(path_):
            os.makedirs(path_)

            
    def new2oldtext_comparison(self):
        mlst = list(self.recent_file['SENTENCES'])
        mlst = [x for x in mlst if type(x)==str]
        texts = list(self.older_file['SENTENCES'])
        texts_1 = [x for x in texts if type(x)==str]
        # texts_2 = [jieba.lcut(text) for text in texts_1]
        texts_2 = [wordpunct_tokenize(text) for text in texts_1]
        print_log("Building Dictionary..")
        dictionary = corpora.Dictionary(texts_2)
        feature_cnt = len(dictionary.token2id)
        print_log("Building Corpus..")
        corpus = [dictionary.doc2bow(text) for text in texts_2]
        tfidf = models.TfidfModel(corpus) 
        index = similarities.SparseMatrixSimilarity(tfidf[corpus], num_features = feature_cnt)
        ridx_lst = []
        rval_lst = []
        rsntnce_lst = []
        rcount_lst = []
        oidx_lst = []
        oval_lst = []
        osntnce_lst = []
        ocount_lst = []
        score_lst = []
        print_log("Calculating Similarity..")
        x = 0
        for keyword in mlst:
            if x % 250 == 0:
                print_log(["Completed", x, "of", len(mlst)])
            x = x+1
            tmp_ = {}
            # kw_vector = dictionary.doc2bow(jieba.lcut(keyword))
            kw_vector = dictionary.doc2bow(wordpunct_tokenize(keyword))
            sim = index[tfidf[kw_vector]]
            for i in range(len(sim)):
                tmp_[i]=sim[i]
            val_1 = self.recent_file[self.recent_file['SENTENCES']==keyword]
            val_1_idx = list(val_1['HEAD_IDX'])[0]
            val_1_val = list(val_1['HEAD_VAL'])[0]
            val_1_count = list(val_1['Counter'])[0]
            score_ = max(tmp_.items(), key=operator.itemgetter(1))[1]
            if score_>0:
                new_dict = {}
                for k, v in tmp_.items():
                    new_dict.setdefault(v, []).append(k)
                key_lst = new_dict[score_]
                for key_ in key_lst:
                    matched_text = texts_1[key_]
                    val_2 = self.older_file[self.older_file['SENTENCES']==matched_text]
                    val_2_idx = list(val_2['HEAD_IDX'])[0]
                    val_2_val = list(val_2['HEAD_VAL'])[0]
                    val_2_count = list(val_2['Counter'])[0]
                    ridx_lst.append(val_1_idx)
                    rval_lst.append(val_1_val)
                    rsntnce_lst.append(keyword)
                    rcount_lst.append(val_1_count)
                    oidx_lst.append(val_2_idx)
                    oval_lst.append(val_2_val)
                    osntnce_lst.append(matched_text)
                    ocount_lst.append(val_2_count)
                    score_lst.append(score_)    
        flag_lst = ['NEW2OLD']*len(score_lst)
        r_v_o_df = pd.DataFrame({'RECENT_FILE_IDX':ridx_lst,\
                                 'RECENT_FILE_VAL':rval_lst,\
                                 'RECENT_FILE_TEXT':rsntnce_lst,\
                                 'RECENT_FILE_Counter':rcount_lst,\
                                 'OLD_FILE_IDX':oidx_lst,\
                                 'OLD_FILE_VAL':oval_lst,\
                                 'OLD_FILE_TEXT':osntnce_lst,\
                                 'OLD_FILE_Counter':ocount_lst,\
                                 'MATCH_SCORE':score_lst,\
                                 'FLAG':flag_lst})
        r_v_o_df.to_excel(self.new_v_old, engine='openpyxl')
        print_log("Recent vs Old comparison file created..")
        return r_v_o_df
        
        
    def old2newtext_comparison(self):
        mlst = list(self.older_file['SENTENCES'])
        mlst = [x for x in mlst if type(x)==str]
        texts = list(self.recent_file['SENTENCES'])
        texts_1 = [x for x in texts if type(x)==str]
        # texts_2 = [jieba.lcut(text) for text in texts_1]
        texts_2 = [wordpunct_tokenize(text) for text in texts_1]
        print_log("Building Dictionary..")
        dictionary = corpora.Dictionary(texts_2)
        feature_cnt = len(dictionary.token2id)
        print_log("Building Corpus..")
        corpus = [dictionary.doc2bow(text) for text in texts_2]
        tfidf = models.TfidfModel(corpus) 
        index = similarities.SparseMatrixSimilarity(tfidf[corpus], num_features = feature_cnt)
        ridx_lst = []
        rval_lst = []
        rsntnce_lst = []
        rcount_lst = []
        oidx_lst = []
        oval_lst = []
        osntnce_lst = []
        ocount_lst = []
        score_lst = []
        print_log("Calculating Similarity..")
        x = 0
        for keyword in mlst:
            if x % 250 == 0:
                print_log(["Completed", x, "of", len(mlst)])
            x = x+1
            tmp_ = {}
            # kw_vector = dictionary.doc2bow(jieba.lcut(keyword))
            kw_vector = dictionary.doc2bow(wordpunct_tokenize(keyword))
            sim = index[tfidf[kw_vector]]
            for i in range(len(sim)):
                tmp_[i]=sim[i]
            val_1 = self.older_file[self.older_file['SENTENCES']==keyword]
            val_1_idx = list(val_1['HEAD_IDX'])[0]
            val_1_val = list(val_1['HEAD_VAL'])[0]
            val_1_count = list(val_1['Counter'])[0]
            score_ = max(tmp_.items(), key=operator.itemgetter(1))[1]
            if score_>0:
                new_dict = {}
                for k, v in tmp_.items():
                    new_dict.setdefault(v, []).append(k)
                key_lst = new_dict[score_]
                for key_ in key_lst:
                    matched_text = texts_1[key_]
                    val_2 = self.recent_file[self.recent_file['SENTENCES']==matched_text]
                    val_2_idx = list(val_2['HEAD_IDX'])[0]
                    val_2_val = list(val_2['HEAD_VAL'])[0]
                    val_2_count = list(val_2['Counter'])[0]
                    ridx_lst.append(val_2_idx)
                    rval_lst.append(val_2_val)
                    rcount_lst.append(val_2_count)
                    rsntnce_lst.append(matched_text)
                    oidx_lst.append(val_1_idx)
                    oval_lst.append(val_1_val)
                    ocount_lst.append(val_1_count)
                    osntnce_lst.append(keyword)
                    score_lst.append(score_)     
        flag_lst = ['OLD2NEW']*len(score_lst)
        o_v_r_df = pd.DataFrame({'OLD_FILE_IDX':oidx_lst,\
                                 'OLD_FILE_VAL':oval_lst,\
                                 'OLD_FILE_TEXT':osntnce_lst,\
                                 'OLD_FILE_Counter':ocount_lst,\
                                 'RECENT_FILE_IDX':ridx_lst,\
                                 'RECENT_FILE_VAL':rval_lst,\
                                 'RECENT_FILE_TEXT':rsntnce_lst,\
                                 'RECENT_FILE_Counter':rcount_lst,\
                                 'MATCH_SCORE':score_lst,\
                                 'FLAG':flag_lst})
        o_v_r_df.to_excel(self.old_v_new, engine='openpyxl')
        print_log("Old vs Recent comparison file created..")
        return o_v_r_df
        
        
    def display_differ(str1, str2, red, blue, bold):
        txt1 = str1.split()
        txt2 = str2.split()
        dif = Differ()
        dlst = list(dif.compare(txt2, txt1))
        tlist = []
        bluelist = []
        redlist = []
        for val in dlst:
            bluelist.append(bold)
            bluelist.append('#-#')
            redlist.append(bold)
            redlist.append('#-#')
            if re.findall('^\-', val):
                val = re.sub('^\-','',val)
                tlist.append(red)
                tlist.append(val)
                redlist.append(val)
            elif re.findall('^\+', val):
                val = re.sub('^\+','',val)
                tlist.append(blue)
                tlist.append(val)
                bluelist.append(val)
            elif re.findall('^\s\s*', val):
                tlist.append(bold)
                tlist.append(val)
                tlist.append(' ')
            else:
                pass
        return tlist, bluelist, redlist
        
        
    def filter_lsit(lst_):
        flat=list(itertools.chain.from_iterable(lst_))
        flat = [x for x in flat if x]
        return flat

                
    def duplicates(lst, item):
        return [i for i, x in enumerate(lst) if x == item]
        
        
    def int_xl_output_new(self, ExcelOutput):
        print_log(self.compared_without_highlighting)
        df = pd.read_excel(self.compared_without_highlighting, engine='openpyxl', dtype='O')
        df = df.replace('NaN', np.nan)
        df = df.fillna(' ')
        df["OLD_FILE_IDX"] = df["OLD_FILE_IDX"].map(str).map(str.strip)
        df["RECENT_FILE_IDX"] = df["RECENT_FILE_IDX"].map(str).map(str.strip)
        df['OLD_FILE_VAL'] = df['OLD_FILE_IDX'].str.cat(df['OLD_FILE_VAL'], sep =" ")
        df['RECENT_FILE_VAL'] = df['RECENT_FILE_IDX'].str.cat(df['RECENT_FILE_VAL'], sep =" ")
        df = df.drop(['RECENT_FILE_IDX','OLD_FILE_IDX'], axis = 1)
        df = df[[
            'OLD_FILE_VAL',
            'OLD_FILE_TEXT',
            'OLD_FILE_Counter',
            'RECENT_FILE_VAL', 
            'RECENT_FILE_TEXT',
            'RECENT_FILE_Counter',
            'MATCH_SCORE',
            'FLAG']]

        print_log("Comparison file opened for Excel Generation..")    
        rows_to_drop = []
        for i, row in df.iterrows():
            OSec_name = row['OLD_FILE_VAL']
            OSec_name = raw_txt(OSec_name)
            RSec_name = row['RECENT_FILE_VAL']
            RSec_name = raw_txt(RSec_name)
            otext = row['OLD_FILE_TEXT']
            rtext = row['RECENT_FILE_TEXT']
            score = row['MATCH_SCORE']
            ocount = row['OLD_FILE_Counter']
            rcount = row['RECENT_FILE_Counter']
            flag = row['FLAG']
            flag = flag.strip()
            patrn = re.compile(r'\s+')
            OSec_name = (patrn.sub(" ", OSec_name))
            RSec_name = (patrn.sub(" ", RSec_name))
            RSec_name = RSec_name.strip()
            OSec_name = OSec_name.strip()
            df.at[i,'OLD_FILE_VAL'] = OSec_name
            df.at[i,'RECENT_FILE_VAL'] = RSec_name
            if OSec_name == RSec_name and score >= 0.99:
                rows_to_drop.append(i)
            elif OSec_name == RSec_name and 0.6 <= score < 0.99:
                df.at[i,'FLAG'] = "Updated"
            elif OSec_name != RSec_name and 0.99 > score >= 0.7:  
                df.at[i,'FLAG'] = "Moved & Updated"
            elif OSec_name != RSec_name and score >= 0.99:
                df.at[i,'FLAG'] = "Moved"
            elif OSec_name == RSec_name and score < 0.6 and flag == 'NEW2OLD':
                values_to_add2 = {
                    'OLD_FILE_VAL': 'NA', 
                    'OLD_FILE_TEXT': 'NA', 
                    'OLD_FILE_Counter': 0, 
                    'RECENT_FILE_VAL': RSec_name, 
                    'RECENT_FILE_TEXT': rtext, 
                    'RECENT_FILE_Counter': rcount, 
                    'MATCH_SCORE': score, 
                    'FLAG': 'Added'}
                row_to_add2 = pd.Series(values_to_add2)
                df = df.append(row_to_add2, ignore_index=True)
                rows_to_drop.append(i)
            elif OSec_name == RSec_name and score < 0.6 and flag == 'OLD2NEW':
                values_to_add1 = {
                    'OLD_FILE_VAL': OSec_name, 
                    'OLD_FILE_TEXT': otext, 
                    'OLD_FILE_Counter': ocount, 
                    'RECENT_FILE_VAL': 'NA', 
                    'RECENT_FILE_TEXT': 'NA', 
                    'RECENT_FILE_Counter': 0, 
                    'MATCH_SCORE': score, 
                    'FLAG': 'Removed'}
                row_to_add1 = pd.Series(values_to_add1)
                df = df.append(row_to_add1, ignore_index=True)
                rows_to_drop.append(i)
            elif OSec_name != RSec_name and score < 0.7 and flag == 'NEW2OLD':
                values_to_add2 = {
                    'OLD_FILE_VAL': 'NA', 
                    'OLD_FILE_TEXT': 'NA', 
                    'OLD_FILE_Counter': 0, 
                    'RECENT_FILE_VAL': RSec_name, 
                    'RECENT_FILE_TEXT': rtext, 
                    'RECENT_FILE_Counter': rcount, 
                    'MATCH_SCORE': score, 
                    'FLAG': 'Added'}
                row_to_add2 = pd.Series(values_to_add2)                
                df = df.append(row_to_add2, ignore_index=True)
                rows_to_drop.append(i)       
            elif OSec_name != RSec_name and score < 0.7 and flag == 'OLD2NEW':
                values_to_add1 = {
                    'OLD_FILE_VAL': OSec_name, 
                    'OLD_FILE_TEXT': otext, 
                    'OLD_FILE_Counter': ocount, 
                    'RECENT_FILE_VAL': 'NA', 
                    'RECENT_FILE_TEXT': 'NA', 
                    'RECENT_FILE_Counter': 0, 
                    'MATCH_SCORE': score, 
                    'FLAG': 'Removed'}
                row_to_add1 = pd.Series(values_to_add1)
                df = df.append(row_to_add1, ignore_index=True)
                rows_to_drop.append(i)

        print_log("Flag allocation completed per matching scores..")
        df = df.drop(labels=rows_to_drop, axis=0)

        df = df.rename(columns={
                        'OLD_FILE_VAL' : 'OldFile_Section', 
                        'OLD_FILE_TEXT' : 'OldFile_Section_Data', 
                        'RECENT_FILE_VAL' : 'NewFile_Section', 
                        'RECENT_FILE_TEXT' : 'NewFile_Section_Data',
                        })
        df = df.drop(['MATCH_SCORE'], axis = 1)

        Comp_df = pd.read_excel(self.final_table_score, engine='openpyxl', dtype='O')
        for col in Comp_df.columns:
            if col == "Unnamed: 0": Comp_df = Comp_df.drop([col], axis = 1)
        Comp_df.drop(Comp_df[Comp_df['Flag'] == 'Match'].index, inplace = True)
        Comp_df["Oldfile_IDX"] = Comp_df["Oldfile_IDX"].map(str).map(str.strip)
        Comp_df["Recentfile_IDX"] = Comp_df["Recentfile_IDX"].map(str).map(str.strip)
        Comp_df['Oldfile_SectionName'] = Comp_df['Oldfile_IDX'].str.cat(Comp_df['Oldfile_SectionName'], sep =" ")
        Comp_df['Recentfile_SectionName'] = Comp_df['Recentfile_IDX'].str.cat(Comp_df['Recentfile_SectionName'], sep =" ")
        Comp_df = Comp_df.drop(['Recentfile_IDX','Oldfile_IDX' ], axis = 1)
        Comp_df = Comp_df.rename(columns={
                'Oldfile_SectionName' : 'OldFile_Section', 
                'Oldfile_SENTENCES' : 'OldFile_Section_Data', 
                'Recentfile_SectionName' : 'NewFile_Section', 
                'Recentfile_SENTENCES' : 'NewFile_Section_Data',
                'Oldfile_Counter' : 'OLD_FILE_Counter',
                'Recentfile_Counter' : 'RECENT_FILE_Counter',
                'Flag' : 'FLAG'
                })    
        df = df.append(Comp_df, ignore_index=True)
                        
        df = df.sort_values(by=['OldFile_Section', 'OLD_FILE_Counter' ])
        df = df.drop(['RECENT_FILE_Counter', 'OLD_FILE_Counter'], axis = 1)
        df.drop_duplicates(subset=['OldFile_Section', 'OldFile_Section_Data', 'NewFile_Section', 'NewFile_Section_Data'],keep = 'first', inplace = True)
        
        workbook = xlsxwriter.Workbook(os.path.join(st_03,'comparison_highlighted.xlsx'))
        #out_workbook = xlsxwriter.Workbook(os.path.join(out_path, 'Text.xlsx'))
        # out_workbook = xlsxwriter.Workbook(os.path.join(out_path, self.document1 + self.document2 +'Text.xlsx'))
        
        out_workbook = ExcelOutput

        print_log("Process started for highlighting differencs in excel..")

        worksheet = workbook.add_worksheet()
        out_worksheet = out_workbook.add_worksheet('Text')
        bold = workbook.add_format({'bold': True})
        red = workbook.add_format({'color': 'red'})
        blue = workbook.add_format({'color': 'blue'})
        bold = out_workbook.add_format({'bold': True})
        red = out_workbook.add_format({'color': 'red'})
        blue = out_workbook.add_format({'color': 'blue'})
        
        comparison_text = []
        RECENT_FILE_IDXlst = []
        RECENT_FILE_TEXTlst = []
        OLD_FILE_IDXlst = []
        OLD_FILE_TEXT_lst = []
        FLAG_lst = []
        for_highlight_blue = []
        for_highlight_red = []

        for _, row in df.iterrows():
            rfid = row['NewFile_Section']
            #rfval = row['RECENT_FILE_VAL']
            rftext = str(row['NewFile_Section_Data'])
            ofid = row['OldFile_Section']
            #ofval = row['OLD_FILE_VAL']
            oftext = str(row['OldFile_Section_Data'])
            #s_core = row['MATCH_SCORE']
            flg = row['FLAG']
            segments, highlight_list_blue, highlight_list_red = compare_document.display_differ(rftext, oftext, red, blue, bold)
            comparison_text.append(segments)
            for_highlight_blue.append(highlight_list_blue)
            for_highlight_red.append(highlight_list_red)
            RECENT_FILE_IDXlst.append(rfid)
            RECENT_FILE_TEXTlst.append(rftext)
            OLD_FILE_IDXlst.append(ofid)
            OLD_FILE_TEXT_lst.append(oftext)
            FLAG_lst.append(flg)
            
        st = 0
        temp_1 = [bold,'OldFile_Section','_']
        temp_2 = [bold,'OldFile_Section_Data','_']
        temp_3 = [bold,'NewFile_Section','_']
        temp_4 = [bold,'NewFile_Section_Data','_']
        temp_5 = [bold,'FLAG','_']
        temp_6 = [bold,'Compared_data','_']
        temp_7 = [bold,'HIGHLIGHT','_blue']
        temp_8 = [bold,'HIGHLIGHT','_red']

        worksheet.write_rich_string(0,0, *temp_1)
        worksheet.write_rich_string(0,1, *temp_2)
        worksheet.write_rich_string(0,2, *temp_3)
        worksheet.write_rich_string(0,3, *temp_4)
        worksheet.write_rich_string(0,4, *temp_5)
        worksheet.write_rich_string(0,5, *temp_6)
        worksheet.write_rich_string(0,6, *temp_7)
        worksheet.write_rich_string(0,7, *temp_8)

        out_worksheet.write_rich_string(0,0, *temp_1)
        out_worksheet.write_rich_string(0,1, *temp_2)
        out_worksheet.write_rich_string(0,2, *temp_3)
        out_worksheet.write_rich_string(0,3, *temp_4)
        out_worksheet.write_rich_string(0,4, *temp_5)
        out_worksheet.write_rich_string(0,5, *temp_6)
        
        for I, J, K, L, M, N, O, P in zip(OLD_FILE_IDXlst,
                                    OLD_FILE_TEXT_lst,
                                    RECENT_FILE_IDXlst,
                                    RECENT_FILE_TEXTlst,
                                    FLAG_lst,
                                    comparison_text,
                                    for_highlight_blue,
                                    for_highlight_red):
            st+=1

            worksheet.write_rich_string(st,0, *[bold,I,' '])
            worksheet.write_rich_string(st,1, *[bold,J,' '])
            worksheet.write_rich_string(st,2, *[bold,K,' '])
            worksheet.write_rich_string(st,3, *[bold,L,' '])
            worksheet.write_rich_string(st,4, *[bold,M,' '])
            worksheet.write_rich_string(st,5, *N)

            out_worksheet.write_rich_string(st,0, *[bold,I,' '])
            out_worksheet.write_rich_string(st,1, *[bold,J,' '])
            out_worksheet.write_rich_string(st,2, *[bold,K,' '])
            out_worksheet.write_rich_string(st,3, *[bold,L,' '])
            out_worksheet.write_rich_string(st,4, *[bold,M,' '])
            out_worksheet.write_rich_string(st,5, *N)

            if len(O)<=2:
                worksheet.write_rich_string(st,6, *[bold,'AS_IS_STRING',' '])
            else:
                O.append(' ')
                worksheet.write_rich_string(st,6, *O)

            if len(P)<=2:
                worksheet.write_rich_string(st,7, *[bold,'AS_IS_STRING',' '])
            else:
                P.append(' ')
                worksheet.write_rich_string(st,7, *P)
        
        format = out_workbook.add_format({'text_wrap': True,
                                            'align': 'left',
                                            'valign': 'top'})
        # out_worksheet.set_column('A:F', None, format)

        out_worksheet.set_column_pixels(0, 0, 250, format)
        out_worksheet.set_column_pixels(1, 1, 500, format)
        out_worksheet.set_column_pixels(2, 2, 250, format)
        out_worksheet.set_column_pixels(3, 3, 500, format)
        out_worksheet.set_column_pixels(4, 4, 100, format)
        out_worksheet.set_column_pixels(5, 5, 500, format)
        
        out_worksheet.freeze_panes(1, 1)
        out_worksheet.autofilter('A1:F1')

        # out_workbook.close() #to be able to use by other modules
        workbook.close()
        print_log("Highlighted excel generation complete..")
        return out_workbook
        
        
def main(pro_path, pdf_1_name, pdf_2_name, outxl, ExcelOutput):
    obj = compare_document(pro_path, pdf_1_name, pdf_2_name)
    print_log(["Project Location: ", pro_path])

    ################################################
    # oldbase = fname_noext(str(os.path.basename(pdf_1_name)))
    # f_old = os.path.join(st_02, oldbase)
    # oldxl = os.path.join(f_old, oldbase +'_TOC_tokenized.xlsx')

    # newbase = fname_noext(str(os.path.basename(pdf_2_name)))
    # f_new = os.path.join(st_02, newbase)
    # newxl = os.path.join(f_new, newbase +'_TOC_tokenized.xlsx')
    
    # r_v_o_df, o_v_r_df = TextSimDFs(oldxl, newxl)
    ################################################

    ####New2Old xlsx generation
    r_v_o_df = obj.new2oldtext_comparison()
    print_log("New to Old Text comparison file generated..")
    
    ####Old2New xlsx generation
    o_v_r_df = obj.old2newtext_comparison()
    print_log("Old to New Text comparison file generated..")
    # print(r_v_o_df.columns)
    # print(o_v_r_df.columns)
    F_DF = pd.concat([r_v_o_df, o_v_r_df], sort=False).drop_duplicates(\
                    subset=['RECENT_FILE_IDX','RECENT_FILE_VAL','RECENT_FILE_TEXT',\
                            'OLD_FILE_IDX','OLD_FILE_VAL','OLD_FILE_TEXT',\
                            'MATCH_SCORE'], keep="first").reset_index(drop=True)
    F_DF = F_DF.replace('NaN', np.nan).fillna(' ')
    # F_DF = F_DF.fillna(' ')
    F_DF.to_excel(obj.compared_without_highlighting, engine='openpyxl')

    ####Comparison xlsx generation
    # obj.magic_xlsx_writing(F_DF)
    # print("Comparison Excel Generated..")
    
    ExcelOutputD = obj.int_xl_output_new(ExcelOutput)
    # if outxl:
    #     ExcelOutputD = obj.int_xl_output_new(ExcelOutput)
    #     return ExcelOutputD
    # else:
        # return ExcelOutput

    return ExcelOutputD
