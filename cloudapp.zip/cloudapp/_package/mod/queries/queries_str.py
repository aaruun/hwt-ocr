
qry_chk_new = '''
  select DocComparisonID, 
        FileCurrentVersion, 
        FileNewVersion, 
        IsIncludeTable,
        IsIncludeImages,
        IsOutputPDF,
        IsOutputExcel,
        IsStandardComparison,
        FileStatus,
        FileProcessCancelled,
        TotalPages,
        PagesCompleted,
        Percentage,
        ChangesFound,
        CreatedBy
  from StandardComparisonDetails
  where FileStatus = 1
  order by UpdatedDate;
'''

# and (CreatedBy = 'testuser2@ul.com' or CreatedBy = 'testuser6@ul.com')
#  and (CreatedBy = 'testuser5@ul.com' or CreatedBy = 'testuser6@ul.com')

qry_update_proc = '''
  update StandardComparisonDetails
  set   FileStatus = @status,
        Percentage = @percent
  where DocComparisonID = @id;
'''


qry_update_path = '''
  insert into StandardDocumentResultsFiles(
      DocComparisonId, 
      FileName, 
      ServerPath,
      CreatedDate)
  values (@id, '@filename', 'NA', '@datetime');
'''


qry_update_metrics = '''
  update StandardComparisonDetails
  set   FileName = "@filename"
  where DocComparisonID = @id;
'''
