#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import numpy as np
# import jieba
# import openpyxl
from gensim.models import Word2Vec
from gensim.corpora import Dictionary
from gensim.similarities import SoftCosineSimilarity, SparseTermSimilarityMatrix, WordEmbeddingSimilarityIndex
# import os
from nltk import wordpunct_tokenize
from tqdm import tqdm

tqdm.pandas()

docsim_index = None
dictionary = None
corpus_list_token = None

def get_textCompareData(newxl, oldxl):
    dfnew = pd.read_excel(newxl, engine='openpyxl')
    dfold = pd.read_excel(oldxl, engine='openpyxl')

    dfnew.insert(loc=0, column='SLnew', value=np.arange(len(dfnew)))
    dfold.insert(loc=0, column='SLold', value=np.arange(len(dfold)))

    # dfnew['TOKENS'] = dfnew['SENTENCES'].dropna().str.lower().apply(lambda x: jieba.lcut(x))
    # dfold['TOKENS'] = dfold['SENTENCES'].dropna().str.lower().apply(lambda x: jieba.lcut(x))

    dfnew['TOKENS'] = dfnew['SENTENCES'].dropna().astype(str).str.lower().progress_apply(wordpunct_tokenize)
    dfold['TOKENS'] = dfold['SENTENCES'].dropna().astype(str).str.lower().progress_apply(wordpunct_tokenize)

    dflstnew = dfnew[['SLnew', 'TOKENS']].dropna()
    dflstold = dfold[['SLold', 'TOKENS']].dropna()
    
    return dfnew, dfold, dflstnew, dflstold


def get_bestmatch(slno, sentence, flag):
    sims = docsim_index[dictionary.doc2bow(sentence)]
    result_list = [corpus_list_token[i] for i in [a[0] for a in sims]]
    score_list = [a[1] for a in sims]
    results = [(each[0],' '.join(each[1])) for each in result_list]
    for score, result in zip(score_list, results):
        # print ('{:.5f} : {}\n'.format(score, result[0]))
        score, result, flag = score, result[0], flag
    return score, result, flag


def train_simModel(tokensList, slTokenMapping):

    model = Word2Vec(vector_size=300, window=5, min_count=1, workers=4, alpha=0.025, epochs=30)
    model.build_vocab(tokensList)
    model.train(tokensList, total_examples=model.corpus_count, epochs=model.epochs)

    corpus_list_token = slTokenMapping #.to_numpy()
    # query_list_token = dflstnew.to_numpy()

    termsim_index = WordEmbeddingSimilarityIndex(model.wv)
    dictionary = Dictionary(corpus_list_token[:,1])
    bow_corpus = [(document[0], dictionary.doc2bow(document[1])) for document in corpus_list_token]
    bow_corpus = np.array(bow_corpus, dtype=object)

    # , tfidf, nonzero_limit=100 not required if using bow_corpus instead of tfidf
    similarity_matrix = SparseTermSimilarityMatrix(termsim_index, dictionary) #, tfidf, nonzero_limit=100)
    docsim_index = SoftCosineSimilarity(bow_corpus[:,1].tolist(), similarity_matrix, num_best=1)

    return docsim_index, dictionary, corpus_list_token
    

def get_comparisonDFs(dfnew, dfold, dflstnew, dflstold): 
    # # ### New To Old Comparison
    global docsim_index, dictionary, corpus_list_token
    docsim_index, dictionary, corpus_list_token = train_simModel(dflstold['TOKENS'], dflstold.to_numpy())
    sim_func_r_v_o = lambda x: pd.Series(get_bestmatch(x['SLnew'], x['TOKENS'], 'NEW2OLD'))
    # we get SlNo for old file using function
    dflstnew[['MATCH_SCORE', 'SLold', 'FLAG']] = dflstnew.progress_apply(sim_func_r_v_o, axis=1)

    #merge dfs based on sl no.
    #drop tokens, drop SL columns, rename _x as OLD, rename _y as NEW
    r_v_o_df = dflstnew.merge(dfold, on=['SLold']).merge(dfnew, on=['SLnew'])
    cols = [col for col in r_v_o_df.columns if col.startswith('TOKENS') or col.startswith('SL')]
    r_v_o_df.drop(cols, axis=1, inplace=True)

    rencols_r_v_o = {'HEAD_IDX_x':'OLD_FILE_IDX',
               'HEAD_VAL_x':'OLD_FILE_VAL',
               'SENTENCES_x':'OLD_FILE_TEXT',
               'HEAD_IDX_y':'RECENT_FILE_IDX',
               'HEAD_VAL_y':'RECENT_FILE_VAL',
               'SENTENCES_y':'RECENT_FILE_TEXT'}
    r_v_o_df.rename(columns=rencols_r_v_o, inplace=True)
    r_v_o_df.to_excel('new_v_old.xlsx', engine='openpyxl')


    # # ### Old To New Comparison
    docsim_index, dictionary, corpus_list_token = None, None, None
    docsim_index, dictionary, corpus_list_token = train_simModel(dflstnew['TOKENS'], dflstnew.to_numpy())
    sim_func_o_v_r = lambda x: pd.Series(get_bestmatch(x['SLold'], x['TOKENS'], 'OLD2NEW'))
    # we get SlNo for new file using function
    dflstold[['MATCH_SCORE', 'SLnew', 'FLAG']] = dflstold.progress_apply(sim_func_o_v_r, axis=1)

    #merge dfs based on sl no.
    #drop tokens, drop SL columns, rename _x as NEW, rename _y as OLD
    o_v_r_df = dflstold.merge(dfnew, on=['SLnew']).merge(dfold, on=['SLold'])
    cols = [col for col in o_v_r_df.columns if col.startswith('TOKENS') or col.startswith('SL')]
    o_v_r_df.drop(cols, axis=1, inplace=True)

    rencols_o_v_r = {'HEAD_IDX_x':'RECENT_FILE_IDX',
               'HEAD_VAL_x':'RECENT_FILE_VAL',
               'SENTENCES_x':'RECENT_FILE_TEXT',
               'HEAD_IDX_y':'OLD_FILE_IDX',
               'HEAD_VAL_y':'OLD_FILE_VAL',
               'SENTENCES_y':'OLD_FILE_TEXT'}
    o_v_r_df.rename(columns=rencols_o_v_r, inplace=True)
    o_v_r_df.to_excel('old_v_new.xlsx', engine='openpyxl')
    
    return r_v_o_df, o_v_r_df


def TextSimDFs(newxl, oldxl):

    dfnew, dfold, dflstnew, dflstold = get_textCompareData(newxl, oldxl)
    r_v_o_df, o_v_r_df = get_comparisonDFs(dfnew, dfold, dflstnew, dflstold)

    return r_v_o_df, o_v_r_df

