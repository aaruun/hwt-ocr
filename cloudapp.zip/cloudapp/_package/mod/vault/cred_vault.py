import os
# import cmd
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential

keyVaultName = os.environ["KEY_VAULT_NAME"]
KVUri = f"https://{keyVaultName}.vault.azure.net"

credential = DefaultAzureCredential()
client = SecretClient(vault_url=KVUri, credential=credential)

print(f"Retrieving secrets from {keyVaultName}.")

sendgridapikey = client.get_secret('SendGridAPIKey').value

server = client.get_secret('DBServerQA').value
database = client.get_secret('DBDatabaseQA').value
username = client.get_secret('DBUserNameQA').value
password = client.get_secret('DBPasswordQA').value
containername = client.get_secret('BlobContainerName').value
blbconnectstr = client.get_secret('BlobConnStrQA').value

# server = client.get_secret('ProdDBServer').value
# database = client.get_secret('ProdDBName').value
# username = client.get_secret('ProdDBUserID').value
# password = client.get_secret('ulsqladmin').value
# containername = client.get_secret('BlobContainerName').value
# blbconnectstr = client.get_secret('BlobStorageConnStr').value


# poller = client.begin_delete_secret(secretName)
# deleted_secret = poller.result()
