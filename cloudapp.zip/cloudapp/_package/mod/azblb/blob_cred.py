
connect_str = ""
keys = ""

# setx AZURE_STORAGE_CONNECTION_STRING "<yourconnectionstring>" # Windows
# export AZURE_STORAGE_CONNECTION_STRING="<yourconnectionstring>" # Linux

# connect_str = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
