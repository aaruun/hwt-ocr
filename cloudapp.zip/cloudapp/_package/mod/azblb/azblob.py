import os, uuid
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, __version__
# from _package.mod.azblb.blob_cred import connect_str, keys
from _package.mod.vault.cred_vault import blbconnectstr


def upload_toblob(container_name, local_file_name, upload_file_path, PUBLISH_ENV):
    try:
        # connect_str, _ = creds(PUBLISH_ENV)
        blob_service_client = BlobServiceClient.from_connection_string(blbconnectstr)

        blob_client = blob_service_client.get_blob_client(container=container_name, blob=local_file_name)

        print("Uploading to Azure Storage as blob: " + local_file_name)
        with open(upload_file_path, "rb") as data:
            blob_client.upload_blob(data)

        print("Done")

    except Exception as ex:
        print('Exception:')
        print(ex)


def download_fromblob(container_name, local_file_name, download_file_path, PUBLISH_ENV):
    try:
        # connect_str, _ = creds(PUBLISH_ENV)
        blob_service_client = BlobServiceClient.from_connection_string(blbconnectstr)

        # for file in files:
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=local_file_name)

        # Download the blob to a local file
        print("Downloading blob to: " + download_file_path)

        with open(download_file_path, "wb") as download_file:
            download_file.write(blob_client.download_blob().readall())

        print("File " + local_file_name + " Downloaded..")

    except Exception as ex:
        print('Exception:')
        print(ex)
