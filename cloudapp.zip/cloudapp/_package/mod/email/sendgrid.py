
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import From, To, Subject, HtmlContent, Mail
# import urllib.request as urllib
import re
from _utils.utils import pro_path
from _package.mod.vault.cred_vault import sendgridapikey

template = os.path.join(pro_path, "_package/mod/email/email_template.html")

def notify_user(email, file1, file2, tables, images, outpdf, outxl, status):

    try:
        sg = SendGridAPIClient(sendgridapikey)
        from_email = From("no-reply-ul-CompareDoc <no-reply@mail.comparedoc.ul.com>")
        to_email = To(email)
        subject = Subject("Document Comparison for "+ file1 + " & " + file2 + " has " + status)

        HtmlFile = open(template, 'r', encoding='utf-8')
        source_code = HtmlFile.read()
        source_code = re.sub("####pdf1####", file1, source_code)
        source_code = re.sub("####pdf2####", file2, source_code)
        source_code = re.sub("####tables####", str(tables), source_code)
        source_code = re.sub("####images####", str(images), source_code)
        source_code = re.sub("####outpdf####", str(outpdf), source_code)
        source_code = re.sub("####outxl####", str(outxl), source_code)
        html_content = HtmlContent(source_code)

        message = Mail(from_email, to_email, subject, html_content)

        response = sg.send(message=message)
        print(response.status_code)
        print(response.body)
        print(response.headers)

    except Exception as ex:
        print(ex)
        # exit()
        pass

