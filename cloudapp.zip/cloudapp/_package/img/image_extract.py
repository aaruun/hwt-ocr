#!/usr/bin/env python
# coding: utf-8

# import sys
# sys.path.append('D:\\Projects\\UL\\AzureApp\\cloudapp\\')


import fitz
import re
import cv2
import numpy as np
from _package.tabl import table_identification as tbi
from _package.tabl.crop_imgs import crop_whitespace


def auto_canny(image, sigma=0.33):
    # sigma=0.99
    blurred = cv2.GaussianBlur(image, (5, 5), 0)
    v = np.median(blurred)
    lower = int(max(0, (1.0 - sigma) * v))
    upper = int(min(255, (1.0 + sigma) * v))
    edged = cv2.Canny(blurred, lower, upper)
    return edged


def remove_text(img):
    image = img.copy()
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    ret, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    close_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (11, 1))
    close = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, close_kernel, iterations=1)

    dilate_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 1))
    dilate = cv2.dilate(close, dilate_kernel, iterations=2)

    edged = auto_canny(dilate)

    _cnts = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    _cnts = _cnts[0] if len(_cnts) == 2 else _cnts[1]
    for c in _cnts:
        x,y,w,h = cv2.boundingRect(c)
        if h/w < 0.15 or (h < 15 and w < 50):
            cv2.rectangle(img, (x, y), (x + w, y + h), (255, 255, 255), -1)
    
    # image = img.copy()
    # gry = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # cnts = cv2.findContours(gry, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    # cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    # for c in cnts:
    #     x,y,w,h = cv2.boundingRect(c)
    #     if h < 15 and w < 50:
    #         cv2.rectangle(img, (x, y), (x + w, y + h), (255, 255, 255), -1)
    
    return img


def remove_whiteimgs(image):
    img = cv2.cvtColor(image, cv2.IMREAD_GRAYSCALE)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    #blur = cv2.GaussianBlur(gray_img,(11, 11),0)
    #ret3,th3 = cv2.threshold(blur,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    
    img = cv2.medianBlur(gray, 5)
    #ret,th1 = cv2.threshold(img, 180, 255, cv2.THRESH_BINARY)
    #th2 = cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,11,2)
    th3 = cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,11,2)

    diff = cv2.bitwise_not(th3)
    x = cv2.countNonZero(diff)
    
    # print("Count Non Zero", x)
    
    if x > 50:
        return True
    else:
        return False


def selectBBox(text):
    tc = False
    text0 = re.sub('[^A-Za-z]+', ' ', text).split()
    text1 = re.sub('[^A-Za-z.-]+', ' ', text).split()
    #text = [w for w in text]
    for w in text1:
        if len(w) > 20:
            tc = True
            break
    c = len(text0)
    # tc = len(text1)
    return c, tc, text0


def pix2np(pix):
    im = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, pix.n)
    im = np.ascontiguousarray(im[..., [2, 1, 0]])  # rgb to bgr
    return im


def derotate(a0, b0, a1, b1, prm):
    p0 = fitz.Point(a0, b0)
    p1 = fitz.Point(a1, b1)
    x0, y0 = p0*prm
    x1, y1 = p1*prm
    #print("Rotated Matrix", x0, y0, x1, y1)
    return x0, y0, x1, y1


def get_images(PDFFile, Step1Out, FileNoEx):
    
    doc = fitz.open(PDFFile)
    # boxes = []
    img_coords = []
    yThr = 40

    j = 0
    for page in doc:
        #print("Rotation", page.number, page.rotation)
        if j > 1: # to remove first 2 pages for image comparison
            blocks = page.get_text("blocks")
            tbl = [b for b in blocks if b[6] == 0]
            tbl.sort(key=lambda x: x[1])
            
            # print("Step1: ", j+1, tbl)
            
            selected = []
            # selected.append([j+1, 0.0, 0.0, 595.0, 100.0, "HeaderAdjustment"])
            selected.append([j+1, 0.0, 0.0, 595.0, 50.0, "HeaderAdjustment"])
            a0, b0, a1, b1 = None, None, None, None
            prev = None
            
            for i in range(len(tbl)):
                
                # get the current block coordinates
                x0, y0, x1, y1 = tbl[i][0], tbl[i][1], tbl[i][2], tbl[i][3]
                # print("Step2: i y0 y1: ", i, y0, y1, hgt, text[:5])
                
                if page.rotation != 0:
                    x0, y0, x1, y1 = derotate(x0, y0, x1, y1, page.rotation_matrix)
                
                c, tc, text = selectBBox(tbl[i][4])
                hgt = y1 - y0
                wdt = x1 - x0
                
                # select sentences with count of words > 2
                # if (c > 2 or (c > 0 and hgt > 14)) and hgt < wdt and x0 < 100: #or (x1 > 400 and hgt > 18)):
                if ((c > 2 or (c > 0 and hgt > 14)) and (hgt < wdt) and (x0 < 200 and c > 3)) or c > 50 or tc:
                    
                    # b0 is to check if new block after a gap or new page
                    if not b0:
                        # if new block or gap started, assign the current block values
                        a0, b0, a1, b1 = x0, y0, x1, y1
                        # print("Step3: i b0 b1: ", i, b0, b1)
                    
                    if not prev:
                        Y = y1
                        prev = y1
                        # print("Step4a: i Y y1: ", i, Y, y1)
                    else:
                        Y = y0 - prev
                        # print("Step4b: i Y prev y0: ", i, Y, prev, y0)
                        prev = y1
                    

                    if Y <= yThr:
                        a0, b0, a1, b1 = min(x0, a0), min(y0, b0), max(x1, a1), max(y1, b1)
                        # print("Step5: collated block: ", i, a0, b0, a1, b1)

                    elif Y > yThr:
                        # print("Step6: selected block: ", i, x0, y0, x1, y1)
                        selected.append([j+1, a0, b0, a1, b1, "CollatedBlock"])
                        selected.append([j+1, x0, y0, x1, y1, text[:5]])
                        
                        # if new block or gap started, assign the current block values
                        a0, b0, a1, b1 = x0, y0, x1, y1
                        
                else:
                    if b0:
                        selected.append([j+1, a0, b0, a1, b1, "CollatedBlock"])
                    # print("Step7: block not selected", y0, y1, hgt, text[:5])
            
            # to remove footer text but not needed
            # selected.append([j+1, 0.0, 700.0, 595.0, 842.0, "FooterAdjustment"]) 
            # needed for capturing images close to footer without end text block.
            selected.append([j+1, 0.0, 800.0, 595.0, 842.0, "FooterAdjustment"])
            
            newk = []
            for k in selected:
                if k not in newk:
                    newk.append(k)
                
            for i in range(len(newk)-1):

                coor1, xl, yt, xr, yb, text1 = newk[i]
                coor2, al, bt, ar, bb, text2 = newk[i+1]
                
                # print("Coor1:", coor1, xl, yt, xr, yb, text1)
                # print("Coor2:", coor2, al, bt, ar, bb, text2)
                
                #595 x 842 pixels, select images with gap bigger than 100
                if bt - yb > 100:
                    x, y, w, h = 0, int(yb), 595, int(bt - yb)
                    pix = page.get_pixmap()
                    im = pix2np(pix)

                    score = tbi.get_tables(im)
                    # print('Score', score)
                    if score < 10000: #not a table
                        image = im[y+5:y+h, x:x+w]
                        checkimg = image.copy()
                        img = remove_text(checkimg)
                        res = remove_whiteimgs(img)
                        if res:
                            cropped, wht, coords = crop_whitespace(image, 100, False)
                            a, b, e, f = coords
                            if wht:
                                cv2.imwrite(Step1Out+"/page_"+str(j+1)+"_"+str(i)+".png", cropped)
                                img_coords.append(["page_"+str(j+1)+"_"+str(i)+".png", [a, y+b, a+e, y+b+f]])
                
        j = j+1
    doc.close()
    return img_coords

# if __name__ == '__main__':
#     FolderPath = "D:/Projects/UL/AzureApp/cloudapp/jobs/"

#     PDFFile = FolderPath+"_blob_input/New_RSS Gen Issue 5_14.pdf"
#     Step1Out = FolderPath+"_image/step1/New_RSS Gen Issue 5_14/"
#     FileNoEx = "New_RSS Gen Issue 5_14"
#     # PDFFile = FolderPath+"_blob_input/Old_ETSI EN 300 330-1 v1.7.1.pdf"
#     # Step1Out = FolderPath+"_image/step1/Old_ETSI EN 300 330-1 v1.7.1/"
#     # FileNoEx = "Old_ETSI EN 300 330-1 v1.7.1"
#     get_images(PDFFile, Step1Out, FileNoEx)
