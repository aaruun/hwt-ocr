
#IMPORTS 
import os
import cv2
import numpy as np
from _package.mod.ssim.structural_similarity import structural_similarity
# import platform as pf
# import shutil
from io import BytesIO
import fitz
from _utils.utils import out_path, im_path1, vba_bin, st_02#, pro_path, crop_path im_path2, im_path3, 
from _package.img.image_extract import get_images #, remove_text, remove_whiteimgs derotate, pix2np, selectBBox
from _package.img.get_toc_coords import get_final_toc_coords
from _utils.progress_logs import print_log
from _utils.utils import score_thresh, hl_thresh

# polylines = 0

# im_path3f2 = im_path3
# num_ratio = 1
# den_ratio = 1

# im_path3 = im_path1

red = fitz.utils.getColor('red')
blue = fitz.utils.getColor('blue')
yellow = fitz.utils.getColor('yellow')
orange = fitz.utils.getColor('orange')


def fname_noext(fname_ext):
    # file_basename = os.path.basename(fname_ext)
    # filename_without_extension = file_basename.split('.')[0]
    fname = os.path.splitext(fname_ext)[0]
    return fname


def fitz_overwrite(Path, doc):
    if os.path.isfile(Path):
        docbytes = doc.tobytes()
        doc.close()
        os.remove(Path)
        doc = fitz.open("pdf", docbytes)
        doc.save(Path)
        doc.close()
    print("Overwrite Success", Path)


def calculate_scale(imwd, imht):
    bound_size = (400, 300)
    # check the image size without loading it into memory
    # im = Image.open(file_path)
    original_width, original_height = imwd, imht #im.size

    # calculate the resize factor, keeping original aspect and staying within boundary
    bound_width, bound_height = bound_size
    ratios = (float(bound_width) / original_width, float(bound_height) / original_height)
    return min(ratios)

    
def img_extract(File, FileNoEx, inppath):
    
    Step1Out= os.path.join(im_path1, FileNoEx)
    Step1In= os.path.join(inppath, File)
    
    if not (os.path.isdir(Step1Out)):
        os.makedirs(Step1Out)

    print_log(["Filenames with extension:", File])
    print_log(["Input Path:", Step1In])
   
    file_coords = get_images(Step1In, Step1Out, FileNoEx)

    return file_coords, Step1Out


def rsz(pct, img):
    ht, wd = img.shape[:2]
    rwd = int(wd * pct / 100)
    rht = int(ht * pct / 100)
    rsz_img = cv2.resize(img, (rwd, rht), interpolation = cv2.INTER_LANCZOS4) #best quality
    return rsz_img


def threshold_img(img):
    th3 = cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,11,2)
    return th3


def auto_canny(image, sigma=0.33):
    # sigma=0.99
    blurred = cv2.GaussianBlur(image, (5, 5), 0)
    v = np.median(blurred)
    lower = int(max(0, (1.0 - sigma) * v))
    upper = int(min(255, (1.0 + sigma) * v))
    edged = cv2.Canny(blurred, lower, upper)
    return edged


def line_remove(img):

    img0 = cv2.cvtColor(img, cv2.IMREAD_GRAYSCALE)
    dstimg = cv2.cvtColor(img0, cv2.COLOR_BGR2GRAY)
    
    edged = auto_canny(dstimg)
    
    thrs = edged
    hz = np.copy(thrs)
    vt = np.copy(thrs)

    rows,cols = thrs.shape
    hval = int(cols // 10)
    vval = int(rows // 10)

    hStr = cv2.getStructuringElement(cv2.MORPH_RECT, (hval,1))
    hz = cv2.erode(hz, hStr, (-1, -1))
    hz = cv2.dilate(hz, hStr, (-1, -1))

    vStr = cv2.getStructuringElement(cv2.MORPH_RECT, (1, vval))
    vt = cv2.erode(vt, vStr, (-1, -1))
    vt = cv2.dilate(vt, vStr, (-1, -1))
    
    masks = cv2.add(hz, vt)
    
    kernel = np.ones((5, 5), dtype = "uint8")
    dilated = cv2.dilate(masks, kernel,iterations=3)
    morphclose = cv2.morphologyEx(dilated, cv2.MORPH_CLOSE, kernel)
    
    result2 = cv2.dilate(edged, kernel, iterations=3)
    fin_img = cv2.subtract(result2, morphclose)
    
    return fin_img
    

def colour_change(img1, img2):
    b1, g1, r1 = cv2.split(img1)
    b2, g2, r2 = cv2.split(img2)
    b1 = b1 - 255
    g1 = g1 - 255
    r1 = r1 - 255
    b2 = b2 - 255
    g2 = g2 - 255
    r2 = r2 - 255
    
    blue = abs(np.count_nonzero(b1) - np.count_nonzero(b2))
    green = abs(np.count_nonzero(g1) - np.count_nonzero(g2))
    red = abs(np.count_nonzero(r1) - np.count_nonzero(r2))

    if not((blue <= 4000 and green <= 4000 and red <= 4000)or (blue == green and green == red )):
        return True
    else:
        return False


def img_compare(img_a, img_b, score_thresh):
    x, y = img_a.shape[:2]
    img_b0 = cv2.resize(img_b, (y,x), interpolation=cv2.INTER_LANCZOS4) #best quality
    
    #GET THE SCORE AND DIFFERENCE FOR IMAGES
    # tha = threshold_img(img_a)
    # thb = threshold_img(img_b)

    # edgea = auto_canny(tha)
    # edgeb = auto_canny(thb)

    score, diff = structural_similarity(img_a, img_b0, full=True, channel_axis=-1)

    if score > score_thresh:
        result = (diff * 255).astype("uint8")
    else:
        result = img_b0
    
    return score, result
    

def doContours(src):
    minContourSize = 50
    res = src.copy()
    countours, _ = cv2.findContours(src,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

    mask = np.zeros(src.shape[:2],dtype=np.uint8)

    for c in countours:
        if cv2.contourArea(c) > minContourSize:
            x,y,w,h  = cv2.boundingRect(c)
            cv2.rectangle(mask,(x,y),(x+w,y+h),(255),-1)

    # find the contours on the mask (with solid drawn shapes) and draw outline on input image
    countours, _ = cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    for c in countours:
        cv2.drawContours(res,[c],0,(255,255,255),2)
    # show image
    cv2.imshow("Contour",res)


def combine_bbox(boxes):
    # selected = []
    hld = None
    i = 0
    for i in range(len(boxes)):

        if i == 0:
            hld = boxes[0]

        if i > 0:

            ths = boxes[i]
            # nxt = boxes[i+1]
            x, y, w, h = ths
            a, b, c, d = hld

            hld = min(x, a), min(y, b), max(x+w, a+c), max(y+h, b+d)
        
        i += 1

    return hld


def display_diffs(img2, diff, img_coords1, img_coords2):

    thresh = cv2.threshold(diff, 127, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    mask = np.zeros(thresh.shape[:2], dtype=np.uint8)
    contours = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = contours[0] if len(contours) == 2 else contours[1]
    coords1, coords2, boxes = [], [], []

    x, y = diff.shape[:2]
    img_b = cv2.resize(img2, (y,x), interpolation=cv2.INTER_LANCZOS4) # best quality

    for c in contours:
        area = cv2.contourArea(c)
        if area > 800:
            x,y,w,h = cv2.boundingRect(c)
            cv2.rectangle(mask,(x,y),(x+w,y+h), (255, 255, 255), -1)
            boxes.append([x,y,w,h])

            _coords1 = (img_coords1[0]+x, img_coords1[1]+y, img_coords1[0]+x+w, img_coords1[1]+y+h)
            _coords2 = (img_coords2[0]+x, img_coords2[1]+y, img_coords2[0]+x+w, img_coords2[1]+y+h)

            coords1.append(_coords1)
            coords2.append(_coords2)

            # cv2.rectangle(img_b, (x, y), (x+w, y+h), (0,0,255), 1)

    # a, b, e, f = combine_bbox(boxes)
    # print("rectangle", a,b,e,f)
    # cv2.rectangle(img2, (a, b), (e-5, f), (0,0,255), 1)

    countours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in countours:
        cv2.drawContours(img_b, [c], 0, (0, 0, 255), 1)
    
    return img_b, coords1, coords2


def img_draw_single(img, img_name, sec_name, i, sec_column, column, flag, worksheet,  header_format):

    # img = cv2.imread(im_path3+FileNoEx+'/'+img_name)
    print_log(['Row', i])
    imgbuffer = cv2.imencode('.png', img)[1]
    imgdata = BytesIO(imgbuffer)

    imht, imwd = img.shape[:2]
    resize_scale1 = calculate_scale(imwd, imht)
    #Full path not required when passing image data in bytes format: XlOut+img1_name, just pass blank string for excel application
    worksheet.write(sec_column+str(i+2), sec_name, header_format)
    worksheet.insert_image(column+str(i+2), img_name, {'x_scale': resize_scale1, 'y_scale': resize_scale1, 'image_data': imgdata})

    worksheet.write_comment(column+str(i+2), img_name)
    worksheet.write('E'+str(i+2), flag, header_format)


def find_area(points):
    return (points[2]-points[0])*(points[3]-points[1])
    
    
def chck_sec_pos(sec_pos, img_pos):
    if sec_pos > img_pos:
        return False
    else:
        return True


def map_toc_imgs(df, file_coords):

    imgMapped = []

    for item in file_coords:
        img_name, pdf_img_coords = item

        img_pg_no = int(img_name.split("_")[1].split("_")[0])
        
        #Slicing dataframe if section and images are present in same page
        df_slice = df[df['PageNumber'] == img_pg_no]
        img_sec_mapped = 'NA'
        #If slice contains any value
        if df_slice['SectionNameOrig'].any():
            for i in range(0, len(df_slice)-1):
                #Check if image is present above or section name
                pos_flag = chck_sec_pos(df_slice['Coords'].iloc[i][0][3], pdf_img_coords[1])
                
                if pos_flag:
                    img_sec_mapped = df_slice['SectionNameOrig'].iloc[i]
                else:
                    break
        # If both images and section doesn't present in same page  
        # Get slice of sections that lies in previous pages of image       
        df_slice2 = df[df['PageNumber'] < img_pg_no]
        if img_sec_mapped == 'NA' and df_slice2['SectionNameOrig'].any():
            
            #Assign last section from slice to image 
            img_sec_mapped = df_slice2['SectionNameOrig'].iloc[-1]
        
        imgMapped.append([img_name, img_sec_mapped])
   
    return imgMapped


def get_img_nums_in_sec(img_with_sec):
    pdf_img_with_sec_imgnum= {}
    img_no = 0
    if img_with_sec:
        for i in range(len(img_with_sec)):
            if i > 0 and img_with_sec[i][1] == img_with_sec[i-1][1]:
                img_no += 1
            else:
                img_no = 0
            pdf_img_with_sec_imgnum[img_with_sec[i][0]] = [img_with_sec[i][1], img_no]

    return pdf_img_with_sec_imgnum


def img_draw_multi(name1, name2, img1, img2, sec1, sec2, status_flag, i, worksheet, header_format):

    img1buffer = cv2.imencode('.png', img1)[1]
    img1data = BytesIO(img1buffer)

    imht1, imwd1 = img1.shape[:2]
    resize_scale1 = calculate_scale(imwd1, imht1)
    worksheet.write('A'+str(i+2), sec1, header_format)
    worksheet.insert_image('B'+str(i+2), name1, {'x_scale': resize_scale1, 'y_scale': resize_scale1, 'image_data': img1data})
    worksheet.write_comment('B'+str(i+2), name1+"\n"+sec1)

    img2buffer = cv2.imencode('.png', img2)[1]
    img2data = BytesIO(img2buffer)

    imht2, imwd2 = img2.shape[:2]
    resize_scale2 = calculate_scale(imwd2, imht2)
    worksheet.write('C'+str(i+2), sec2, header_format)
    worksheet.insert_image('D'+str(i+2), name2, {'x_scale': resize_scale2, 'y_scale': resize_scale2, 'image_data': img2data})
    worksheet.write_comment('D'+str(i+2), name2+"\n"+sec2)
    worksheet.write('E'+str(i+2), status_flag, header_format)


def img_pdf_write(pdf_highlight, pdf, FileNoEx):
    if pdf_highlight:
        doc = fitz.open(pdf)
        for item in pdf_highlight:
            pg_no, coords, clr = item
            doc[pg_no].drawRect(tuple(coords), width=1, color = clr)
        f = os.path.join(out_path, FileNoEx+".pdf")
        # f = os.path.join(out_path, FileNoEx)
        # f = ".".join([f,"pdf"])
        print_log(["Output PDF File Saved at", f])
        fitz_overwrite(f, doc)


def pdf_img_process(pdf_img_name, FileNoEx):
    
    pdf_img = cv2.imread(os.path.join(im_path1, FileNoEx, pdf_img_name))

    _img = line_remove(pdf_img)
    if cv2.countNonZero(_img) > 100:
        print_log([pdf_img_name, FileNoEx, "SELECTED IMAGE", cv2.countNonZero(_img)])
        median = cv2.medianBlur(_img, 5)
        return median, pdf_img, pdf_img_name
    else:
        return None, None, None
 

def img_comparison(pdf1_img, pdf2_img, score_thresh):
    scores = []
    proc_scores = []
    matched_pdf1 = []
    matched_pdf2 = []

    i = 0
    for item1 in pdf1_img:
        _score, maxscore = 0, score_thresh
        med1, img1, name1 = item1
        for item2 in pdf2_img:
            med2, img2, name2 = item2
            _score, _diff= img_compare(med1, med2, score_thresh)

            if _score > maxscore:
                proc_scores.append([name1, name2, img1, img2, _score, _diff])
        print_log(["Comparison", i])
        i = i+1
    print_log(["Number of images matched", i])

    i = 0
    proc_scores.sort(key=lambda x: x[4], reverse=True)
    for scr in proc_scores:
        name1, name2, img1, img2, score, _diff = scr
        if name1 not in matched_pdf1 and name2 not in matched_pdf2:
            matched_pdf1.append(name1)
            matched_pdf2.append(name2)
            scores.append([name1, name2, img1, img2, score, _diff])
            print_log(["Processing Scores", i, '{0:.4f}'.format(score), name1, name2])
            i = i+1

    removed = []
    for item1 in pdf1_img:
        _, img1, name1 = item1
        if not name1 in matched_pdf1:
            removed.append([img1, name1])

    added = []
    for item2 in pdf2_img:
        _, img2, name2 = item2
        if not name2 in matched_pdf2:
            added.append([img2, name2])

    return scores, removed, added


def comparison_flags(scores, removed, added, worksheet, header_format, pdf1_coords, pdf2_coords, oldsection, newsection, outxl, hl_thresh):
    i = 0
    
    pdf1_highlight= []
    pdf2_highlight= []

    for item in scores:
        name1, name2, img1, img2, score, diff = item
        print_log([name1, name2, '{0:.4f}'.format(score), 'Row', i])

        # cv2.imshow("Image1", img1)
        # cv2.imshow("Image2", img2)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()

        img_coords1 = pdf1_coords[name1]
        img_coords2 = pdf2_coords[name2]

        pg_no1 = int(name1.split('_')[1])-1
        pg_no2 = int(name2.split('_')[1])-1

        sec1 = oldsection.get(name1)[0]
        imgno1 = oldsection.get(name1)[1]

        sec2 = newsection.get(name2)[0]
        imgno2 = newsection.get(name2)[1]

        samesection = sec1 == sec2
        samenumber = imgno1 == imgno2

        if score < hl_thresh:

            ddimg2, _coords1, _coords2 = display_diffs(img2, diff, img_coords1, img_coords2)
            img2 = ddimg2

            for coords in _coords1:
                pdf1_highlight.append([pg_no1, coords, red])
            for coords in _coords2:
                pdf2_highlight.append([pg_no2, coords, red]) 

            if samesection and samenumber:
                status_flag = "Updated " + str('{0:.4f}'.format(score))
            elif not samesection and (samenumber or not samenumber):
                status_flag = "Moved & Updated " + str('{0:.4f}'.format(score))
            elif samesection and not samenumber:
                status_flag = "Intra-section Moved & Updated " + str('{0:.4f}'.format(score))
                
        elif score >= hl_thresh and samesection and samenumber:
            clr_flag = colour_change(img1, img2)
            if clr_flag:
                status_flag = "Updated(color) " + str('{0:.4f}'.format(score))
            else:
                continue
                # status_flag = "No Change "+ str('{0:.4f}'.format(score))

        elif score >= hl_thresh and not samesection and (samenumber or not samenumber):
            status_flag = "Moved " + str('{0:.4f}'.format(score))
            pdf1_highlight.append([pg_no1, img_coords1, yellow])
            pdf2_highlight.append([pg_no2, img_coords2, yellow])

        elif score >= hl_thresh and samesection and not samenumber:
            status_flag = "Intra-section Moved " + str('{0:.4f}'.format(score))
            pdf1_highlight.append([pg_no1, img_coords2, orange])
            pdf2_highlight.append([pg_no2, img_coords2, orange])

        if outxl:
            worksheet.set_row_pixels(i+1, 300)
            img_draw_multi(name1, name2, img1, img2, sec1, sec2, status_flag, i, worksheet, header_format)
        
        i = i+1

    # x = len(scores)
    x = i
    for item in removed:
        img1, name1 = item
        sec1 = oldsection.get(name1)[0]
        img_coords = pdf1_coords.get(name1)
        pg_no = int(name1.split('_')[1])-1
        if outxl:
            worksheet.set_row_pixels(x+1, 300)
            img_draw_single(img1, name1, sec1, x, 'A', 'B', 'Removed', worksheet, header_format)
        pdf1_highlight.append([pg_no, img_coords, red])                                  
        x = x+1

    # y = len(scores)+len(removed)
    y = i + len(removed)
    for item in added:
        img2, name2 = item
        sec2 = newsection.get(name2)[0]
        img_coords = pdf2_coords.get(name2)
        pg_no = int(name2.split('_')[1])-1
        if outxl:
            worksheet.set_row_pixels(y+1, 300)
            img_draw_single(img2, name2, sec2, y, 'C', 'D', 'Added', worksheet, header_format)
        pdf2_highlight.append([pg_no, img_coords, blue])                                     
        y = y+1

    return pdf1_highlight, pdf2_highlight                                     


def img_module(File1, File2, inppath, outpdf, outxl, ExcelOutput):

    FileNoEx1, FileNoEx2 = fname_noext(File1), fname_noext(File2)
    
    file1_coords, _ = img_extract(File1, FileNoEx1, inppath)
    file2_coords, _  = img_extract(File2, FileNoEx2, inppath)
    print_log("Images extracted..")

    old_pdf_path = os.path.join(inppath,File1)
    new_pdf_path = os.path.join(inppath,File2)
    # print_log(old_pdf_path)
    # print_log(new_pdf_path)
        
    pdf1_img_compare, pdf2_img_compare = [], []
    
    if len(file1_coords) > 0:
        for img1 in file1_coords:
            img_compare, img_final, img_final_name = pdf_img_process(img1[0], FileNoEx1)
            if img_final_name:
                pdf1_img_compare.append([img_compare, img_final, img_final_name])
        print_log(['Number of images for comparison in oldfile', len(pdf1_img_compare)])
    else:
        print_log(["No images found in ", File1])

    if len(file2_coords) > 0:
        for img2 in file2_coords:
            img_compare, img_final, img_final_name = pdf_img_process(img2[0], FileNoEx2)
            if img_final_name:
                pdf2_img_compare.append([img_compare, img_final, img_final_name])
        print_log(['Number of images for comparison in newfile', len(pdf2_img_compare)])
    else:
        print_log(["No images found in ", File2])

    if len(pdf1_img_compare) > 0 or len(pdf2_img_compare) > 0:

        scores, removed, added = img_comparison(pdf1_img_compare, pdf2_img_compare, score_thresh)

        rows = len(scores) + len(removed) + len(added) + 1
        print_log(["Maximumn number of rows in Excel", rows])

        workbook = ExcelOutput
        worksheet = workbook.add_worksheet('Images')
        workbook.add_vba_project(vba_bin)

        header_format = workbook.add_format({
                        'bold': True,
                        'text_wrap': True,
                        'align' : 'left',
                        'valign': 'top'})

        worksheet.set_column_pixels(0, 0, 150)  #Setting cell dim for Old Pdf Section name column
        worksheet.set_column_pixels(1, 1, 400)  #Setting cell dim for Old Pdf Image column
        worksheet.set_column_pixels(2, 2, 150)  #Setting cell dim for New Pdf Section name column
        worksheet.set_column_pixels(3, 3, 400)  #Setting cell dim for New Pdf Image column
        worksheet.set_column_pixels(4, 4, 250)  #Setting cell dim for Statuscolumn
        
        # for rw in range(1, rows):
            # worksheet.set_row_pixels(rw, 300)

        old_sec_name= 'Old Section name'
        new_sec_name= 'New Section name'
        old_image= 'Image in Old file'
        new_image= 'Image in New file'
        score_head= 'Status'
        
        worksheet.write('A1', old_sec_name, header_format)
        worksheet.write('B1', old_image, header_format)
        worksheet.write('C1', new_sec_name, header_format)
        worksheet.write('D1', new_image, header_format)
        worksheet.write('E1', score_head, header_format)
        
        worksheet.freeze_panes(1, 5)
        worksheet.autofilter('A1:E1')

        #Get TOC extracted from Text Module
        toc_file_end = "TOC.xlsx"

        toc_files = os.listdir(os.path.join(st_02, FileNoEx1))
        old_toc_path = [file for file in toc_files if toc_file_end in file]

        toc_files = os.listdir(os.path.join(st_02, FileNoEx2))
        new_toc_path = [file for file in toc_files if toc_file_end in file]

        old_toc_file_path = os.path.join(st_02,FileNoEx1,old_toc_path[0])
        new_toc_file_path = os.path.join(st_02,FileNoEx2,new_toc_path[0])

        df1 = get_final_toc_coords(old_pdf_path, old_toc_file_path)
        df2 = get_final_toc_coords(new_pdf_path, new_toc_file_path)

        old_img_with_sec = map_toc_imgs(df1, file1_coords)
        new_img_with_sec = map_toc_imgs(df2, file2_coords)

        old_sec_imgnum = get_img_nums_in_sec(old_img_with_sec)
        new_sec_imgnum = get_img_nums_in_sec(new_img_with_sec)
        
        # print(old_sec_imgnum)
        # print(new_sec_imgnum)

        pdf1_coords = dict(file1_coords)
        pdf2_coords = dict(file2_coords)

        # print(pdf1_coords)
        # print(pdf2_coords)

        if rows > 0:
            pdf1_highlight, pdf2_highlight = comparison_flags(scores, removed, added, worksheet, header_format, pdf1_coords, pdf2_coords, old_sec_imgnum, new_sec_imgnum, outxl, hl_thresh)
            # scores, removed, added, worksheet, header_format, FileNoEx1, FileNoEx2, pdf1_img_coords, pdf2_img_coords, oldsection, newsection, outxl
        
            if outpdf:
                img_pdf_write(pdf1_highlight, old_pdf_path, FileNoEx1)
                img_pdf_write(pdf2_highlight, new_pdf_path, FileNoEx2)
        
        return workbook


    else:
        workbook = ExcelOutput
        worksheet = workbook.add_worksheet('Images')
        workbook.add_vba_project(vba_bin)
        worksheet.write('A1', 'No images found for comparison..')
        return workbook
        
    
    
