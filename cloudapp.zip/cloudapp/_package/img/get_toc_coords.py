#Import Libraries
import numpy as np
import pandas as pd
import fitz
import re
# from _utils.progress_logs import print_log
# red = fitz.utils.getColor('red')
# Returns area of text box that contins section name
def find_area(points):
    return (points[2]-points[0])*(points[3]-points[1])

def get_final_toc_coords(pdf_path, toc_file_path):
    df = pd.read_excel(toc_file_path, engine='openpyxl')
    df = df.replace('NaN', np.nan)
    df = df.fillna(' ')

    df["IDX"] = df["IDX"].map(str).map(str.strip)
    df['SectionNameOrig'] = df['IDX'].str.cat(df['SectionNameOrig'], sep =" ")
    df['PageNumber'] = df['PageNumber'].replace(' ', np.nan)

    #Get all Page Numbers and fill NA values with fill forward approach
    pg_no = df['PageNumber'].fillna(method="pad")

    i = 0
    for no in pg_no:
        if isinstance(no, float):
            den = 10
        else:
            den = 1
        no = str(no)
        no = re.sub(r'\.+','',no)
        no = no.strip()
        pg_no[i] = int(no)//den
        i +=1

    #Get all SectionNames
    SectionName = df['SectionNameOrig']

    #FOR DEBUGGING HIGHLIGHTED ALL THE TOC IN PDF
    doc = fitz.open(pdf_path)
    toc_coords = []

    for i in range(len(pg_no)):
        _section_name = SectionName[i] 
        _pg_no = int(pg_no[i])
        try: 
            _page = doc.loadPage(_pg_no-1)
        except:
            print(_page, " : Not found in PDF")
            break
        areas = _page.searchFor(_section_name)
        for area in areas:
            toc_coords.append([_section_name, _pg_no, [area]])

    toc_df = pd.DataFrame(toc_coords, columns =['SectionNameOrig', 'PageNumber', 'Coords'])

    doc.close()

    return toc_df
