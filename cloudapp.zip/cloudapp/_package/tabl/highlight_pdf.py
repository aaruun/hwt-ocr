# Import Libraries

import fitz
import re
from difflib import SequenceMatcher
#from _utils.progress_logs import print_log

  
def clean_records(block)  :
    block = str(block)
    block =  re.sub(r'\\n',' ',block)
    block =  re.sub(r'\\r',' ',block)
    block =  re.sub(r'\'\, ',' ',block)
    block =  re.sub(r'\'','',block)
    block = re.sub(r'^\[','',block)
    block = re.sub(r'\]$','',block)
    #block = re.sub(r'\s+0\,','',block)
    #block = re.sub(r'\s+0\s+','',block)
    block = re.sub(r'nan','',block)
    block = re.sub(r'^0\,\s+','',block)
    block = re.sub(r':',': ',block)
    block = re.sub(r'\"','',block)
    block = block.strip()
    return block


def raw_txt(a):
    # a = re.sub('^\(','',a)
    # a = re.sub(',\)$','',a)
    # a = re.sub(r'\\n',' ',a)
    # a = re.sub(r'\\n','',a)
    a = re.sub(r'[^A-Za-z0-9]+', '', a)
    a = a.strip()
    return(a)


def generate_annot_updated_old(file, table, records, page, commoncol):
    doc = fitz.open(file)
    temp = []
    
    
    for page in doc:
        if len(records) == 0:
            records = list(range(0,(len(table))))
        
        for rec in records:
            rd = list(table.iloc[rec][:])
            
            a = clean_records(rd)
            b = page.searchFor(a)
            flag = 0
            if len(a) > 1 and b is not None and len(b) > 0:
                for c in b:
                    temp.append(c)

            else:
                blocks = page.getTextBlocks()
                a = raw_txt(a)
                if len(a) > 1:
                    for blk in blocks:
                        blk1 = blk[4]
                        blk1= str(blk1)
                        blk1 = raw_txt(blk1)
                        seq = SequenceMatcher(a=a, b=blk1)
                        if a == blk1 or (seq.ratio() >= 0.98):
                            temp.append(blk[0:4])
                            flag = 1
                            break

            if flag == 0 and len(b) == 0:
                blocks = page.getTextBlocks()
                for j in range(table.shape[1]):
                    d = clean_records(table.iloc[rec][j])
                    d = raw_txt(d)
                    
                    if len(d) > 1:
                        for blk in blocks:
                            blk1 = blk[4]
                            blk1= str(blk1)
                            blk1 = raw_txt(blk1)
                            if d == blk1:
                                temp.append(blk[0:4])
                                break

    doc.close()
    return set(temp)


def generate_annot_updated(file, table, records, page, commoncol):
    doc = fitz.open(file)
    temp = []
    for page in doc:                                      
        if len(records) == 0:
            records = list(range(0,(len(table))))

        for rec in records:
            rd = list(table.iloc[rec][:])
            a = clean_records(rd)
            b = page.searchFor(a)
            flag = 0
            tmp = False
            if len(a) > 1 and b is not None and len(b) > 0:
                for c in b:
                    temp.append(c)
            else:
                blocks = page.getTextBlocks()
                a = raw_txt(a)
                if len(a) > 1:
                    for blk in blocks:
                        blk1 = blk[4]
                        blk1= str(blk1)
                        blk1 = raw_txt(blk1)
                        seq = SequenceMatcher(a=a, b=blk1)
                        if a == blk1 or (seq.ratio() >= 0.75) or (blk1 in a) or (a in blk1):
                            temp.append(blk[0:4])
                            flag = 1
                            break

            if len(b) == 0:
                blocks = page.getTextBlocks()
                for j in range(table.shape[1]):
                    tmp = False
                    d = clean_records(list(table.iloc[rec][j:j+1]))
                    sp = d.find(' ')
                    if sp != -1:
                        tmp = page.searchFor(d)
                    if not tmp and sp != -1:
                        d = raw_txt(d)
                        if len(d) > 1:
                            for blk in blocks:
                                blk1 = blk[4]
                                blk1= str(blk1)
                                blk1 = raw_txt(blk1)
                                seq = SequenceMatcher(a=d, b=blk1)
                                if d == blk1 :#or (seq.ratio() >= 0.90):
                                    temp.append(blk[0:4])
                                    break
                    elif tmp:
                        temp = temp + tmp

    doc.close()
    return set(temp)
    