import cv2
# import os

# folder = "D:\\Projects\\UL\\AzureApp\\cloudapp\\jobs\\_table\\image\\"

def rsz(pct, img):
    ht, wd = img.shape[:2]
    rwd = int(wd * pct / 100)
    rht = int(ht * pct / 100)
    rsz_img = cv2.resize(img, (rwd, rht), interpolation = cv2.INTER_LANCZOS4)
    return rsz_img


def crop_whitespace(file, pct, SAVE):
    # Load image, grayscale, Gaussian blur, Otsu's threshold
    if SAVE:
        image = cv2.imread(file)
        original = image.copy()
    else:
        original = file.copy()
        image = file

    # cv2.imshow('image', image)
    # cv2.waitKey(0)

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (25,25), 0)
    thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

    # Perform morph operations, first open to remove noise, then close to combine
    noise_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
    opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, noise_kernel, iterations=2)
    close_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (7,7))
    close = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, close_kernel, iterations=3)

    # Find enclosing boundingbox and crop ROI
    coords = cv2.findNonZero(close)
    x,y,w,h = cv2.boundingRect(coords)
    # cv2.rectangle(image, (x, y), (x + w, y + h), (36,255,12), 2)
    crop = original[y:y+h, x:x+w]

    ht, wd = crop.shape[:2]
    if ht > 50 and wd > 50:

        # cv2.imshow('crop', crop)
        # cv2.waitKey(0)

        if pct == 100:
            resized = crop
        else:
            resized = rsz(pct, crop)

        if SAVE:
            cv2.imwrite(file, resized)
        else:
            return resized, True, (x,y,w,h)
    else:
        return crop, False, (x,y,w,h) #no image only white space


# files = os.listdir(folder)

# for file in files:
#     if file.endswith('.jpg'):
#         cropped = crop_whitespace(os.path.join(folder, file))
        # cv2.imshow('thresh', thresh)
        # cv2.imshow('close', close)
        # cv2.imshow('image', image)
        # cv2.imshow('crop', cropped)
        # cv2.waitKey()
