# Import Libraries

import fitz
import re
import os
import pandas as pd
import numpy as np
# from pandas import read_excel
from _utils.utils import inp_path, st_02
import ntpath
from _utils.progress_logs import print_log

file = ""
mylist = []
toc_1 = []

def fname_noext(fname_ext):
    # file_basename = os.path.basename(fname_ext)
    # filename_without_extension = file_basename.split('.')[0]
    fname = os.path.splitext(fname_ext)[0]
    return fname


def path_leaf(path):
    head, tail = ntpath.split(path)
    return head, tail or ntpath.basename(head)


def create_toc(file):
    _, FName = path_leaf(file)
    FPath = fname_noext(FName)

    toc_file = os.path.join(st_02, FPath, FPath+'_TOC.xlsx')
    
    df = pd.read_excel(toc_file, engine='openpyxl')
    df.fillna('',inplace=True)
    # df['PageNumber'] = df['PageNumber'].str.extract('(\d+)').fillna(method='ffill').astype(int)
    df['SectionNameOrig'] = df.IDX.astype(str) + ' ' + df.SectionNameOrig.astype(str)
    toc_1 = df[['SectionNameOrig', 'PageNumber']].to_numpy()
    return toc_1


def get_toc(pg, toc_1):
    ml = []
    i = 0
    for _, page in toc_1:
        if page == pg:
            ml.append(i)
        i += 1
    return(ml)


def match(blk_match_list, b1, b3):
    blk = None
    c = 0
    for blm in blk_match_list:
        toc_data = blm[0]
        toc_blks = blm[1]
        if len(toc_blks) >0  and b1 is not None and b3 is not None:
                                 
            toc_block_y1 = toc_blks[0][1]
            toc_block_y3 = toc_blks[0][3]
            
            if((toc_block_y1 < b1) and (toc_block_y3 < b3)):
                if (c==0):
                    chk0 = abs(toc_block_y1 - b1)
                    chk1 = abs(toc_block_y3 - b3)
                    blk = toc_data
                y0 = abs(toc_block_y1 - b1)
                y1 = abs(toc_block_y3 - b3)
                if((y0 < chk0) and (y1 < chk1)):
                    blk = toc_data
                c +=1
    if blk:
        return blk
    else:
        return False


def block_match(blocks, str1):
    b1 = None
    b3 = None
    blk_match = False
    for blk in blocks:
        b = blk[4]
        b = raw_txt(b)
        if str1==b:
            b1 = blk[1]
            b3 = blk[3]
            blk_match = True
            break
    return blk_match, b1, b3
    

def raw_txt(a):
    a = str(a)
    a = re.sub('^\[','',a)
    a = re.sub('\]$','',a)
    a = re.sub('^\(','',a)
    a = re.sub(',\)$','',a)
    a = re.sub(r'\\n',' ',a)
    a = re.sub(r'\\r',' ',a)
    a = re.sub(r'[^A-Za-z0-9.]+', '', a)
    a = re.sub('Unnamed[0-90-9]','',a)
    a = a.strip()
    return(a)


def main_section(filename, tabledetails):
    mlist = []
    toc_1 = create_toc(filename)

    for val in tabledetails:
        page, tblno, table, txtblk, fn = val
                      
        toc_recs = get_toc(page+1, toc_1)

        if len(table.index) == 1:
            rec = 0
        elif len(table.index) > 1:
            rec = 1
        
        a = list(table.iloc[rec][:])
        b = list(table.columns)
        c = table.columns[0]
        doc = fitz.open(fn)
        for pg in doc:
            s = pg.searchFor(c)
        cb1 = 0
        cb3 = 0
        for i in range(len(s)):
            cb1 = cb1 + s[i][1]
            cb3 = cb3 + s[i][3]
        if len(s) > 0 :
            cb1 = cb1/len(s)
            cb3 = cb3/len(s)
        if cb1 > 0 and cb3 > 0:
            blk_match3 = True
        else:
            blk_match3 = False

        a = raw_txt(a)
        b = raw_txt(b)

        blk_match1, ab1, ab3 = block_match(txtblk, a)
        blk_match2, bb1, bb3 = block_match(txtblk, b)
        
        toc_blk_match = None
        blk_match_list = []
        df = None
        toc2 = None
        
        if len(toc_recs) >= 1:
            for j in toc_recs:
                str1 = toc_1[j][0] 
                doc = fitz.open(fn)
                for pg in doc:
                    toc_blk_match = pg.searchFor(str1)
                    if toc_blk_match:
                        break
                tmp = [str1, toc_blk_match]
                blk_match_list.append(tmp)
        
        if blk_match1:
            df = match(blk_match_list, ab1, ab3)
        elif blk_match2:
            df = match(blk_match_list, bb1, bb3)
        elif blk_match3:
            df = match(blk_match_list, cb1, cb3)
        if not df:
            for pg in range(page-1, 0, -1):
                toc2 = get_toc(pg, toc_1)
                if len(toc2) >=1:
                    break
        elif df:
            mlist.append([page, tblno, df])

        if toc2 and not df:
            mlist.append([page, tblno, toc_1[toc2[-1]][0]])

    return mlist

