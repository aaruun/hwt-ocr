#IMPORT LIBRARIES

import os
import imgkit
import cv2
import pandas as pd
import platform as pf
from _utils.utils import wkhtml_path
from io import BytesIO
import ntpath
from _package.tabl.crop_imgs import crop_whitespace

color_flag = 0                                                                                                                    

def fname_noext(fname_ext):
    # file_basename = os.path.basename(fname_ext)
    # filename_without_extension = file_basename.split('.')[0]
    fname = os.path.splitext(fname_ext)[0]
    return fname


def path_leaf(path):
    head, tail = ntpath.split(path)
    return head, tail or ntpath.basename(head)


def calculate_scale(imwd, imht):
    bound_size = (400, 300)
    # check the image size without loading it into memory
    # im = Image.open(file_path)
    original_width, original_height = imwd, imht #im.size

    # calculate the resize factor, keeping original aspect and staying within boundary
    bound_width, bound_height = bound_size
    ratios = (float(bound_width) / original_width, float(bound_height) / original_height)
    return min(ratios)


def highlight_record(table1, version, compTblnum, flag, table_page, origTblnum, path1tbl, record1, table1diffcols):
    global color_flag
    not_changed = []
    table1 = table1.reset_index(drop=True)
           
    try:
        if len(record1) > 0 and len(table1diffcols) > 0:
            color_flag = flag
            df1 = table1.style.applymap(highlight_col, subset = pd.IndexSlice[:, table1diffcols]).applymap(highlight_col, subset = pd.IndexSlice[record1,:])
        elif len(record1) > 0 and len(table1diffcols) == 0:
            color_flag = flag
            df1 = table1.style.applymap(highlight_col, subset = pd.IndexSlice[record1,:])
        elif len(table1diffcols) > 0 and len(record1) == 0:
            color_flag = flag
            df1 = table1.style.applymap(highlight_col, subset = pd.IndexSlice[:, table1diffcols])
        elif len(table1diffcols) == 0 and len(record1) == 0:
            df1 = False
    except Exception as ex:
        print(ex)
        df1 = False

    path_1= os.path.join(path1tbl, str(origTblnum) + '-'+ str(compTblnum) + '_' + version+ '$' + str(table_page) + '#' + str(flag) + '.html')
    fname = str(origTblnum) + '-'+ str(compTblnum) + '_' + version+ '$' + str(table_page) + '#' + str(flag) + '.jpg'

    if df1:
        f = open(path_1,"w",encoding ='utf-8')
        output = df1.render() #TODO: uniform table border for excel output
        f.write(output)
        f.close()
    else:
        not_changed.append(fname)
        try:
            table_to_html1= table1.to_html()
            text_file = open(path_1, "w",encoding ='utf-8')
            text_file.write(table_to_html1)
            text_file.close()
        except :
            print('This is second exception')
    return not_changed


def highlight_col(x):
    if color_flag == 1:
        color = 'background-color: #ff7373'
    elif color_flag == 2:
        color = 'background-color: #90ee90'
    elif color_flag == 3 :#or color_flag == 4:
        color = 'background-color: #ffce73'
    return color
    

def write_html_image(path1tbl, img_tblpath2):
    files = os.listdir(path1tbl)
    for file in files:
        file_name = file.split('.')[0]
        file_name = img_tblpath2 + file_name + '.jpg'
        if 'Windows' in pf.platform():
            config = imgkit.config(wkhtmltoimage=wkhtml_path+'/wkhtmltoimage.exe')
        if 'Linux' in pf.platform():
            config = imgkit.config(wkhtmltoimage='/usr/local/bin/wkhtmltoimage')
        imgkit.from_file(path1tbl+file, file_name, config=config)
        crop_whitespace(file_name, 95, True)

            
def write_excel(tcd1, tcd2, tblpath2, ExcelOutput, imgdetails, notchanged):
    workbook = ExcelOutput
    worksheet = workbook.add_worksheet('Tables')
    
    old_table= 'Table in Old file'
    new_table= 'Table in New file'
    flag= 'Flag'
    
    old_table_section = 'Table section in Old file'
    new_table_section = 'Table section in New file'

    bold = workbook.add_format({
                'bold': True,
                'text_wrap': True,
                'align' : 'left',
                'valign': 'top'}) # center vcenter
    
    worksheet.write('A1', old_table_section, bold)
    worksheet.write('B1', old_table, bold)
    worksheet.write('C1', new_table_section, bold)
    worksheet.write('D1', new_table, bold)
    worksheet.write('E1', flag, bold)
    
    worksheet.freeze_panes(1, 5)
    worksheet.autofilter('A1:E1')

    worksheet.set_column_pixels(0, 0, 150)  #Setting cell dim for Old Pdf Section name column
    worksheet.set_column_pixels(1, 1, 400)  #Setting cell dim for Old Pdf Image column
    worksheet.set_column_pixels(2, 2, 150)  #Setting cell dim for New Pdf Section name column
    worksheet.set_column_pixels(3, 3, 400)  #Setting cell dim for New Pdf Image column
    worksheet.set_column_pixels(4, 4, 250)  #Setting cell dim for Statuscolumn

    compare = []
    added = []
    removed = []

    for item in imgdetails:
        compTblnum, origTblnum, flag, pageold, pagenew = item
        oldsection, newsection = 'Not Available', 'Not Available'
        ocounter, ncounter = 1, 1

        if flag in [1, 3]:
            for itm in tcd1:
                pg, tblno, df, c = itm
                if pg == pageold and tblno == origTblnum:
                    oldsection = df
                    ocounter = c
                    if oldsection and ocounter:
                        break
        if flag in [2, 3]:
            for itm in tcd2:
                pg, tblno, df, c = itm
                if pg == pagenew and tblno == origTblnum:
                    newsection = df
                    ncounter = c
                    if newsection and ncounter:
                        break

        oldfile = str(compTblnum) + '-'+ str(compTblnum) + '_ver1$' + str(pageold) + '#' + str(flag) + '.jpg'
        newfile = str(origTblnum) + '-'+ str(compTblnum) + '_ver2$' + str(pagenew) + '#' + str(flag) + '.jpg'
        
        if flag == 1 and oldfile not in notchanged:
            removed.append([oldsection, oldfile, flag])
        elif flag == 2 and newfile not in notchanged:
            added.append([newsection, newfile, flag])
        elif flag == 3 and (oldfile not in notchanged or newfile not in notchanged):
            compare.append([oldsection, oldfile, newsection, newfile, flag, ocounter, ncounter])

    XLRows = len(added)+len(removed)+len(compare)+1
    for rw in range(1, XLRows):
        worksheet.set_row_pixels(rw, 300)

    x = 2
    for item in compare:

        oldsection, oldfile, newsection, newfile, flag, ocounter, ncounter = item

        if oldsection == newsection:
            if ocounter == ncounter:
                flag = 'Updated'
            elif ocounter != ncounter:
                flag = 'Updated & Intra Section Movement'
        elif oldsection != newsection:
            flag = 'Updated & Moved'
        else:
            flag = 'Updated & for Manual Verification'

        worksheet.write('A'+str(x), oldsection, bold)
        worksheet.write('C'+str(x), newsection, bold)
        worksheet.write('E'+str(x), flag, bold)

        if os.path.isfile(tblpath2+oldfile):
            oimg = cv2.imread(tblpath2+oldfile)
            oimgbuffer = cv2.imencode('.png', oimg)[1]
            oimgdata = BytesIO(oimgbuffer)
            oimage_height, oimage_width = oimg.shape[:2]
            oresize_scale = calculate_scale(oimage_width, oimage_height)
            worksheet.insert_image('B'+str(x), oldfile, {'x_scale': oresize_scale, 'y_scale': oresize_scale, 'image_data': oimgdata})

        if os.path.isfile(tblpath2+newfile):
            nimg = cv2.imread(tblpath2+newfile)
            nimgbuffer = cv2.imencode('.png', nimg)[1]
            nimgdata = BytesIO(nimgbuffer)
            nimage_height, nimage_width = nimg.shape[:2]
            nresize_scale = calculate_scale(nimage_width, nimage_height)
            worksheet.insert_image('D'+str(x), newfile, {'x_scale': nresize_scale, 'y_scale': nresize_scale, 'image_data': nimgdata})

        x = x + 1


    y = len(compare)+2 #x+1
    for item in added:
        newsection, newfile, _ = item
        flag = 'Added'
        nimg = cv2.imread(tblpath2+newfile)
        nimgbuffer = cv2.imencode('.png', nimg)[1]
        nimgdata = BytesIO(nimgbuffer)
        nimage_height, nimage_width = nimg.shape[:2]
        nresize_scale = calculate_scale(nimage_width, nimage_height)

        worksheet.write('A'+str(y), 'NA', bold)
        worksheet.write('B'+str(y), 'NA', bold)
        worksheet.write('C'+str(y), newsection, bold)
        worksheet.write('E'+str(y), 'Added', bold)
        worksheet.insert_image('D'+str(y), newfile, {'x_scale': nresize_scale, 'y_scale': nresize_scale, 'image_data': nimgdata})
        y = y+1


    z = len(compare)+len(added)+2 #y+1
    for item in removed:
        oldsection, oldfile, _ = item
        oimg = cv2.imread(tblpath2+oldfile)
        oimgbuffer = cv2.imencode('.png', oimg)[1]
        oimgdata = BytesIO(oimgbuffer)
        oimage_height, oimage_width = oimg.shape[:2]
        oresize_scale = calculate_scale(oimage_width, oimage_height)

        worksheet.write('A'+str(z), oldsection, bold)
        worksheet.write('C'+str(z), 'NA', bold)
        worksheet.write('D'+str(z), 'NA', bold)
        worksheet.write('E'+str(z), 'Removed', bold)
        worksheet.insert_image('B'+str(z), oldfile, {'x_scale': oresize_scale, 'y_scale': oresize_scale, 'image_data': oimgdata})
        z = z+1

    return workbook

    