#Import Libraries

import tabula
import numpy as np
import pandas as pd
import os
import re
import fitz
# import time
# import logging
# from datetime import datetime
# from _package.utils import inp_path
from _package.tabl import get_sections
from _package.tabl import highlight_dataframe
from _package.tabl import highlight_pdf
from _package.tabl import table_identification as tbi
from _utils.utils import out_path, tbl_path1, tbl_path2, tbl_path3, vba_bin #, print_log
from _utils.progress_logs import print_log


blue   = (0.0, 0.0, 1.0)
red    = (1.0, 0.0, 0.0)
yellow = (1.0, 1.0, 0.0)
# orange = (1.0, 0.6, 0.0)
# green = (0.0, 1.0, 0.0)

def fname_noext(fname_ext):
    # file_basename = os.path.basename(fname_ext)
    # filename_without_extension = file_basename.split('.')[0]
    fname = os.path.splitext(fname_ext)[0]
    return fname


def fitz_overwrite(Path, doc):
    if os.path.isfile(Path):
        docbytes = doc.tobytes()
        doc.close()
        os.remove(Path)
        doc = fitz.open("pdf", docbytes)
        doc.save(Path)
        doc.close()
    print("Overwrite Success", Path)


def clean_column_names(df):
    a = df
    c = list(a.columns)
    cols = []
    nan_counter = 0
    #print(c)
    for i in range(len(c)):
        d1 = str(c[i:i+1])
        d2 = re.sub(r'\\r',' ',d1)
        d3 = re.sub(r'[\[]','',d2)
        d4 = re.sub(r'[\]]','',d3)
        d5 = re.sub(r'\'','',d4)
        d5 = re.sub(r'Unnamed:','Column',d5)
        if d5.find('nan') != -1 :
            f = u'Column {}'.format(nan_counter)
            nan_counter = nan_counter + 1
            d5 = re.sub(r'nan',f,d5)
        #print('This is d5: ',d5)
        cols.append(d5)
    a.columns = cols
    return a


def check_header_not_read(df):
    a = df
    c = list(a.columns)
    cols = []
    check = 0
    new_df = pd.DataFrame()
    for i in range(len(c)):
        d1 = str(c[i])
        d2 = d1[:6]
        if d2 == 'Column':
            check = check + 1
    if check == len(c):
        new_df = df[1:]
        new_df.columns = list(df.iloc[0][:])
        new_df = clean_column_names(new_df)
    if len(new_df) > 0:
        return new_df
    else:
        return a


def clean_records(df):
    drop_na_records = []
    for k in range(df.shape[0]):
        check5 = 0
        for m in range(df.shape[1]):
            b = list(df.iloc[k][m:m+1])
            b = str(b)
            c = re.sub(r'^\[','',b)
            c = re.sub(r'\]$','',c)
            c = re.sub(r'\'','',c)
            c = re.sub(r'\\r',' ',c)
            c = c.strip()
            if(c=='nan'):
                check5 = check5 + 1
            else:
                try:
                    df.iat[k,m] = c
                except:
                    df.iat[k,m] = float(c)

        if check5 == df.shape[1]:
            drop_na_records.append(k)

    if len(drop_na_records) > 0:
        val = df.drop(drop_na_records)
        return(val)
    else:
        return df


def raw_txt(a):
    a = str(a)
    a = re.sub('^\(','',a)
    a = re.sub(',\)$','',a)
    a = re.sub(r'[^A-Za-z0-9]+', '', a)
    a = re.sub('nan','',a)
    a = a.strip()
    return(a)


def no_column_diff_record_changes(diff):
    _annot3 = []
    _annot4 = []
    imgnamedetails = []
    not_changed = []

    for item in diff:
        pgtbl1, table1, fn1, pgtbl2, table2, fn2 = item

        table1 = table1.fillna(np.nan)
        table2 = table2.fillna(np.nan)
            
        table1 = clean_records(table1)
        table2 = clean_records(table2)
                
        # cols = list(table1.columns)
        table1col = set(table1.columns)
        table2col = set(table2.columns)
        compare1 = []
        compare2 = []
        commoncol = list(table1col.intersection(table2col))
        table1diffcols = list(table1col.difference(set(commoncol)))
        table1col = list(table1col)
        table2diffcols = list(table2col.difference(set(commoncol)))
        table2col = list(table2col)
        
        table1commcols = list(table1[commoncol])
        table2commcols = list(table2[commoncol])

        for k in range(len(table1)):
            # compare1.append(list(table1.iloc[k][table1commcols]))
            compare1.append(raw_txt(list(table1.iloc[k][table1commcols])))
        for k in range(len(table2)):
            # compare2.append(list(table2.iloc[k][table2commcols]))
            compare2.append(raw_txt(list(table2.iloc[k][table2commcols])))
        record1 = []
        
        for k in range(len(compare1)):
            if(compare1[k] in compare2):
                pass
            else:
                record1.append(k)

        pageno1 = int(pgtbl1.split('_')[0])
        tableno1  = int(pgtbl1.split('_')[1])
        not_changed1 = highlight_dataframe.highlight_record(table1, 'ver1', tableno1, 3, pageno1, tableno1, tbl_path1, record1, table1diffcols)

        tmp = [fn1, table1, record1, pageno1, commoncol, table1diffcols]

        _annot3.append(tmp)                                                              
        
        record2 = []
        for k in range(len(compare2)):
            if(compare2[k] in compare1):
                pass
            else:
                record2.append(k)

        pageno2 = int(pgtbl2.split('_')[0])
        tableno2  = int(pgtbl2.split('_')[1])
        not_changed2 = highlight_dataframe.highlight_record(table2,'ver2', tableno1, 3, pageno2, tableno2, tbl_path1, record2, table2diffcols)

        tmp = [fn2, table2, record2, pageno2, commoncol, table2diffcols]   
        _annot4.append(tmp)

        not_changed += not_changed1+not_changed2

        imgnamedetails.append([tableno1, tableno2, 3, pageno1, pageno2])
        
    return _annot3, _annot4, imgnamedetails, not_changed

        
def remove_garbabge_tables(df):
    nlist1 = list(range(len(df)))
    check = 0
    for n in range(len(df)):
        ll = df[n]
        x = df[n].shape[0]
        y = df[n].shape[1]
                
        cols = list(ll.columns)

        if len(cols) == 1:
            check5 = True if len(ll.columns) == 1 and len(str(ll.columns[0])) > 100 else False
        else:
            check5 = False
    
        for i in cols:
            check4 = 0 
            for j in range(x):
                if(pd.isna(ll.iloc[j][i])==True):
                    check4 += 1
                if(check4==x):
                    ll.drop(i, axis = 1,inplace=True)
        
        x = ll.shape[0]
        y = ll.shape[1]
        check1 = x*y  # Total number of attributes
        check2 = 0    # Total NaN 
        check3 = 0    # Total number of string attributes
        
        for i in range(x):
            for j in range(y):
                if(isinstance(ll.iloc[i][j],str)==True):
                    check3 += 1
                elif(np.isnan(ll.iloc[i][j])==True):
                    check2 += 1
        
        if((check1==check2) or (check2/check1 > 0.9) or (x==1 and y==1) or (x<=2 and y==1) or check5):
            # (check2/check1 > 0.9)
            # (x==2 and y==1)):  #(check1-check3 >5)
            nlist1.remove(n)
            check +=1
            
    return nlist1
    
    
def split_pdf(pdf_file, pdfout, pages):

    if not (os.path.isdir(pdfout)):
        os.makedirs(pdfout)
    
    pdf = fitz.open(pdf_file)

    tbldetails = []
    for page in pages:
        txtblk = pdf[page].getTextBlocks()
        doc = fitz.open() # new empty PDF
        doc.insert_pdf(pdf, from_page =page, to_page = page, links=False, annots=False)
        fn = "/Page_"+str(page)+".pdf"
        doc.save(pdfout+fn)

        print_log('Reading Tables From ' + pdf_file + ' File Page ' + str(page))
        tables_file1= tabula.read_pdf(pdfout+fn, multiple_tables=True, 
                                        pages="all", lattice=True, guess=True, silent=True)

        if(len(tables_file1) > 0 ):
            tables_file1 = [clean_column_names(tbl) for tbl in tables_file1]
            nlist2 = remove_garbabge_tables(tables_file1)
            for j in nlist2:
                tbldetails.append([page, j, tables_file1[j], txtblk, pdfout+fn])
        doc.close()
    pdf.close()
    return tbldetails


def get_tbllist(file1, tabledetails):
    sectionlist = get_sections.main_section(file1, tabledetails)
    tblcompdetails = []
    c = 1
    for ix, item in enumerate(sectionlist):
        ct = len(sectionlist)
        if ix < ct and ix > 0:
            page, tblno, df = item
            previous = sectionlist[ix-1][2] #previous df
            current = df
            if current == previous:
                c += 1
                tblcompdetails.append([page, tblno, df, c])
            else:
                c = 1
                tblcompdetails.append([page, tblno, df, c])
            print('Section is :', df, 'counter is :', c)
        else:
            tblcompdetails.append([sectionlist[ix][0], sectionlist[ix][1], sectionlist[ix][2], c])
            print("Last section")
    
    return tblcompdetails


def table_difference(settablelist1, setpgtbl1list, tbllst1, ver, x):
    _annot1 = []
    imgnamedetails = []
    not_changed = []

    table_addremov = list(settablelist1-setpgtbl1list)

    print('settablelist1', ver, settablelist1)
    print('setpgtbl1list', ver, setpgtbl1list)
    print('table_addremov', ver, table_addremov)

    tmp = []

    for val in table_addremov:
        # print("pagetable and value check1", val)
    
        table_clean = pd.DataFrame()
        filename = ''
        
        for item in tbllst1:
            pgtbl, table, fn = item
            if pgtbl == val:
                table = table.fillna(np.nan)
                table_clean = clean_records(table)
                filename = fn
                # print("pagetable and value check2", pgtbl, val, filename)
                if len(table_clean) > 0:
                    break
        table_clean = table_clean.reset_index(drop=True)
        records = list(range(0,(len(table_clean))))
        print('records', records)
        
        table_page = int(val.split('_')[0])
        tblno = int(val.split('_')[1])

        not_changed0 = highlight_dataframe.highlight_record(table_clean, ver, tblno, x, table_page, tblno, tbl_path1, records, list(table_clean.columns))
        
        if filename:
            annot = highlight_pdf.generate_annot_updated(filename, table_clean, records, table_page, [])
            tmp = [table_page, annot, x]
            _annot1.append(tmp)
            imgnamedetails.append([tblno, tblno, x, table_page, table_page])
            not_changed += not_changed0
        else:
            print("No filename ", filename, table_page, tblno, x, len(records))

    return _annot1, imgnamedetails, not_changed


def get_singleAnnot(data1, data3, data5):
    _annot3 = []
    data = data1+data3+data5

    for item in data:
        fn1, table1, record1, pageno1, _, table2diffcols = item
            
        if len(record1) > 0 or len(table2diffcols) > 0:
            annot = highlight_pdf.generate_annot_updated(fn1, table1, record1, pageno1, [])
            tmp = [pageno1, annot, 3]
            _annot3.append(tmp)
    return _annot3


def pdf_hl(_annot1, _annot3, fitzfile1, path):
    consolidatedlist = _annot1 + _annot3
    for l2 in consolidatedlist:
        pg   = l2[0]
        annots = l2[1]
        flag   = l2[2]
        
        if flag == 1:
            color = {"stroke": red, "fill": red}
        elif flag == 2:
            color = {"stroke": blue, "fill": blue}
        else:
            color = {"stroke": yellow, "fill": yellow}
        
        page_content = fitzfile1[pg]
        if (annots is not None):
            if (isinstance(annots,tuple)==True):
                annot = page_content.addRectAnnot(annots)
                annot.setColors(color)
                annot.setOpacity(0.3)
                annot.update()
            elif (isinstance(annots,set)==True):
                for an in annots:
                    annot = page_content.addRectAnnot(an)
                    annot.setColors(color)
                    annot.setOpacity(0.3)
                    annot.update()


def table_module(version1, version2, inp_path, outpdf, outxl, ExcelOutput):
    # start = time.time()
    
    file1 = inp_path + version1
    file2 = inp_path + version2
    
    File1NoEx = fname_noext(version1)
    File2NoEx = fname_noext(version2)
    
    pdfout1 = os.path.join(tbl_path3, File1NoEx)
    pdfout2 = os.path.join(tbl_path3, File2NoEx)
    
    fitzfile1 = fitz.open(file1)
    fitzfile2 = fitz.open(file2)

    pages1 = tbi.table_detection(fitzfile1)
    pages2 = tbi.table_detection(fitzfile2)

    tabledetails1 = split_pdf(file1, pdfout1, pages1)
    tabledetails2 = split_pdf(file2, pdfout2, pages2)

    _annot1, _annot2, _annot3, _annot4 = [], [], [], []

    tblcompdetails1 = get_tbllist(file1, tabledetails1)
    tblcompdetails2 = get_tbllist(file2, tabledetails2)

    tablelist1, tablelist2 = [], []
    tbllst1, tbllst2, diffs = [], [], []

    for val1 in tabledetails1:
        page1, j1, table1, _, fn1 = val1
        table1 = check_header_not_read(table1)
        table1 = table1.reset_index(drop=True)

        for val2 in tabledetails2:
            page2, j2, table2, _, fn2 = val2
            table2 = check_header_not_read(table2)
            table2 = table2.reset_index(drop=True)

            pgtbl1 = str(page1)+'_'+str(j1)
            pgtbl2 = str(page2)+'_'+str(j2)

            tablelist1.append(pgtbl1)
            tablelist2.append(pgtbl2)

            tbllst1.append([pgtbl1, table1, fn1])
            tbllst2.append([pgtbl2, table2, fn2])

            set1 = set(table1)
            set2 = set(table2)
            set3 = set1.union(set2)
            set4 = set3.difference(set1)
            set5 = set3.difference(set2)
            set6 = len(set1.intersection(set2))
            diff = len(set4) + len(set5)

            if set6 > 0:
                diffs.append([diff, pgtbl1, table1, fn1, pgtbl2, table2, fn2])


    diff0, diff1, diff2 = [], [], []
    common1, common2 = [], []

    for item1 in diffs:
        diff, pgtbl1, table1, fn1, pgtbl2, table2, fn2 = item1
        if diff == 0 and pgtbl1 not in common1 and pgtbl2 not in common2:
            diff0.append([pgtbl1, table1, fn1, pgtbl2, table2, fn2])
            common1.append(pgtbl1)
            common2.append(pgtbl2)

    for item2 in diffs:
        diff, pgtbl1, table1, fn1, pgtbl2, table2, fn2 = item2
        if diff == 1 and pgtbl1 not in common1 and pgtbl2 not in common2:
            diff1.append([pgtbl1, table1, fn1, pgtbl2, table2, fn2])
            common1.append(pgtbl1)
            common2.append(pgtbl2)

        elif diff == 2 and pgtbl1 not in common1 and pgtbl2 not in common2:
            diff2.append([pgtbl1, table1, fn1, pgtbl2, table2, fn2])
            common1.append(pgtbl1)
            common2.append(pgtbl2)

    # for item3 in diffs:
    #     diff, pgtbl1, table1, fn1, pgtbl2, table2, fn2 = item3
    #     if diff == 2 and pgtbl1 not in common1 and pgtbl2 not in common2:
    #         diff2.append([pgtbl1, table1, fn1, pgtbl2, table2, fn2])
    #         common1.append(pgtbl1)
    #         common2.append(pgtbl2)


    settablelist1 = set(tablelist1)
    setpgtbl1list = set(common1)

    settablelist2 = set(tablelist2)
    setpgtbl2list = set(common2)

    _annot1, imgnamedetails1, not_changed1 = table_difference(settablelist1, setpgtbl1list, tbllst1, 'ver1', 1)
    _annot2, imgnamedetails2, not_changed2 = table_difference(settablelist2, setpgtbl2list, tbllst2, 'ver2', 2)

    data1, data2, imgnamedetails3, not_changed3 = no_column_diff_record_changes(diff0)
    data3, data4, imgnamedetails4, not_changed4 = no_column_diff_record_changes(diff1)
    data5, data6, imgnamedetails5, not_changed5 = no_column_diff_record_changes(diff2)

    _annot3 = get_singleAnnot(data1, data3, data5)
    _annot4 = get_singleAnnot(data2, data4, data6)

    f1 = out_path+version1
    f2 = out_path+version2

    if outpdf:
        pdf_hl(_annot1, _annot3, fitzfile1, f1)
        pdf_hl(_annot2, _annot4, fitzfile2, f2)
 
        fitz_overwrite(f1, fitzfile1)
        fitz_overwrite(f2, fitzfile2)

    if outxl:
        print("write_html_image", tbl_path1, tbl_path2)
        highlight_dataframe.write_html_image(tbl_path1, tbl_path2)

        imgnamedetails = imgnamedetails1+imgnamedetails2+imgnamedetails3+imgnamedetails4+imgnamedetails5
        notchanged = not_changed1+not_changed2+not_changed3+not_changed4+not_changed5

        print('imgnamedetails', imgnamedetails)
        print('notchanged', notchanged)

        ExcelOutputT = highlight_dataframe.write_excel(tblcompdetails1, tblcompdetails2, tbl_path2, ExcelOutput, imgnamedetails, notchanged)
        return ExcelOutputT
    else:
        return ExcelOutput
    
