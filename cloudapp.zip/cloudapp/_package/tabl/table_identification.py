#!/usr/bin/env python
# coding: utf-8

# import shutil
# import os
# import fitz
# import re
import cv2
import numpy as np

def pix2np(pix):
    im = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, pix.n)
    im = np.ascontiguousarray(im[..., [2, 1, 0]])  # rgb to bgr
    return im


def grayImage(img):
    img0 = cv2.cvtColor(img, cv2.IMREAD_GRAYSCALE)
    dstimg = cv2.cvtColor(img0, cv2.COLOR_BGR2GRAY)
    return dstimg


def line_remove(img):
    thrs = cv2.bitwise_not(img)
    
    hz = np.copy(thrs)
    vt = np.copy(thrs)

    rows,cols = thrs.shape
    hval = int(cols // 10)
    vval = int(rows // 35)

    hStr = cv2.getStructuringElement(cv2.MORPH_RECT, (hval,1))
    hz = cv2.erode(hz, hStr, (-1, -1))
    hz = cv2.dilate(hz, hStr, (-1, -1))

    vStr = cv2.getStructuringElement(cv2.MORPH_RECT, (1, vval))
    vt = cv2.erode(vt, vStr, (-1, -1))
    vt = cv2.dilate(vt, vStr, (-1, -1))
    
    masks = cv2.add(hz, vt)

    kernel = np.ones((5, 5), dtype = "uint8")
    dilated = cv2.dilate(masks, kernel,iterations=1)
    morphclose = cv2.morphologyEx(dilated, cv2.MORPH_CLOSE, kernel)
    
    blur = cv2.GaussianBlur(morphclose,(5,5),0)
    th3 = cv2.threshold(blur,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1]
    
    return th3


def not_rect(c):
    peri = cv2.arcLength(c, True)
    approx = cv2.approxPolyDP(c, 0.02 * peri, True)
    
    #epsilon = 0.01*cv2.arcLength(c, True)
    #approx = cv2.approxPolyDP(c, epsilon, True)
    #cv2.drawContours(img, [approx], 0, (0), 3)
    return not len(approx) == 4


def removeLines(img):
    # edged = cv2.Canny(img, 50, 100)
    mask = np.ones(img.shape[:2], dtype="uint8") * 255
    cnts = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    for c in cnts:
        if not_rect(c):
            cv2.drawContours(mask, [c], -1, 0, -1)
        #area = cv2.contourArea(c)
        #x,y,w,h = cv2.boundingRect(c)
        #if h < 100:
            #cv2.rectangle(img, (x, y), (x + w, y + h), (255, 255, 255), -1)
    img = cv2.bitwise_and(img, img, mask=mask)
    return img


def get_tables(image):

    img = image.copy()
    
    #img = cv2.imread(img)
    gray = grayImage(img)
    lines = line_remove(gray)
    lns = removeLines(lines)
    score = cv2.countNonZero(lns)
    
    #cv2.imshow("lines", lines)
    #cv2.waitKey(0)
    #cv2.destroyAllWindows()
    
    # cv2.imshow("lns", lns)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
    
    return score


def table_detection(doc):
    # doc = fitz.open(PDFFile)

    pages = []
    j = 0
    for page in doc:
        pix = page.get_pixmap()
        im = pix2np(pix)
        score = get_tables(im)
        # print(j+1, score)
        if score > 5000:
            pages.append(j)
        j = j+1

    return pages

# if __name__ == '__main__':
#     pages = table_detection(PDFFile)
