#!/usr/local/bin python

from flask import Flask
from flask import render_template
from datetime import datetime
from comparedoc import comparedocjob
# from concurrent.futures import ThreadPoolExecutor
from threading import Thread
import os
from _utils.utils import logpath

dtstr = datetime.now().strftime("%Y.%m.%d")

# executor = ThreadPoolExecutor(1)
# executor.submit(comparedocjob)
th = Thread(name='CompareDoc', target=comparedocjob)
th.daemon=True
th.start()

app = Flask(__name__)

@app.route('/')
def run_jobs():
    # executor.submit(background_comparison_job)
    return 'Comparison Job submitted in background..'


def background_comparison_job():
    print('CompareDoc running in background..')
    # comparedocjob
    return 'Comparison Job had exception..'


@app.route("/progress")
def get_data(N=20):
    lines = []
    if os.path.isdir(logpath):
        files = os.listdir(logpath)
        for file in files:
            if file.startswith('progress') and file.endswith('.log'):
                with open(logpath+'/'+file, 'r') as f:
                    for line in (f.readlines()[-N:]):
                        lines.append(line)
            else:
                lines.append("No logging file available..")
    else:
        lines.append("No logging folder available..")

    return render_template("progress.html", data=lines)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=False, use_reloader=False)
