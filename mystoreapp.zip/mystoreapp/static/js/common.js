

function calculateSum() {
   var sum = 0;
   $(".ptp").each(function () {
      if (!isNaN(this.value) && this.value.length != 0) {
            sum += parseFloat(this.value);
      }
   });
   $("#btotal").val(sum.toFixed(2));
}

// For items
$(function(){
   $("table tr").keyup(function(){
      var oitm = $(this).find('.dsc').val();
      var uom = $(this).find('.uom');
      var pup = $(this).find('.pup');
      var pqt = $(this).find('.pqt');
      var lookitm = oitm.split("(")[0];

   if (lookitm.length > 2) {
   fetch('/getitem/' + lookitm).then(function(response){
      response.json().then(function(data){
         var item = $('<datalist id="itmdatalist"></datalist>');
         for (let itm of data.gitems) {              
            item.append('<option value="'+ itm.slno+': '+itm.itmname +' (Rs. '+ itm.unitprc +')">');
         }
         $("#itmdatalist").replaceWith(item);
      });
   })};
   var sitm = $(this).find('.dsc').val();
      var sln = sitm.split(":")[0];
      fetch('/getuompri/' + sln).then(function(response){
         response.json().then(function(data){
            uom.val(data.uitems[0].itmuom);
            pup.val(data.uitems[0].unitprc);
            pqt.focus();
         });
      });
});
});

// For customers
$(function(){
   $("#custname").keyup(function(){
      var custname = $('#custname').val();
      var lookcust = custname.split(":")[0];

   if (lookcust.length > 2) {
   fetch('/getcust/' + lookcust).then(function(response){
      response.json().then(function(data){
         var customers = $('<datalist id="custslist"></datalist>');
         for (let cust of data.custslst) {    
            customers.append('<option value="'+ cust.cstcde+': '+cust.cstnme +'">');
         }
         $("#custslist").replaceWith(customers);
      });
   })};
   var scust = $('#custname').val();
   var cod = scust.split(":")[0]
      fetch('/getcod/' + cod).then(function(response){
         response.json().then(function(data){
            $('#custname').val(data.codlst[0].cstnme);
            $('#custcode').val(data.codlst[0].cstcde);
            $('#tbalance').val(data.codlst[0].csttbal);
            $('#billno').val(data.codlst[0].cstblno);
            $('#items-0-dsc').focus()
         });
      });
});
});


$(function(){
$("table tr").keyup(function(){
   var qty = parseFloat($(this).find('.pqt').val());
   var price = parseFloat($(this).find('.pup').val());
   prce = price*qty;
   prc = Math.round(prce)
   if (!isNaN(prc) && prc.length != 0) {
      $(this).find('.ptp').val(prc.toFixed(2));
      calculateSum();
      }
});
});

   