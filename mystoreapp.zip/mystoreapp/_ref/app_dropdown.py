from flask_wtf import FlaskForm
from wtforms import SelectField
from flask import Flask, render_template, request, jsonify
import pandas as pd
from config.appconfig import Config


app = Flask(__name__)
app.config.from_object(Config)

class ItemsForm(FlaskForm):
    # slno = SelectField('SLNo')
    items = SelectField('Items')
    uoms = SelectField('UOM')

Path = "D:\\Projects\\grocery\\mystoreapp\\"

df = pd.read_excel("D:\\Projects\\grocery\\mystoreapp\\data\\ItemsDB.xlsx")
# df = df.set_index(["SlNo"])

@app.route('/', methods=['GET', 'POST'])
def dropdown():
    # total_data = pd.read_excel("D:\\Projects\\grocery\\mystoreapp\\data\\ItemsDB.xlsx")
    # data1 = df.index.tolist()
    data1 = df['ItemName'].unique().tolist()
    # data2 = df['UOM'].unique().tolist()
    
    form = ItemsForm()
    form.items.choices = [(i, i) for i in data1]
    # form.uoms.choices = [(i, i) for i in data2]
    return render_template('dropdown.html', form=form)


# @app.route('/item_choice/<value>')
# def item_choice(value):
#     item_choosen = value
#     df1 = df.loc[item_choosen, 'Item Name'].tolist()
#     print(df1)
#     return jsonify({'Item Name': df1})


@app.route('/getitem/<item>')
def get_items(item):
    df = pd.read_excel(Path+"data/ItemsDB.xlsx")
    res = df[df['ItemName'].str.contains(item, na=False, case=False)]
    lst = res[['SlNo', 'ItemName', 'UOM', 'UnitPriceRTL']] #.to_json(orient='records')
    
    itmA = []
    for ix, itm in lst.iterrows():
        itmObj = {}
        itmObj['slno'] = ix
        itmObj['itmname'] = itm['ItemName']
        itmObj['itmuom'] = itm['UOM']
        itmObj['unitprc'] = itm['UnitPriceRTL']
        itmA.append(itmObj)

    print({'gitems': itmA})
    return jsonify({'gitems': itmA})


# @app.route('/unit_choice/<value>')
# def unit_choice(value):
#     # YOU CAN IMPLEMENT THIS BY FOLLOWING THE SAME MODEL AS THE DEVICES
#     unit_choosen = value
#     df2 = df.loc[unit_choosen, 'UOM'].tolist()
#     print(df2)
#     return jsonify({'UOM': df2})


# class LocationsForm(FlaskForm):
#     locations = SelectField('Locations')

# @app.route('/', methods=['GET', 'POST'])
# def dropdown():
#     total_data = pd.read_csv("CPS.csv")
#     data = total_data['LOCATION'].unique().tolist()

#     form = LocationsForm()
#     form.locations.choices = [(i, i) for i in data]

#     return render_template(form=form)


# @app.route('/device_choice/<value>')
# def device_choice(value):
#     location_choosen = value
#     df = pd.read_csv("CPS.csv")
#     df = df.set_index(["LOCATION"])
#     df1 = df.loc[location_choosen, 'Device'].tolist()

#     return jsonify({'Devices': df1})

# @app.route('/unit_choice/<value>')
# def unit_choice(value):
#     # YOU CAN IMPLEMENT THIS BY FOLLOWING THE SAME MODEL AS THE DEVICES


if __name__ == '__main__':
    app.run(debug = True)
    