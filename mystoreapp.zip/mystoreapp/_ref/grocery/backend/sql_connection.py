import datetime
import mysql.connector
# import psycopg2

__cnx = None

def get_sql_connection():
  print("Opening mysql connection")
  global __cnx

  if __cnx is None:
    __cnx = mysql.connector.connect(user='sqladmin', password='Singap0re', database='grocerystore')
    # __cnx = conn = psycopg2.connect(host="localhost",
    #                                 database="grocerystore",
    #                                 user="grocery",
    #                                 password="grocery")

  return __cnx

