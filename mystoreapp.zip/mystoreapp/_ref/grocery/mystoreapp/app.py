from flask import Flask, render_template, flash, redirect, request, url_for, jsonify
from sales.forms import CustInfo, ItemsForm, SalesForm, BillTotal
from config.appconfig import Config
# import sqlite3 as sql
import pandas as pd
import numpy as np

Path = "D:\\Projects\\grocery\\mystoreapp\\"
itmdb = pd.read_excel(Path+"data/ItemsDB.xlsx")

app = Flask(__name__)
app.config.from_object(Config)


@app.route('/')
def home():
   return render_template('home.html')


def PopulateForm():
    custinfo = CustInfo()
    salesform = SalesForm()
    billtotal = BillTotal()

    # itmlst = itmdb['ItemName'].unique().tolist()
    # print(itmlst)

    custinfo.custname.data = ''
    custinfo.custcode.data = ''
    custinfo.tbalance.data = ''
    custinfo.dte.data = ''

    billtotal.btotal.data = ''

    while len(salesform.items) > 0:
        salesform.items.pop_entry()

    for i in range(10):
        itemform = ItemsForm()
        itemform.sl = str(i+1)
        itemform.dsc = ''
        itemform.uom = ''
        itemform.untprc = ''
        itemform.qty = ''
        itemform.ttlprc = ''
        salesform.items.append_entry(itemform)
        
        i += 1

    return custinfo, salesform, billtotal


@app.route('/salesform', methods=['GET', 'POST'])
def addsales():

    if request.method == 'GET':
        print("newsale in request")
        custinfo, salesform, billtotal = PopulateForm()
    else:
        custinfo = CustInfo()
        salesform = SalesForm()
        billtotal = BillTotal()

        print("salesubmit in request")
        print('salesubmit' in request.form)

        d = request.form.to_dict()
        df = pd.DataFrame([d.values()], columns=d.keys())
        save_data(df)
        # df.to_csv(Path+"data/form.csv")
        return redirect(url_for('addsales'))

    return render_template('sales.html', custinfo=custinfo, salesform=salesform, billtotal=billtotal)


@app.route('/lookup')
def lookup():
    key = request.args.get('key')
    nme, tbal = get_value(key)
    print(jsonify(val=(nme, tbal)))
    return jsonify(val=(nme, tbal))


def get_value(key):
    kv = pd.read_csv(Path+"data/Customers.csv").dropna()
    bv = pd.read_csv(Path+"data/CreditDB.csv").dropna()
    for _, row in kv.iterrows():
        if str(int(row['CustomerCode'])) == key:
            custName = row['CustomerName']
            break
        else:
            custName = '+New Customer+'
    
    bal = bv[bv.custcode.astype(int).astype(str) == key]
    tbalance = str(bal.btotal.sum())
    return custName, tbalance


def re_col(col):
    col = col.replace('items-', '')
    if '-' in col:
        first = col.split('-')[0]
        last = col.split('-')[1]
        re_col = last+'-'+first
    else:
        re_col = col
    return re_col


def save_data(df):

    dfcust = df[['custname', 'custcode', 'dte', 'btotal']]
    
    stub=['sl', 'dsc', 'uom', 'untprc', 'qty', 'ttlprc']
    df = df.rename(columns=lambda x: re_col(x))
    dff = pd.wide_to_long(df, stub, i=['custname', 'custcode', 'dte'], j='row', sep='-').replace('', np.nan)
    dff = dff.dropna(subset=['dsc','uom','untprc','qty','ttlprc']).reset_index()
    dff.drop(['csrf_token', 'row', 'salesubmit', 'tbalance'], axis=1, inplace=True)

    dff.to_csv(Path+"data/SalesDB.csv", mode='a', index=False, header=False)
    dfcust.to_csv(Path+"data/CreditDB.csv", mode='a', index=False, header=False)


@app.route('/getitem/<item>')
def get_items(item):
    if ':' in item:
        sln, item = item.split(":")
    res = itmdb[itmdb['ItemName'].str.contains(item, na=False, case=False)]
    lst = res[['SlNo', 'ItemName', 'UOM', 'UnitPriceRTL']] #.head(1) #.to_json(orient='records')
    
    itmA = []
    for ix, itm in lst.iterrows():
        itmObj = {}
        itmObj['slno'] = itm['SlNo']
        itmObj['itmname'] = itm['ItemName']
        itmObj['itmuom'] = itm['UOM']
        itmObj['unitprc'] = itm['UnitPriceRTL']
        itmA.append(itmObj)

    print({'gitems': itmA})
    return jsonify({'gitems': itmA})


@app.route('/getuompri/<sln>')
def get_uompri(sln):
    res = itmdb[itmdb['SlNo'] == int(sln)]
    lst = res[['SlNo', 'ItemName', 'UOM', 'UnitPriceRTL']] #.head(1) #.to_json(orient='records')
    
    itmA = []
    for ix, itm in lst.iterrows():
        itmObj = {}
        itmObj['slno'] = itm['SlNo']
        itmObj['itmname'] = itm['ItemName']
        itmObj['itmuom'] = itm['UOM']
        itmObj['unitprc'] = itm['UnitPriceRTL']
        itmA.append(itmObj)

    print({'uitems': itmA})
    return jsonify({'uitems': itmA})
    

if __name__ == '__main__':
    app.run(debug = True)
