from collections import defaultdict
from flask_wtf import FlaskForm
from wtforms import BooleanField, StringField, validators, DateTimeField, IntegerField, TextAreaField, TextField, RadioField, SelectField
from wtforms import StringField, PasswordField, BooleanField, SubmitField, FieldList, FormField
from wtforms.validators import DataRequired, Length, InputRequired, ValidationError, Required, Email
import pandas as pd

Path = "D:\\Projects\\grocery\\mystoreapp\\"
# itmdb = pd.read_excel(Path+"data/ItemsDB.xlsx")
# itmlst = itmdb.ItemName.unique().tolist()
# ItemsForm.dsc.choices = [x for x in itmlst]

class CustInfo(FlaskForm):
    custname = TextField("Customer Name:")
    tbalance = IntegerField("Total Balance:")
    custcode = IntegerField("Customer Code:",[Required("Please enter customer code.")])
    dte = TextField("Date:")


class ItemsForm(FlaskForm):
    dropdown_list = ['-', 'NOS', 'KG', 'GM', 'LITRE', 'PACKET', 'BOX']
    sl = IntegerField("slno")
    dsc = TextField("name") #SelectField("name", choices=itmlst) #TextField("name")
    uom = SelectField("uom", choices=dropdown_list, default=1)
    untprc = TextField("untprc")
    qty = TextField("qty")
    ttlprc = TextField("ttlprc")


class BillTotal(FlaskForm):
    btotal = TextField("Bill Total:")


class SalesForm(FlaskForm):
    items = FieldList(FormField(ItemsForm), min_entries = 10)

    