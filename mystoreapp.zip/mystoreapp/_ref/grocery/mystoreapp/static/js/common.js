

function calculateSum() {
   var sum = 0;
   $(".ptp").each(function () {
      if (!isNaN(this.value) && this.value.length != 0) {
            sum += parseFloat(this.value);
      }
   });
   $("#btotal").val(sum.toFixed(2));
}


$(function(){
   $("table tr").keyup(function(){
      var oitm = $(this).find('.dsc').val();
      var uom = $(this).find('.uom');
      var pup = $(this).find('.pup');
      var lookitm = oitm.split("(")[0]

   fetch('/getitem/' + lookitm).then(function(response){
      response.json().then(function(data){
         var item = $('<datalist id="datalistOptions"></datalist>');
         for (let itm of data.gitems) {              
            item.append('<option value="'+ itm.slno+': '+itm.itmname +' (Rs. '+ itm.unitprc +')">');
         }
         $("#datalistOptions").replaceWith(item);
      });
   });
   var sitm = $(this).find('.dsc').val();
   var sln = sitm.split(":")[0]
   fetch('/getuompri/' + sln).then(function(response){
      response.json().then(function(data){
         uom.val(data.uitems[0].itmuom);
         pup.val(data.uitems[0].unitprc);
      });
   });
});
});


$(function(){
$("table tr").keyup(function(){
   var qty = parseFloat($(this).find('.pqt').val());
   var price = parseFloat($(this).find('.pup').val());
   prc = price*qty;
   if (!isNaN(prc) && prc.length != 0) {
      $(this).find('.ptp').val(prc.toFixed(2));
      calculateSum();
      }
});
});


//   <script type=text/javascript>
//       $(function(){
//          $('#custbtn').on('click', function (e) {
//             $.getJSON({{ request.script_root|tojson|safe }} + '/lookup',
//                { key: $('#custcode').val() },
//                function(data) {
//                   var ul = $('#custname');
//                   var ul2 = $('#tbalance');
//                   ul.val(data.val[0]);
//                   ul2.val(data.val[1]);
//                });
//          });
//       });
//    </script>

//    <script type=text/javascript>
//         function calculateSum() {
//             var sum = 0;
//             $(".ptp").each(function () {
//                 if (!isNaN(this.value) && this.value.length != 0) {
//                     sum += parseFloat(this.value);
//                 }
//             });
//             $("#btotal").val(sum.toFixed(2));
//         }
//    </script>

//    <script type=text/javascript>
//       $(function(){
//          $("table tr").keyup(function(){
//             var oitm = $(this).find('.dsc').val();
//             var uom = $(this).find('.uom');
//             var pup = $(this).find('.pup');
//             var lookitm = oitm.split("(")[0]

//          fetch('/getitem/' + lookitm).then(function(response){
//             response.json().then(function(data){
//                var item = $('<datalist id="datalistOptions"></datalist>');
//                for (let itm of data.gitems) {              
//                   item.append('<option value="'+ itm.slno+': '+itm.itmname +' (Rs. '+ itm.unitprc +')">');
//                }
//                $("#datalistOptions").replaceWith(item);
//             });
//          });
//          var sitm = $(this).find('.dsc').val();
//          var sln = oitm.split(":")[0]
//          fetch('/getuompri/' + sln).then(function(response){
//             response.json().then(function(data){
//                uom.val(data.uitems[0].itmuom);
//                pup.val(data.uitems[0].unitprc);
//             });
//          });
//       });

//       });
//    </script>

//    <script type=text/javascript>
//       $(function(){
//          $("table tr").keyup(function(){
//             var qty = parseFloat($(this).find('.pqt').val());
//             var price = parseFloat($(this).find('.pup').val());
//             prc = price*qty;
//             if (!isNaN(prc) && prc.length != 0) {
//                $(this).find('.ptp').val(prc.toFixed(2));
//                calculateSum();
//                }
//          });
//          });
//    </script>

   