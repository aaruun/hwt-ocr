from flask import Flask, request, render_template_string, redirect
import sqlite3 as sql

app = Flask(__name__)

DB_PATH = 'database.sqlite'

def create_database():
    conn = sql.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
                CREATE TABLE IF NOT EXISTS SubmitClaim (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    type TEXT,
                    receipt TEXT, 
                    amount TEXT, 
                    description TEXT
                )                
                """)

    conn.commit()
    
    conn.close()

def generate_data():
    """Generate fake data. Use once."""
    conn = sql.connect(DB_PATH)
    cur = conn.cursor()

    for i in range(1, 11):
        cur.execute("""INSERT INTO SubmitClaim (type, receipt, amount, description) VALUES (?, ?, ?, ?)""", 
                    (f"Type {i}", f"Receipt {i}", f"Amount {i}", f"Description {i}"))

    conn.commit()
    conn.close()
    
@app.route('/')
def index():
    return '<a href="/list">LIST</a>'
    
@app.route('/list')
def list():

    conn = sql.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("SELECT * FROM  SubmitClaim")
    rows = cur.fetchall()

    conn.close()

    #return render_template("list.html", rows=rows)
    return render_template_string(template_list, rows=rows)


@app.route('/edit/<int:number>', methods=['GET', 'POST'])
def edit(number):

    conn = sql.connect(DB_PATH)
    cur = conn.cursor()

    if request.method == 'POST':
        item_id      = number
        item_type    = request.form['type']
        item_receipt = request.form['receipt']
        item_amount  = request.form['amount']
        item_description = request.form['description']
    
        cur.execute("UPDATE SubmitClaim SET type = ?, receipt = ?, amount = ?, description = ? WHERE id = ?",
                    (item_type, item_receipt, item_amount, item_description, item_id))
        conn.commit()
        
        return redirect('/list') 
        
    cur.execute("SELECT * FROM SubmitClaim WHERE id = ?", (number,))
    item = cur.fetchone()
    
    conn.close()

    #return render_template("edit.html", item=item)
    return render_template_string(template_edit, item=item)

@app.route('/delete/<int:number>')
def delete(number):

    conn = sql.connect(DB_PATH)
    cur = conn.cursor()
        
    cur.execute("DELETE FROM SubmitClaim WHERE id = ?", (number,))

    conn.commit()
    
    conn.close()

    return redirect('/list') 

@app.route('/add', methods=['GET', 'POST'])
def add():

    conn = sql.connect(DB_PATH)
    cur = conn.cursor()

    if request.method == 'POST':
        item_type    = request.form['type']
        item_receipt = request.form['receipt']
        item_amount  = request.form['amount']
        item_description = request.form['description']
        
        cur.execute("""INSERT INTO SubmitClaim (type, receipt, amount, description) VALUES (?, ?, ?, ?)""", 
                    (item_type, item_receipt, item_amount, item_description))
        conn.commit()
        
        return redirect('/list') 
        
    #return render_template("add.html", item=item)
    return render_template_string(template_add)

template_list = """
<h1>LIST</h1>
{% if rows %}
<table border="1">
    <thead>
        <td>ID</td>
        <td>Type</td>
        <td>Receipt</td>
        <td>Amount</td>
        <td>Description</td>
        <td>Action</td>
    </thead>

    {% for row in rows %}
    <tr>
        <td>{{row[0]}}</td>
        <td>{{row[1]}}</td>
        <td>{{row[2]}}</td>
        <td>{{row[3]}}</td>
        <td>{{row[4]}}</td>
        <td>
            <a href="{{ url_for( "edit", number=row[0] ) }}">EDIT</a> | 
            <a href="{{ url_for( "delete", number=row[0] ) }}">DELETE</a>
        </td>
    </tr>
    {% endfor %}
</table>
{% else %}
Empty</br>
{% endif %}
<a href="{{ url_for( "add" ) }}">ADD</a>
"""

template_add = """
<h1>ADD</h1>
<form method="POST" action="{{ url_for( "add" ) }}">
    Type: <input name="type" value=""/></br>
    Receipt: <input name="receipt" value=""/></br>
    Amount: <input name="amount" value=""/></br>
    Description: <input name="description" value=""/></br>
    <button>UPDATE</button></br>
</form>
"""

template_edit = """
<h1>EDIT</h1>
<form method="POST" action="{{ url_for( "edit", number=item[0] ) }}">
    Type: <input name="type" value="{{item[1]}}"/></br>
    Receipt: <input name="receipt" value="{{item[2]}}"/></br>
    Amount: <input name="amount" value="{{item[3]}}"/></br>
    Description: <input name="description" value="{{item[4]}}"/></br>
    <button>UPDATE</button></br>
</form>
"""


if __name__ == '__main__':
    create_database()
    generate_data()
    app.run(debug=True) 