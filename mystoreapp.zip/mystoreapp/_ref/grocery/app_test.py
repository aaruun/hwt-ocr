from flask import Flask, render_template_string, request, jsonify
import wikipedia

app = Flask(__name__)

index_html='''
<html><body>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js">
</script>
<script type=text/javascript>
  function submit() {
    $.getJSON({{ request.script_root|tojson|safe }} + '/topics',
      { key: $('#key').val() },
      function(data) {
        var ul = $('#result');
        ul.empty();
        $(data.topics).each(function(index, item) {
          ul.append($('<li>',{text:item}));});});}
</script>
Search Term: <input id="key" name="key"/>
<input id="submit" type="button" value="Go" onclick="submit();" />
<hr /><ul id="result"></ul>
</body></html>'''

@app.route('/')
def index():
    return render_template_string(index_html)

@app.route('/topics')
def topics():
    key = request.args.get('key')
    topics = wikipedia.search(key) or ['No topic found']
    return jsonify(topics=topics)

app.run(debug=True)