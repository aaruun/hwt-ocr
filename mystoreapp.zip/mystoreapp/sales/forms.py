from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SelectField, FieldList, FormField
# from wtforms import StringField, PasswordField, BooleanField, SubmitField, FieldList, FormField
from wtforms.validators import InputRequired #,DataRequired, Length, ValidationError, Required, Email
# from wtforms import validators, DateTimeField, TextAreaField, RadioField, TextField
# from wtforms.fields.html5 import DateTimeField


class CustInfo(FlaskForm):
    billno = IntegerField("Bill No", [InputRequired("Please enter Bill No.")])
    custname = StringField("Customer Name",[InputRequired("Please enter customer name.")])
    tbalance = StringField("Total Balance")
    custcode = IntegerField("Customer Code",[InputRequired("Please enter customer code.")])
    dte = StringField("Date")


class SettleInfo(FlaskForm):
    pamt = IntegerField("Pending Amount",[InputRequired("Please enter pending amount.")])
    tildate = StringField("Settle Till Date")


class ItemsForm(FlaskForm):
    dropdown_list = ['-', 'NOS', 'KG', 'GRAM', 'LITRE', 'PACKET', 'CAN', 'BOTTLE', 'BOX']
    sl = IntegerField("SlNo")
    dsc = StringField("Item Name")
    uom = SelectField("Unit", choices=dropdown_list)
    untprc = IntegerField("Unit Price")
    qty = IntegerField("Quantity")
    ttlprc = IntegerField("Total Price")


class BillTotal(FlaskForm):
    dropdown_list = ['CREDIT', 'CASH']
    btotal = StringField("Bill Total",[InputRequired("Bill total is required.")])
    pmtmod = SelectField("Payment", choices=dropdown_list)


class SalesForm(FlaskForm):
    items = FieldList(FormField(ItemsForm), min_entries = 8)


class AddCust(FlaskForm):
    custname = StringField("Customer Name",[InputRequired("Please enter customer name.")])
    custcode = IntegerField("Customer Code",[InputRequired("Please enter customer code.")])
    custphon = IntegerField("Customer Phone")


class AddItem(FlaskForm):
    dropdown_list = ['-', 'NOS', 'KG', 'GRAM', 'LITRE', 'PACKET', 'CAN', 'BOTTLE', 'BOX']
    itemcod = IntegerField("Item Code",[InputRequired("Please enter item code.")])
    itemdesc = StringField("Item Name",[InputRequired("Please enter item name.")])
    itemunit = SelectField("Unit",[InputRequired("Please enter item unit.")], choices=dropdown_list)
    itemprice = IntegerField("Unit Price",[InputRequired("Please enter item price.")])


class AddPayment(FlaskForm):
    custname = StringField("Customer Name",[InputRequired("Please enter customer name.")])
    custcode = IntegerField("Customer Code",[InputRequired("Please enter customer code.")])
    paydate = StringField("Date",[InputRequired("Please enter payment date.")])
    custpay = IntegerField("Customer Pay",[InputRequired("Please enter customer pay.")])
    recvdby = StringField("Received By",[InputRequired("Please enter received by.")])


class SearchForm(FlaskForm):
    billno = IntegerField("Bill No")
    custname = StringField("Customer Name")
    frdte = StringField("From Date")
    todte = StringField("To Date")


class LookupForm(FlaskForm):
    custname = StringField("Customer Name",[InputRequired("Please enter customer name.")])
    frdte = StringField("From Date",[InputRequired("Please enter transaction date.")])
    todte = StringField("To Date",[InputRequired("Please enter transaction date.")])