from flask import Flask, render_template, flash, redirect, request, url_for, jsonify, send_from_directory
# import json
import os
from sales.forms import AddCust, AddItem, AddPayment
from sales.forms import CustInfo, SettleInfo, ItemsForm, SalesForm, BillTotal
from sales.forms import SearchForm, LookupForm
from config.appconfig import Config
# import sqlite3 as sql
import pandas as pd
import numpy as np
from datetime import datetime
# from waitress import serve
# import csv

Path = "C:\\Users\\arunk\\OneDrive\\projects\\mystoreapp\\"
# Path = "D:\\Projects\\mystoreapp\\"
itmdb = pd.read_csv(Path+"data/ItemsDB.csv")

app = Flask(__name__)
app.config.from_object(Config)


@app.route('/')
def home():
   return render_template('index.html')


def PopulateForm():
    custinfo = CustInfo()
    salesform = SalesForm()
    billtotal = BillTotal()

    custinfo.billno.data = ''
    custinfo.custname.data = ''
    custinfo.custcode.data = ''
    custinfo.tbalance.data = ''
    custinfo.dte.data = ''

    billtotal.btotal.data = ''
    billtotal.pmtmod.data = ''
    
    while len(salesform.items) > 0:
        salesform.items.pop_entry()

    for i in range(8):
        itemform = ItemsForm()
        itemform.sl = str(i+1)
        itemform.dsc = ''
        itemform.uom = ''
        itemform.untprc = ''
        itemform.qty = ''
        itemform.ttlprc = ''
        salesform.items.append_entry(itemform)
        i += 1
    return custinfo, salesform, billtotal


def PopulateCustInfoForm():
    custinfo = CustInfo()

    # custinfo.billno.data = ''
    custinfo.custname.data = ''
    custinfo.custcode.data = ''
    custinfo.tbalance.data = ''
    custinfo.dte.data = ''

    return custinfo


def PopulateSettleDetail():
    settleinfo = SettleInfo()

    settleinfo.pamt.data = ''
    settleinfo.tildate.data = ''

    return settleinfo


@app.route('/salesform', methods=['GET', 'POST'])
def addsales():

    cinfo, sform, btotal = PopulateForm()

    if request.method == 'GET':
        print("newsale in request")
    else:
        print("salesubmit in request")
        print('salesubmit' in request.form)
        d = request.form.to_dict()
        df = pd.DataFrame([d.values()], columns=d.keys())
        save_data(df)
        flash('Data submitted successfully. Print Receipt?')
        return redirect(url_for('addsales'))

    return render_template('sales.html', custinfo=cinfo, salesform=sform, billtotal=btotal)


@app.route('/receipt', methods=['GET', 'POST'])
def receipt():

    print("Receipt Printing Starts!")

    if request.method == 'GET':
        print("newsale in request")
    df1 = pd.read_csv(Path+"temp/latestbillsale.csv", header=None)
    df2 = pd.read_csv(Path+"temp/latestbillcust.csv", header=None)

    df2.columns = ['BillNo', 'Customer', 'ID', 'Date', 'Total', 'Payment']
    # custinfo = df2.to_dict(orient='records')
    custinfo = df2.values.tolist()
    print(custinfo)

    df1 = df1.iloc[:, -5:]
    df1.columns = ['Description', 'UOM', 'Price', 'Qty', 'Total']
    df1 = df1[['Qty', 'Description', 'Total']]
    df1['Description'] = df1['Description'].str.split(":").str[1]
    # df1['Description'] = df1['Description'].str.replace("Rs. ","₹")
    df1['Description'] = df1['Description'].str.split("(").str[0]
    tblitems = df1.values.tolist()
    print(tblitems)

    # html = df1.to_html(classes=["table table-sm"], table_id="myTable", index=False)
    print("Receipt Printing Ended!")
    return render_template('receipt.html', tbl=tblitems, custinfo=custinfo[0])


@app.route('/lookup')
def lookup():
    key = request.args.get('key')
    nme, tbal, billno = get_value(key)
    print(jsonify(val=(nme, tbal, billno)))
    return jsonify(val=(nme, tbal, billno))


def days_between(d1, d2):
    d1 = datetime.strptime(d1, "%Y-%m-%d")
    d2 = datetime.strptime(d2, "%Y-%m-%d")
    return str(abs((d2 - d1).days))


def get_value(key):
    kv = pd.read_csv(Path+"data/Customers.csv").dropna(thresh=2)
    bv = pd.read_csv(Path+"data/CreditDB.csv").dropna()
    pv = pd.read_csv(Path+"data/Payments.csv").dropna()

    billNo = int(bv['Bill No'].max())+1
    for _, row in kv.iterrows():
        if str(int(row['Customer Code'])) == key:
            custName = row['Customer Name']
            custPhone = row['Phone No']
            if np.isnan(custPhone):
                custNamePh = custName
            else:
                custNamePh = custName + ': ' + str(int(custPhone))
            break
        else:
            custNamePh = '+New Customer+'
    
    bal = bv[(bv['Customer Code'].astype(int).astype(str) == key) & (bv['Payment'] == 'CREDIT')]
    pay = pv[pv['Customer Code'].astype(int).astype(str) == key]
    DLP = str(pay['Date'].max())
    TDY = datetime.today().strftime('%Y-%m-%d')
    if DLP == 'nan':
        DLP = str(bal['Date'].min())
    if DLP == 'nan':
        DTE = str(0)
    else:
        DTE = days_between(DLP.split()[0], TDY)
    tbalance = str(bal['Bill Total'].sum()-pay['Amount Paid'].sum())+' ('+DTE+' Days)'
    return custNamePh, tbalance, billNo


def re_col(col):
    col = col.replace('items-', '')
    if '-' in col:
        first = col.split('-')[0]
        last = col.split('-')[1]
        re_col = last+'-'+first
    else:
        re_col = col
    return re_col


def save_settle_data(df):

    df['custname'] = df['custname'].str.split(':').str[0]
    dfcust = df[['billno', 'custname', 'custcode', 'dte', 'pamt', 'pmtmod']]
    dfsetl = df[['custname', 'custcode', 'dte', 'tbalance', 'pamt', 'tildate']]

    custcode = int(df.at[0, 'custcode'])
    tildate = pd.to_datetime(df.at[0, 'tildate'])

    print(tildate, custcode)
    print(type(tildate), type(custcode))

    # Read files
    dfsales = pd.read_csv(Path+"data/SalesDB.csv", parse_dates=['Date']) #, dayfirst=True)
    dfcredit = pd.read_csv(Path+"data/CreditDB.csv", parse_dates=['Date']) #, dayfirst=True)
    dfpmt = pd.read_csv(Path+"data/Payments.csv", parse_dates=['Date']) #, dayfirst=True)

    # Take data for backup
    dfsales_bu = dfsales[(dfsales['Customer Code'] == custcode) & (dfsales['Date'] < tildate)]
    dfcredit_bu = dfcredit[(dfcredit['Customer Code'] == custcode) & (dfcredit['Date'] < tildate)]
    dfpmt_bu = dfpmt[(dfpmt['Customer Code'] == custcode) & (dfpmt['Date'] < tildate)]

    df.drop(['csrf_token', 'tbalance', 'tildate', 'settlesubmit'], axis=1, inplace=True)

    # Append data to archive files
    dfsales_bu.to_csv(Path+"archive/SalesDB.csv", mode='a', index=False, header=False)
    dfcredit_bu.to_csv(Path+"archive/CreditDB.csv", mode='a', index=False, header=False)
    dfpmt_bu.to_csv(Path+"archive/Payments.csv", mode='a', index=False, header=False)

    # Drop backed up records
    dfsales.drop(dfsales[((dfsales['Customer Code'] == custcode) & (dfsales['Date'] < tildate))].index, inplace=True)
    dfcredit.drop(dfcredit[((dfcredit['Customer Code'] == custcode) & (dfcredit['Date'] < tildate))].index, inplace=True)
    dfpmt.drop(dfpmt[((dfpmt['Customer Code'] == custcode) & (dfpmt['Date'] < tildate))].index, inplace=True)

    # Overwrite files within data folder
    dfsales.to_csv(Path+"data/SalesDB.csv", index=False)
    dfcredit.to_csv(Path+"data/CreditDB.csv", index=False)
    dfpmt.to_csv(Path+"data/Payments.csv", index=False)

    # Append files within data folder
    dfsetl.to_csv(Path+"data/SettleDB.csv", mode='a', index=False, header=False)
    dfcust.to_csv(Path+"data/CreditDB.csv", mode='a', index=False, header=False)


def save_data(df):
    df['custname'] = df['custname'].str.split(':').str[0]

    dfcust = df[['billno', 'custname', 'custcode', 'dte', 'btotal', 'pmtmod']]
    # print(dfcust.columns)
    
    stub=['sl', 'dsc', 'uom', 'untprc', 'qty', 'ttlprc']
    df = df.rename(columns=lambda x: re_col(x))
    dff = pd.wide_to_long(df, stub, i=['billno', 'custname', 'custcode', 'dte', 'pmtmod'], j='row', sep='-').replace('', np.nan)

    dff = dff.dropna(subset=['dsc','uom','untprc','qty','ttlprc']).reset_index()
    # print(dff.columns)
    dff.drop(['csrf_token', 'row', 'salesubmit', 'tbalance'], axis=1, inplace=True)
    dff.to_csv(Path+"data/SalesDB.csv", mode='a', index=False, header=False)
    dff.to_csv(Path+"temp/latestbillsale.csv", mode='w', index=False, header=False)
    dfcust.to_csv(Path+"data/CreditDB.csv", mode='a', index=False, header=False)
    dfcust.to_csv(Path+"temp/latestbillcust.csv", mode='w', index=False, header=False)
    # return dff


@app.route('/getitem/<item>')
def get_items(item):
    if ':' in item:
        _, item = item.split(":")

    if len(item) > 2:
        res = itmdb[itmdb['ItemName'].str.contains(item, na=False, case=False)]
        lst = res[['SlNo', 'ItemName', 'UOM', 'UnitPriceRTL']] #.head(1) #.to_json(orient='records')
        
        itmA = []
        for _, itm in lst.iterrows():
            itmObj = {}
            itmObj['slno'] = itm['SlNo']
            itmObj['itmname'] = itm['ItemName']
            itmObj['itmuom'] = itm['UOM']
            itmObj['unitprc'] = itm['UnitPriceRTL']
            itmA.append(itmObj)

        print({'gitems': itmA})
        return jsonify({'gitems': itmA})
    else:
        return jsonify({'gitems': []})


@app.route('/getuompri/<sln>')
def get_uompri(sln):

    if sln.isdigit():
        res = itmdb[itmdb['SlNo'] == int(sln)]
        lst = res[['SlNo', 'ItemName', 'UOM', 'UnitPriceRTL']] #.head(1) #.to_json(orient='records')
        
        itmA = []
        for _, itm in lst.iterrows():
            itmObj = {}
            itmObj['slno'] = itm['SlNo']
            itmObj['itmname'] = itm['ItemName']
            itmObj['itmuom'] = itm['UOM']
            itmObj['unitprc'] = itm['UnitPriceRTL']
            itmA.append(itmObj)

        print({'uitems': itmA})
        return jsonify({'uitems': itmA})
    else:
        return jsonify({'uitems': []})


@app.route('/dailyview')
def htmlsales_table():
    # lncnt = get_linecount(Path+'data/SalesDB.csv')
    df = pd.read_csv(Path+'data/SalesDB.csv', parse_dates=['Date']) #, dayfirst=True)
    # df['Sale Date'] = df['Date'].apply(pd.to_datetime).dt.strftime('%d-%m-%Y %H:%M')
    df = df.groupby(['Bill No', 'Date', 'Customer Name'])['Price'].agg('sum').reset_index()
    # df.sort_values(by=['Bill No'], inplace=True, ascending=False)
    html = df.to_html(classes=["table table-bordered table-striped table-hover"], table_id="myTable", index=False)
    return render_template('dailyview.html', data=html)


def PopulateSearchForm():
    sf = SearchForm()
    sf.billno.data = ''
    sf.custname.data = ''
    sf.frdte.data = ''
    sf.todte.data = ''
    return sf


def PopulateLookupForm():
    sf = LookupForm()
    sf.custname.data = ''
    sf.frdte.data = ''
    sf.todte.data = ''
    return sf


# @app.route('/dailyitemview')
# def htmldailyitem_table():
#     # lncnt = get_linecount(Path+'data/SalesDB.csv')
#     df = pd.read_csv(Path+'data/CreditDB.csv', parse_dates=['Date']) #, dayfirst=True)
#     # df['Sale Date'] = df['Date'].apply(pd.to_datetime).dt.strftime('%d-%m-%Y %H:%M')
#     df['RowID'] = ''
#     df = df.groupby(['RowID', 'Bill No', 'Date', 'Customer Name'])['Bill Total'].agg('sum').reset_index().tail(100)
#     # df.sort_values(by=['Bill No'], inplace=True, ascending=False), , 'Sl No','Item Description', 'Quantity', 'Unit'
#     html = df.to_html(classes=["table table-bordered table-striped table-hover"], table_id="myTable", index=False)
#     # return render_template('dailyitemview.html', data={'data':df.to_dict(orient='records')})
#     searchform = PopulateSearchForm()
#     return render_template('dailyitemview.html', data=html, sf=searchform)


# @app.route('/viewpayment')
# def viewpayment():

#     dfpay = pd.read_csv(Path+'data/Payments.csv', parse_dates=['Date']) #, dayfirst=True)
#     dfcrd = pd.read_csv(Path+'data/CreditDB.csv', parse_dates=['Date']) #, dayfirst=True)
#     # dfpay['Date'] = pd.to_datetime(dfpay['Date']).dt.strftime('%d-%m-%Y')
#     # dfcrd['Date'] = pd.to_datetime(dfcrd['Date']).dt.strftime('%d-%m-%Y')
    
#     df = pd.concat([dfpay, dfcrd])
#     df['Year'] = pd.DatetimeIndex(df['Date']).year
#     df['Month'] = pd.DatetimeIndex(df['Date']).month
    
#     df['Customer Name'] = df['Customer Name']+' ('+df['Customer Code'].astype(str)+')'
#     df['Duration'] = df['Year'].astype(str)+'-'+df['Month'].astype(str)
#     df = df.groupby(['Customer Name', 'Duration'])[['Bill Total', 'Amount Paid']].agg('sum').reset_index()
#     # df.sort_values(by=['Customer Name', 'Duration'], inplace=True, ascending=False)

#     html = df.to_html(classes=["table table-bordered table-striped table-hover"], table_id="myTable", index=False)
#     return render_template('viewpayment.html', data=html)


def days_pending(custname, df):

    bal = df[(df['Payment'] == 'CREDIT') & (df['Customer Name'] == custname)]
    pay = df[(df['Payment'].isnull()) & (df['Customer Name'] == custname)]
    
    if len(pay.index) > 0:
        DLP = pay['Date'].max().strftime('%Y-%m-%d')
    elif len(bal.index) > 0:
        DLP = bal['Date'].min().strftime('%Y-%m-%d')

    if len(pay.index) > 0 or len(bal.index) > 0:
        TDY = datetime.today().strftime('%Y-%m-%d')
        DTE = days_between(DLP, TDY)
    else:
        DTE = str(0)
        
    return str(DTE)


@app.route('/dailyitemview', methods=['GET', 'POST'])
def htmldailyitem_table():

    searchform = PopulateSearchForm()

    if request.method == 'GET':
        print("table populate in request")
        billno, custname, frdte, todte = None,None,None,None
    else:
        print("search bill in request")
        print('srcitm' in request.form)
        d = request.form.to_dict()
        billno = d['billno']
        custname = d['custname']
        frdte = d['frdte']
        todte = d['todte']

    df = pd.read_csv(Path+'data/CreditDB.csv', parse_dates=['Date']) #, dayfirst=True)
    df['RowID'] = ''

    if billno:
        df = df[df['Bill No'].astype(int).astype(str) == str(billno)]
    if custname:
        df = df[df['Customer Name'].str.contains(custname, na=False, case=False)]
    if frdte:
        df = df[df['Date'].dt.date >= datetime.strptime(frdte, "%Y-%m-%d").date()]
    if todte:
        df = df[df['Date'].dt.date <= datetime.strptime(todte, "%Y-%m-%d").date()]

    df2day = df[df['Date'].dt.date == datetime.today().date()]
    totalsale = df2day['Bill Total'].sum()
    bills = df2day['Bill No'].count()

    df = df.groupby(['RowID', 'Bill No', 'Date', 'Customer Name'])['Bill Total'].agg('sum').reset_index().tail(100)
    df['Date'] = df['Date'].dt.strftime("%d-%b-%y %H:%M")
    html = df.to_html(classes=["table table-bordered table-striped table-hover"], table_id="myTable", index=False)   
    return render_template('dailyitemview.html', data=html, sf=searchform, totalsale=totalsale, bills=bills)


@app.route('/dailychildview/<BillNo>')
def htmldailychild_table(BillNo):
    # lncnt = get_linecount(Path+'data/SalesDB.csv')
    df = pd.read_csv(Path+'data/SalesDB.csv', parse_dates=['Date']) #, dayfirst=True)
    # df['Sale Date'] = df['Date'].apply(pd.to_datetime).dt.strftime('%d-%m-%Y %H:%M')
    df = df[df['Bill No'].astype(int).astype(str)==BillNo]
    df = df[df.columns[-6:]].astype(str)
    print(BillNo)
    html = df.to_html(classes=["table table-bordered table-striped table-hover"], table_id="childTable", index=False)
    return html


def consolidated_data():  
    bv = pd.read_csv(Path+"data/CreditDB.csv", parse_dates=['Date']).dropna()
    pv = pd.read_csv(Path+"data/Payments.csv", parse_dates=['Date']).dropna()
    df = pd.concat([bv, pv]) #.reset_index(drop=True)

    df['Customer Name'] = df['Customer Name'].str.split(':').str[0]
    df['Customer Name'] = df['Customer Name']+' ('+df['Customer Code'].astype(str)+')'
    df = df[['Customer Name', 'Date', 'Bill Total', 'Amount Paid', 'Payment']] #Common
    return df


@app.route('/timeline', methods=['GET', 'POST'])
def timeline():
    
    lookupform = PopulateLookupForm()

    if request.method == 'GET':
        print("table populate in request")
        cstname, frdte, todte = None,None,None
    else:
        print("search bill in request")
        print('srcitm' in request.form)
        d = request.form.to_dict()
        cstname = d['custname']
        frdte = d['frdte']
        todte = d['todte']

    df = consolidated_data()

    if cstname:
        df = df[df['Customer Name'].str.contains(cstname, na=False, case=False)]
    if frdte:
        df = df[df['Date'].dt.date >= datetime.strptime(frdte, "%Y-%m-%d").date()]
    if todte:
        df = df[df['Date'].dt.date <= datetime.strptime(todte, "%Y-%m-%d").date()]

    dfa = df.groupby(['Customer Name'])[['Bill Total', 'Amount Paid']].agg('sum').reset_index()
    dfa['Days Pending'] = dfa['Customer Name'].apply(lambda x: days_pending(x, df))
    dfa['Balance Amount'] = dfa['Bill Total'] - dfa['Amount Paid']
    dfa.sort_values(by=['Balance Amount', 'Days Pending'], inplace=True, ascending=False)
    dfa.insert(0, 'RowID', value='')

    tbalance = dfa['Balance Amount'].sum()
    html = dfa.to_html(classes=["table table-bordered table-striped table-hover display"], table_id="myTable", index=False)
    return render_template('timeline.html', data=html, tbalance=tbalance, sf=lookupform)


@app.route('/personpayment/<custname>')
def personpayment(custname):

    df = consolidated_data()
    df = df.sort_values(by=['Customer Name', 'Date']).reset_index(drop=True)
    df = df[df['Customer Name'] == custname].reset_index(drop=True)
    df['Group'] = '.'

    i = 1
    for ix, _ in df.iterrows():
        if ix == 0:
            df.at[ix, 'Group'] = i
        if ix > 0:
            preval = df['Payment'][ix-1]
            curval = df['Payment'][ix]
            if preval == curval:
                df.at[ix, 'Group'] = i
            elif preval != curval:
                df.at[ix, 'Group'] = i+1
                i += 1  

    dfa = df.groupby(['Customer Name', 'Group'])[['Bill Total', 'Amount Paid']].agg('sum').reset_index()
    dft = df.groupby('Group').agg(From=('Date', np.min), To=('Date', np.max)).reset_index()
    dfa = dfa.merge(dft, on='Group')
    dfa['From'] = dfa['From'].dt.strftime("%d-%b-%y")
    dfa['To'] = dfa['To'].dt.strftime("%d-%b-%y")
    html = dfa.to_html(classes=["table table-bordered table-striped table-hover"], table_id="myTable", index=False)

    # return render_template('viewpayment.html', data=html)
    return html


def AddCustInfoPopulateForm():
    addcust = AddCust()
    addcust.custname.data = ''
    addcust.custcode.data = ''
    addcust.custphon.data = ''
    return addcust


@app.route('/addcustomer', methods=['GET', 'POST'])
def addcustomer():

    addcust = AddCustInfoPopulateForm()

    if request.method == 'GET':
        print("newcust in request")
    else:
        # addcust = AddCust()
        print("custsubmit in request")
        print('custsubmit' in request.form)
        d = request.form.to_dict()
        df = pd.DataFrame([d.values()], columns=d.keys())
        df.drop(['csrf_token', 'newcust'], axis=1, inplace=True)
        df.to_csv(Path+"data/Customers.csv", mode='a', index=False, header=False)
        flash('Customer added successfully.')
        return redirect(url_for('addcustomer'))

    return render_template('addcustomer.html', addcust=addcust)


def AddItemPopulateForm():
    additem = AddItem()
    additem.itemcod.data = ''
    additem.itemdesc.data = ''
    additem.itemunit.data = ''
    additem.itemprice.data = ''
    return additem


@app.route('/additem', methods=['GET', 'POST'])
def addnewitem():
    global itmdb
    additem = AddItemPopulateForm()

    if request.method == 'GET':
        print("newitem in request")
    else:
        # additem = AddItem()
        print("itemsubmit in request")
        print('itemsubmit' in request.form)
        d = request.form.to_dict()
        df = pd.DataFrame([d.values()], columns=d.keys())
        df.drop(['csrf_token', 'newitem'], axis=1, inplace=True)
        df.to_csv(Path+"data/ItemsDB.csv", mode='a', index=False, header=False)
        itmdb = pd.read_csv(Path+"data/ItemsDB.csv")
        flash('Item added successfully.')
        # return redirect(url_for('addnewitem'))
        return redirect(url_for('addupdateitem'))

    return render_template('additem.html', additem=additem)


@app.route('/addupdateitem', methods=['GET', 'POST'])
def addupdateitem():
    global itmdb
    aduditem = AddItemPopulateForm()
    itmdb = pd.read_csv(Path+"data/ItemsDB.csv")
    itmdb['Update'] = ''
    # itmdb['Delete'] = ''

    d = request.form.to_dict()
    if request.method == 'GET':
        print("table in request")

    elif 'updateitem' in d.keys():
        print('updateitem' in request.form)
        itemName = d['itemdesc']
        unitOmm = d['itemunit']
        unitPrc = d['itemprice']
        print(itemName, unitOmm, unitPrc)
        itmdb.loc[itmdb.SlNo == int(d['itemcod']), ['ItemName', 'UOM', 'UnitPriceRTL']] = itemName, unitOmm, unitPrc
        itmdb.drop(['Update'], axis=1, inplace=True)
        itmdb.to_csv(Path+"data/ItemsDB.csv", index=False) #, header=False)

        flash('Item ' + d['itemcod'] + ' updated successfully.')
        return redirect(url_for('addupdateitem'))

    elif 'deleteitem' in d.keys():
        print('deleteitem' in request.form)
        itemName = d['itemdesc']
        unitOmm = d['itemunit']
        unitPrc = d['itemprice']
        print(itemName, unitOmm, unitPrc)
        itmdb.drop(['Update'], axis=1, inplace=True)
        itmdb.drop(itmdb[itmdb.SlNo == int(d['itemcod'])].index, inplace = True)
        itmdb.to_csv(Path+"data/ItemsDB.csv", index=False) #, header=False)

        flash('Item ' + d['itemcod'] + ' deleted successfully.')
        return redirect(url_for('addupdateitem'))

    html = itmdb.to_html(classes=["table table-bordered table-striped table-hover display"], table_id="myTable", index=False)
    return render_template('addupdateitem.html', data=html, aduditem=aduditem)


@app.route('/getcode/<tbl>')
def getcode(tbl):
    if tbl == 'customers':
        df = pd.read_csv(Path+'data/Customers.csv')
        code = int(df['Customer Code'].max()+1)
    elif tbl == 'items':
        df = pd.read_csv(Path+'data/ItemsDB.csv')
        code = int(df['SlNo'].max()+1)

    print(jsonify(val=code))
    return jsonify(val=code)


def AddPaymentPopulateForm():
    addpay = AddPayment()
    addpay.custname.data = ''
    addpay.custcode.data = ''
    addpay.paydate.data = ''
    addpay.custpay.data = ''
    addpay.recvdby.data = ''
    return addpay


@app.route('/addpayment', methods=['GET', 'POST'])
def addpayment():
    addpay = AddPaymentPopulateForm()

    if request.method == 'GET':
        print("newpay in request")
    else:
        # addpay = AddPayment()
        print("paysubmit in request")
        print('paysubmit' in request.form)
        d = request.form.to_dict()
        df = pd.DataFrame([d.values()], columns=d.keys())
        df.drop(['csrf_token', 'newpay'], axis=1, inplace=True)

        df.to_csv(Path+"data/Payments.csv", mode='a', index=False, header=False)
        flash('Payment details updated successfully.')
        return redirect(url_for('addpayment'))

    return render_template('addpayment.html', addpay=addpay)


@app.route('/settleaccount', methods=['GET', 'POST'])
def settleaccount():

    settleaccount = PopulateCustInfoForm()
    settledetail = PopulateSettleDetail()

    if request.method == 'GET':
        print("settleact in request")

    else:
        print("settlesubmit in request")
        print('settlesubmit' in request.form)

        d = request.form.to_dict()
        # print("settle data")
        # print(d)
        d.update(billno=0, pmtmod='CREDIT')
        df = pd.DataFrame([d.values()], columns=d.keys())
        save_settle_data(df)
        # df.to_csv(Path+"data/form_settle.csv")
        flash('Account details settled successfully.')
        return redirect(url_for('settleaccount'))

    return render_template('settleaccount.html', settleaccount=settleaccount, settledetail=settledetail)


@app.route('/getcust/<cust>')
def get_custs(cust):
    if ':' in cust:
        cust, _ = cust.split(":")

    if len(cust) > 2:
        custdb = pd.read_csv(Path+'data/Customers.csv')
        res = custdb[custdb['Customer Name'].str.contains(cust, na=False, case=False)]
        lst = res[['Customer Name', 'Customer Code']] #, 'Phone No']] #.head(1) #.to_json(orient='records')
        
        custA = []
        for _, cst in lst.iterrows():
            cstObj = {}
            cstObj['cstnme'] = cst['Customer Name']
            cstObj['cstcde'] = str(cst['Customer Code'])
            # cstObj['cstphn'] = str(cst['Phone No'])
            custA.append(cstObj)

        print({'custslst': custA})
        return jsonify({'custslst': custA})
    else:
        return jsonify({'custslst': []})


@app.route('/getcod/<cod>')
def get_codbal(cod):

    if cod.isdigit():
        nme, tbal, billNo = get_value(cod)
        custA = []
        # for ix, cst in lst.iterrows():
        cstObj = {}
        cstObj['cstnme'] = nme #cst['Customer Name']
        cstObj['cstcde'] = str(cod) #str(cst['Customer Code'])
        cstObj['csttbal'] = str(tbal) #str(cst['Phone No'])
        cstObj['cstblno'] = str(billNo) #str(cst['Phone No'])
        custA.append(cstObj)

        print({'codlst': custA})
        return jsonify({'codlst': custA})
    else:
        return jsonify({'codlst': []})


@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static/imgs/'),
                          'favicon.ico',mimetype='image/vnd.microsoft.icon')

if __name__ == '__main__':
    # app.run(host='0.0.0.0', port=3000, debug=False, use_reloader=False)
    app.run(debug = True, host='0.0.0.0', port='8080')
    # print("Server Started..")
    # serve(app)
